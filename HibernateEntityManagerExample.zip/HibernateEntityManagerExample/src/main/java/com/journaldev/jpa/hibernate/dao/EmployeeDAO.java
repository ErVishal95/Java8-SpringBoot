package com.journaldev.jpa.hibernate.dao;

import java.util.List;

import com.journaldev.jpa.hibernate.model.Department;
import com.journaldev.jpa.hibernate.model.Employee;

public interface EmployeeDAO
{
    public List<Employee> getAllEmployees();
    public List<Department> getAllDepartments();
    public void addEmployee(Employee employee);
}