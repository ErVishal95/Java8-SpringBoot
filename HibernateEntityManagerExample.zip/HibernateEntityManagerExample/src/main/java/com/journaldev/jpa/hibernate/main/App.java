package com.journaldev.jpa.hibernate.main;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.journaldev.jpa.hibernate.dao.EmployeeDaoImpl;
import com.journaldev.jpa.hibernate.model.Address;
import com.journaldev.jpa.hibernate.model.Certification;
import com.journaldev.jpa.hibernate.model.Department;
import com.journaldev.jpa.hibernate.model.Employee;
import com.journaldev.jpa.hibernate.model.Finance;
import com.journaldev.jpa.hibernate.model.Project;


public class App {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		System.out.println("Starting Transaction");
		entityManager.getTransaction().begin();
		Department department = new Department();
//		department.setId(001);
		department.setName("IT");
		//entityManager.persist(department);
		
	//Finance Object	
		Finance fin1 = new Finance((float) 2222.20, Calendar.getInstance().getTime(), "10%");
		//entityManager.persist(fin1);
		Finance fin2 = new Finance((float) 1144.50, Calendar.getInstance().getTime(), "8%");
		//entityManager.persist(fin2);
		
	//Project Object	
		Project project = new Project("Mike Albert", "Software Development", "$25000", "2 Years");
		//entityManager.persist(project);
		Project project1 = new Project("IBS MALL", "Software Development", "$12400", "1.5s Years");
		//entityManager.persist(project1);
		Project project2 = new Project("qwerty", "as", "$12400", "1.5s Years");
		//entityManager.persist(project2);
		
	//Cetificate Object
		Certification certification1 = new Certification("Java8", "6 Months", "₹ 8999/-");
		//entityManager.persist(certification1);
		Certification certification2 = new Certification("Spring framework", "2 Months", "₹ 5400/-");
		//entityManager.persist(certification2);
		
		
		entityManager.getTransaction().commit();
		System.out.println("Generated department ID = " + department.getId());
//		Department dep = (Department) entityManager.createQuery("Select d from Department d where d.Id = "+1).getSingleResult();
		Department dep = (Department) entityManager.find(Department.class, 1);
		
		entityManager.getTransaction().begin();
		
		Department depart = new Department();
		depart.setName("CSE");
		//entityManager.persist(depart);
		
		Employee employee = new Employee();
		employee.setFirstName("Pankaj");
		employee.setLastName("Sharma");
		employee.setDepartment(depart);
//		employee.setDate(new Date());
		employee.setCheck_id("Testing Transient");
//		employee.setVolatileValueChack("volatileValueChack");
		employee.setAddress(new Address("Mahatma Gandhi marg", "New Delhi", "Delhi", "INDIA", 110001));
//		employee.setFinance(fin1);
		//employee.setFinance(entityManager.find(Finance.class, 1));
		employee.setDate(Calendar.getInstance().getTime());
		employee.setProject(project);
//		employee.getCertifications().add(certification1);
//		employee.getCertifications().add(certification2);
		entityManager.persist(employee);
		
		//entityManager.getTransaction().commit();
		//entityManager.getTransaction().begin();
		
		Employee empl = new Employee();
		empl.setFirstName("vijay");
		empl.setLastName("gupta");
//		empl.setDepartment(department);
		empl.setDepartment(depart);
//		empl.setDate(new Date());
		empl.setCheck_id("Testing Transient");
		empl.setAddress(new Address("Ghanta Ghar marg", "Delhi", "Delhi", "INDIA", 110011));
		//empl.setFinance(entityManager.find(Finance.class, 2));
		empl.setDate(Calendar.getInstance().getTime());
		empl.setProject(project);
		System.out.println("Saving 2nd Employee to Database");

		entityManager.persist(empl);
		//entityManager.getTransaction().commit();
		//entityManager.getTransaction().begin();
		
		Employee empl1 = new Employee();
		empl1.setFirstName("vijay");
		empl1.setLastName("gupta");
//		empl.setDepartment(department);
		empl1.setDepartment(depart);
//		empl.setDate(new Date());
		empl1.setCheck_id("Testing Transient");
		empl1.setAddress(new Address("Ghanta Ghar marg", "Delhi", "Delhi", "INDIA", 110011));
		//empl1.setFinance(entityManager.find(Finance.class, 2));
		empl1.setDate(Calendar.getInstance().getTime());
		empl1.setProject(project);
		entityManager.persist(empl1);
		
/*	//	Project Add Employees
		project.getEmployees().add(empl);
		project.getEmployees().add(employee);
		
//		Certificate Add Employees
		certification1.getSet().add(employee);
		certification1.getSet().add(empl);
		entityManager.persist(certification1);

		certification2.getSet().add(employee);
		certification2.getSet().add(empl);
		entityManager.persist(certification2);
		
		entityManager.persist(project);*/
		entityManager.getTransaction().commit();
		System.out.println("Generated Employee ID = " + empl.getId());

		// get an object using primary key.
		Employee emp = entityManager.find(Employee.class, empl.getId());
		System.out.println("got object " + emp.getFirstName() + " " + emp.getLastName()+" "+emp.getId()+" "+emp.getDate()+" "+emp.getAddress().getCity()+" "+emp.getAddress().getZipCode()+" "+emp.getAddress().getState());

		// get all the objects from Employee table
		@SuppressWarnings("unchecked")
		List<Employee> listEmployee = entityManager.createQuery("SELECT e FROM Employee e").getResultList();

		if (listEmployee == null) {
			System.out.println("No employee found . ");
		} else {
			for (Employee emp1 : listEmployee) {
				System.out.println("Employee name= " + emp1.getFirstName() + " " + emp1.getLastName()+" Employee_Id "+emp1.getId()+" "+emp1.getAddress().getCity()+" "+emp1.getAddress().getZipCode()+" "+emp1.getAddress().getState());
				System.out.println("Employee Current Department is: "+" "+emp1.getDepartment());
			}
		}
		
		List<Department> listDep = entityManager.createQuery("SELECT d FROM Department d").getResultList();
		listDep.stream().map(Department:: getName).forEach(System.out:: println);
		
		entityManager.createQuery("select p from Project p", Project.class).getResultList().stream().map(Project:: getEmployees).forEach(System.out:: println);
		
		entityManager.createQuery("SELECT d FROM Department d").getResultList().stream().forEach(System.out:: println);
		// remove and entity
//		entityManager.getTransaction().begin();
//		System.out.println("Deleting Employee with ID = " + emp.getEmployeeId());
//		entityManager.remove(emp);
//		entityManager.getTransaction().commit();

		// close the entity manager
		entityManager.close();
		entityManagerFactory.close();

	}
}
