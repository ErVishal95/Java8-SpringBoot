package com.journaldev.jpa.hibernate.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindFactorial {
//	public static void main(String[] args) {
//		System.out.println(factRecursive(6));
//	}
//	
//	static int factRecursive(int n) {
//		if(n==0)
//			return 1;
//		return n*factRecursive(n-1);
//	}
	
	public static void main(String[] args) {
		int temp = 0;
		Integer arr[] = {5,5,5,5,5,5,1,1,1,1,0};
		List<Integer> l= new ArrayList<>();
		List<Integer> ll= new ArrayList<>();
		Set<Integer> x = new HashSet<>(Arrays.asList(arr));
		System.out.println(x);
		l.addAll(x);
		for(int j = 0; j<l.size(); j++) {
			int count = 0;
			for(int i = 0; i<arr.length; i++) {
				if(l.get(j)== arr[i] ) 
					count++;
				temp = count;
			}
			ll.add(temp);
			System.out.println(l.get(j)+" "+temp);
		}
		System.out.println(ll);
		}
	}

