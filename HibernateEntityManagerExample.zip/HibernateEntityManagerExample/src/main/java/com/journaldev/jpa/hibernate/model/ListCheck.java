package com.journaldev.jpa.hibernate.model;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ListCheck {
	public static void main(String[] args) {
		List<Integer> l1 = Arrays.asList(1,2,3,5,6,7);
		List<Integer> l2 = Arrays.asList(1,2,4,3,5);
		
		for(int j =0; j<l1.size();j++) {
			for(int i = 0; i<l2.size(); i++) {
				if(l2.get(i).equals(l1.get(j)))
						continue;
				else if(!l2.get(i).equals(l1.get(j))) {
//					if(!l2.contains(l1.get(i)))
//						l2.add(l1.get(j));
//					else
//						l2.remove(l1.get(j));
				} 	
			}
		}
		System.out.println(l2);
		List<Optional<Integer>> l3 = l1.stream().map((p) -> {
            return l2.stream().filter(u -> p.equals(u)).findFirst();
        }).collect(Collectors.toList());
		System.out.println(l3);
		l3.stream().skip(1).forEach(System.out::println);
	}
}
