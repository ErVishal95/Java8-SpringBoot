package com.journaldev.jpa.hibernate.model;

class Transact {
	public int amount = 10000;
	
	public synchronized void withDraw(int amt) {
		System.out.println("Going to withdraw");
		
		if(this.amount < amt) {
			System.out.println("Balance is low");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.amount -= amt;
		System.out.println("Amount withdrawn");
	}
	public synchronized void deposit(int amt) {
		System.out.println("Going to deposit");
		
		this.amount += amt;
		
		System.out.println("amount deposited");
		notify();
	}
}

public class ProducerConsumer{
	public static void main(String[] args) {
		final Transact t = new Transact();
		
		new Thread() {
			public void run() {t.withDraw(15000);};
		}.start();
		
		new Thread() {
			public void run() {t.deposit(1000);;};
		}.start();
	}
}
