package com.journaldev.jpa.hibernate.model;

import java.util.Collection.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamTestPrg {
//	public static void main(String[] args) {
//		String s1 = "asdf";
//		String s2 = "qwerty";
//		IntStream a = s1.chars();
//		IntStream b = s2.chars();
////		a.mapToObj(c-> (char)c).toString() + b.mapToObj(c-> (char)c).toString();
////		System.out.println(a..concat(s2));
//		Stream<String> st1 = Stream.of("asdf");
//		Stream<String> st2 = Stream.of("qwerty");
//		Stream<String> st3 = Stream.concat(st1, st2);
//		
////		System.out.println(st3.collect(Collectors.toList()));
//		String str = st3.collect(Collectors.joining(","));
//		System.out.println(str);
//	}
	
	public static void main(String[] args) {
		ArrayList<Integer> l = new ArrayList<Integer>(Arrays.asList(1, 2, 2, 3, 4, 7, 10, 15));  
		System.out.println(l.stream().filter(e-> e%5== 0).collect(Collectors.toList()));
		
		System.out.println(l.indexOf(1));
		System.out.println(l.stream().filter(ll -> ll.equals(1)).findAny().orElse(null));
		
		Map<Character, Integer> hm = new HashMap<Character, Integer>();		
		String s = "aaabbbbc";
		char[] c = s.toCharArray();
		for(int i = 0; i< c.length; i++) {
//			System.out.println(c[i]);
			if(hm.containsKey(c[i]))
				hm.put(c[i], hm.get(c[i])+1);
			else
				hm.put(c[i], 1);
		}
		int val=0;
		char requiredChar = 0;
		for(Map.Entry<Character, Integer> h1 : hm.entrySet()) {
			if(val<h1.getValue()) {
				val= h1.getValue();
			requiredChar = h1.getKey();
			}
		}
		System.out.println(hm);
		System.out.println(requiredChar+"   "+val);
		
		System.out.println("__________________________Sequential Stream_____________________________________");
		
		String strg = "1";
		if(strg.endsWith(""))
			System.out.println("hi");
		else
			System.out.println("hello");
		
		System.out.println("_________________________________________________________");
		Stream<Integer> sequentialStr = l.stream();
		sequentialStr.forEach(System.out::println);
		System.out.println();
		IntStream is = "abc".chars();
		System.out.println("__________________________Parallel Stream_____________________________________");
		Stream<Integer> parallelStream = l.parallelStream();
		parallelStream.forEach(System.out::println);
		
		Set<Integer> set = new HashSet<>();
		set.addAll(l);
		l.clear();
		l.addAll(set);
		Object a = l.clone();
		System.out.println(a);
		System.out.println(l);
		System.out.println("*********************");
		
		java.util.List<Integer> list = new ArrayList<>(new HashSet<>(l));
		System.out.println(list);
		
		
		System.out.println(l.stream().distinct().collect(Collectors.toList()));
		
		int valToRemove = 1;
		l.remove(l.indexOf(valToRemove));
		l.get(0);
		l.remove(l.get(2));
		l.contains(2);
		System.out.println(l);
		
		for(int i = l.indexOf(3); i<l.size(); i++) {
			if(3< l.get(i))
				System.out.println(l.get(i));
		}
//		Find all element greater then specified elements in a list
//		Collections.shuffle(l, new Random());
		System.out.println(l);
//		Collections.sort(l);
		System.out.println("************************************************************");
		
		List<Integer> z = l.subList(l.indexOf(3), l.size());
		System.out.println(z);
		Collections.sort(z);
		
//		List<Integer> x= z.subList(z.indexOf(7), z.size());
//		System.out.println(z.subList(z.indexOf(7), z.size()));
		
		List<Integer> xx= IntStream.range(1,  z.size())
				.mapToObj(i -> z.get(i)).collect(Collectors.toList());
		System.out.println(xx);
		
		System.out.println("************************************************************");
//		Find the smallest positive integer value that cannot be represented as sum of any subset of a given array
		java.util.List<Integer> l1 = new LinkedList<>(Arrays.asList(1,2,3)) ;
		for(int i = 0; i<l1.size() && l1.get(i)<= valToRemove; i++) {
			valToRemove += l1.get(i); 
		}
		System.out.println("Smallest positive element not found by summing list elements are :  "+valToRemove);
		
		List<Integer> l11= Arrays.asList(3,5,4,1,2);
		System.out.println(l11.stream().filter(e-> e%2 == 0).skip(0).map(i -> {return i.toString().join("-", i.toString());}));
		
//		Iterator<Integer> it = l11.iterator();
//		while (it.hasNext()) {
//			
//			Collections.sort(l11);
//			Integer value = it.next();
//			System.out.println("List Value:" + value);
////			if (value.equals(3)) {
//////				l11.remove(value);
//////				l11.add(89);
//////				Collections.sort(l11);
////				}
//		}
		
		

		for(int i = 0; i<l11.size(); i++){
			System.out.println(l11.get(i));
			if(l11.get(i).equals(3)){
				l11.remove(i);
				i--;
				l11.add(6);
			}
		}

		
	}
}
