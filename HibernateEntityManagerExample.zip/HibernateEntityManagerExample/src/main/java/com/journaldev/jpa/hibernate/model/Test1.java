package com.journaldev.jpa.hibernate.model;

public interface Test1 {
	public void check();
}
