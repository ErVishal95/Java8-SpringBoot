package com.journaldev.jpa.hibernate.model;

import java.util.function.Function;

////class Customer{
////	public Customer() {
////		System.out.println("In parent");
////	}
////}
////public class TestProgram extends Customer{
//public class TestProgram {	
//	protected TestProgram() {
//		for(int i = 0; i< 10;)
//			System.out.println(++i);
////	System.out.println("check");
//	}
////	
////	public TestProgram(int a) {
////		this();
////		super();
////		System.out.println("In Two");
////	}
//	public static void main(String[] argv) {
//////		int a= 5;
//////		System.out.println("value is:- "+((a>5)? 3 :2));
////		try {
////			int a = 100/0;
////		} catch (Exception e) {
////			System.out.println(e);
////			System.exit(0);
////		}
////		finally {
////			System.out.println("inside finally");
////		}
//	TestProgram program = new TestProgram();
////	program.aMethod();
//	}
////	public void aMethod() {
////		int x =10;
////		switch (x) {
////		default:
////			System.out.println("Default Case Block");
////			break;
////		case 10:
////			System.out.println("Ten");
//////		default:
//////			System.out.println("Default Case Block");
//////			break;
////		case 20:
////			System.out.println("Twenty");
//////			break;
//////		default:
//////			System.out.println("Default Case Block");
//////			break;
////		}
////	}
//}

//interface I1 {
//	void draw(int a, int b);
//}
//interface I2 {
//	void move(int a, int b);
//}
//interface I3 {
//	void draw(int a, int b);
//	void show(int a, int b);
//}
//
//public class TestProgram implements I1, I2, I3{
//	int value;
////	public void draw(int a, int b) {
////		value = a+b;
////	}
//	public void show(int a, int b) {
//		value = a-b;
//	}
//
//	public void move(int a, int b) {
//		value = a+b;		
//	}
//
//	public void draw(int a, int b) {
//		value = a-b;
//	}
//	public static void main(String[] args) {
//		I3 i3 = new TestProgram();
//		i3.draw(12, 35);
//	}
//}

class TestProgram {
//	static {
//		System.out.println("boy");
////		main(new String[] {});
//	}
//	
//	public TestProgram() {
//		System.out.println("cHECK");
//	}
//	{System.out.println("hi");}
//	
//	public static void add() {
//		System.out.println("Hi");
//	}
//	public static void main(String[] args) {
//		int _ = 10;
//		int x = 10_00_00;
//		TestProgram program1 = new TestProgram();
//		System.out.println(_);
//		
//		System.out.println(x);
//		
//		System.out.println("Trying to execute DeadLock in main method");
//		System.out.println('a'+ 'z');
////			Thread.currentThread().join();
////		System.out.println("Identifying DeadLock ");
//		TestProgram program = null;
//		program.add();
//		
//		String a = "vishal";
//		String b = "verma";
//		System.out.println(a = b);
//		
//		System.out.println("this is all about test "+a+(a = b));
//		
//		Function<Integer, Function<Integer, Integer>> curryAdder = q -> w -> q+w;
//		System.out.println(curryAdder.apply(2).apply(3));
//	}
	int binarySearch(int arr[], int l, int r, int x) {
		if (r>= l) {
			int mid = r+ (l-1)/2;
			
			if(arr[mid] == x)
				return mid;
			
			if(arr[mid] > x )
				return binarySearch(arr, l, mid-1, x);
			
			return binarySearch(arr, l, mid+1, x);
		}
		return -1;
	}
	public static void main(String[] args) {
		TestProgram testProgram = new TestProgram();
		int arr[]= {1,2,4,5,8};
		int n = arr.length;
		int x = 5;
		int result = testProgram.binarySearch(arr, 0, n-1, x);
		if(result == -1)
			System.out.println("Element not present");
		System.out.println("Element present at "+result);
	}
}