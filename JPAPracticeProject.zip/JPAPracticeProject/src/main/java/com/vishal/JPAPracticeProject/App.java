package com.vishal.JPAPracticeProject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.vishal.JPAPracticeProject.model.Address;
import com.vishal.JPAPracticeProject.model.Certification;
import com.vishal.JPAPracticeProject.model.Contact;
import com.vishal.JPAPracticeProject.model.Department;
import com.vishal.JPAPracticeProject.model.Emp_ExtraInfo;
import com.vishal.JPAPracticeProject.model.Employee;
import com.vishal.JPAPracticeProject.model.Project;
import com.vishal.JPAPracticeProject.model.Salary;

public class App 
{
    @SuppressWarnings("unchecked")
	public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
        System.out.println( "Hello World!" );
        
        entityManager.getTransaction().begin();
    
     // Department Object
        Department department = new Department("Software Development");
        entityManager.persist(department);

    // Project Objects
        Project project1 = new Project("Mike Albert", "S/W Development", "1235", "3 years");
        project1.setDepartment(department);
        
        Project project2 = new Project("IBS Mall", "S/W Support", "45632", "5 years");
        project2.setDepartment(department);
        
        List<Project> projects = new ArrayList<>();
        projects.add(project1);
        projects.add(project2);
        department.setProjects(projects);

    //  Employee Objects
    	Employee employee1 = new Employee("Jay", "Veeru", null);
    	Employee employee2 = new Employee("Joy", "Roy", null);
    	
//    	Emp_ExtraInfo extraInfo = new Emp_ExtraInfo(24, "B+");
    	employee1.setProject(project1);
//    	employee1.setAge(24);
//    	employee1.setBloodGroup("B+");
    	employee2.setProject(project1);
    	
    	List<Employee> employees = new ArrayList<>();
    	employees.add(employee1);
    	employees.add(employee2);
    	project1.setEmployees(employees);
    	
    //  Salary Objects
    	Salary salary = new Salary(5554.20f, Calendar.getInstance().getTime(), "10%");
    	salary.setEmployee(employee1);
    	employee1.setSalary(salary);
    
    //  Contact Objects	
    	Contact contact1 = new Contact(new Address("Major Mohit Marg", "Noida", "Uttar Pradesh", "India", 21001), 1023456789);
    	Contact contact2 = new Contact(new Address("Gandhi Marg", "New Delhi", "Delhi", "India", 0), 1042356789);
    	
     	employee1.setContact(contact1);
     	employee2.setContact(contact2);
     	
	//Certificate Object
		Certification certification1 = new Certification("Java8", "6 Months", "₹ 8999/-");
		Certification certification2 = new Certification("Spring framework", "2 Months", "₹ 5400/-");
		
		List<Certification> certifications = new ArrayList<>();
		certifications.add(certification1);
		certifications.add(certification2);
		
		employee1.setCertifications(certifications);
    	
    	entityManager.getTransaction().commit();
        System.out.println(entityManager.find(Department.class, 1));
    	System.out.println("**************************************************");
    	System.out.println("Printing Employee data here");
    	entityManager.createQuery("select e from Employee e", Employee.class).getResultList().forEach(System.out::println);
    	System.out.println();
    	System.out.println("------------------------------------------------------------");
 //   	entityManager.createQuery("select e, s from Employee e join Salary s on e.salary = s.id ")
//    							.setParameter("start", new Date(), TemporalType.DATE).
    //							.getResultList().forEach(System.out::println);
    	
    	System.out.println("********************************************");
//    	Query query = entityManager.createNativeQuery("select * from Employee e where e.First_Name like '__y' and e.Project_Id = 1");
    	Query query = entityManager.createQuery("select e from Employee e JOIN FETCH e.project",  Employee.class);
//    	Query query = entityManager.createNativeQuery("select e from Employee e", Employee.class);
		/*setParameter("start", new Date(), TemporalType.DATE).*/
//		List<Object> obj= query.getResultList();
//		for(Object o:obj) {
//		 Employee empp=(Employee) o;
//		 Salary  salll=(Salary)o;
//		 
//			System.out.println("Employee Details "+empp.toString());
//			System.out.println("Salary Details "+salll.toString());
//		}
    	
//    	Query qry = entityManager.createQuery("select s from Salary s where s.appraisalDueDate > '25-06-2019' and s.salaryAmount < 6000");
//    	Query qry = entityManager.createQuery("select avg(s.salaryAmount) from Salary s join s.employee e where e.id = 1");
//    	Query qry = entityManager.createQuery("select d from Department d JOIN FETCH d.projects p where p.p_Budget = 45632 ", Department.class);
    	Query qry = entityManager.createQuery("select p from Department d JOIN FETCH d.projects p where p.p_Budget = 45632 ", Department.class);
//				.setParameter("start", new Date(), TemporalType.DATE)
//				.setParameter("start", Calendar.getInstance().getTime(), TemporalType.DATE);
//				.setParameter("end", new Date(), TemporalType.DATE);
//qry.getResultList();
//System.out.println(qry.getResultList());
    	
    	List result = qry.getResultList();
    	System.out.println(result);
    	
    	for (Object o : result) {
            System.out.println(resultAsString(o));
        }
    	CriteriaQuery<Employee> cq= entityManager.getCriteriaBuilder().createQuery(Employee.class);
    	Root<Employee> root= cq.from(Employee.class);
    	System.out.println(entityManager.createQuery(cq).getResultList());
    	
    	System.out.println("##################################################################################");
    	System.out.println();
//    	System.out.println(employee1);
//    	Cri
    	System.out.println("##################################################################################");
    }
    private static String resultAsString(Object o) {
	    if (o instanceof Object[]) {
	        return Arrays.asList((Object[])o).toString();
	    } else {
	        return String.valueOf(o);
	    }
		
//    	Query qry = entityManager.createQuery("select s from Salary s where s.appraisalDueDate between :start and :end")
//						.setParameter("start", new Date(), TemporalType.DATE)
//						.setParameter("end", new Date(), TemporalType.DATE);
//    	qry.getResultList();
//    	System.out.println(qry.getResultList());
						
		}
}
