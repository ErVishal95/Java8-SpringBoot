package com.vishal.JPAPracticeProject.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Certification")
public class Certification {
	
	@Id @SequenceGenerator(name = "qwerty", sequenceName= "qwerty")
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "qwerty")
	private Integer courseId;
	
	private String courseName;
	private String courseDuration;
	private String fees;
	
	@ManyToMany(mappedBy = "certifications")
	private List<Employee> employees = new ArrayList<Employee>();
	
	public Certification() {}

	public Certification(String courseName, String courseDuration, String fees) {
		super();
		this.courseName = courseName;
		this.courseDuration = courseDuration;
		this.fees = fees;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public String getFees() {
		return fees;
	}

	public void setFees(String fees) {
		this.fees = fees;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return String.format("Certification [courseId=%s, courseName=%s, courseDuration=%s, fees=%s, set=%s]", courseId,
				courseName, courseDuration, fees, employees);
	}
	
}
