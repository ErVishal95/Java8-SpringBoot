package com.vishal.JPAPracticeProject.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;;

@Entity
@Table(name = "Contact")

public class Contact {

	@EmbeddedId
//	@Id @GeneratedValue
//	@JoinColumn(name = "Emp_Address")
	private Address address;
	
	@Column(name = "Contact_Number") @Size(min = 10, max = 10) @Positive
	private Integer contactNumber;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "contact")
	@JoinColumn(name = "Emp_ID")
	private Employee employee;
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Integer getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Integer contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Contact(Address address, @Size(min = 10, max = 10) @Positive Integer contactNumber) {
		super();
		this.address = address;
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return String.format("Contact [address=%s, contactNumber=%s]", address, contactNumber);
	}
	
	
}
