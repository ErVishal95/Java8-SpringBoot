package com.vishal.JPAPracticeProject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Emp_ExtraInfo {
	@Id
	@Column(name = "Age")
	private int age;
	@Column(name = "BloodGroup")
	private String bloodGroup;
	
	public Emp_ExtraInfo(int age, String bloodGroup) {
		super();
		this.age = age;
		this.bloodGroup = bloodGroup;
	}

	public Emp_ExtraInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	@Override
	public String toString() {
		return String.format("Emp_ExtraInfo [age=%s, bloodGroup=%s]", age, bloodGroup);
	}
	
	
}
