package com.vishal.JPAPracticeProject.model;

import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {
	@Id @SequenceGenerator(name = "seq", sequenceName = "seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name = "Employee_Id", nullable = false)
	private Integer id;
	
	@Column(name = "First_Name", length = 40, updatable = true)
	private String firstName;
	
	@Column(name = "Last_Name", length = 40, updatable = true)
	private String lastName;
	
	@Column(name = "Email_Id", length = 40, updatable = true)
	private String emailId;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "project_Id")
	private Project project;
	
	@OneToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER) 
	@JoinColumn(name = "Salary_Account_Id")
	private Salary salary;
	
	@OneToOne(cascade = CascadeType.ALL)
//	 @AttributeOverrides({
//	    	@AttributeOverride (name = "contact_street", column= @Column(name = "Emp_Street")),
//	    	@AttributeOverride (name = "city", column= @Column(name = "Emp_City")),
//	    	@AttributeOverride (name = "state", column= @Column(name = "Emp_State")),
//	    	@AttributeOverride (name = "zipCode", column= @Column(name = "Emp_zipCode")),
//	    	@AttributeOverride (name = "country", column= @Column(name = "Emp_Country")),
//	    })
	private Contact contact;
	
//	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "employees")
	// Using mappedBy both ends for relation will throw an error of illegal use of mappedBy on both side
//	@JoinColumn(name = "Certificate_Course_Id") 
	// Using @JoinColumn or @JOinTable will throw an error of - mappedBy can't be used along with @JOinCoulmn or @JoinTable
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Certification> certifications;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	public Employee() {
		
	}
	public Employee(String firstName, String lastName, String emailId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
	}

	public List<Certification> getCertifications() {
		return certifications;
	}

	public void setCertifications(List<Certification> certifications) {
		this.certifications = certifications;
	}

	@Override
	public String toString() {
		return String.format("Employee [id=%s, firstName=%s, lastName=%s, emailId=%s]", id, firstName, lastName,
				emailId);
	}
	
	
}
