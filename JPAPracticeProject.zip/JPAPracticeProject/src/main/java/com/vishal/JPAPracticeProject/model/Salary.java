package com.vishal.JPAPracticeProject.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Salary")
public class Salary {
	
	@Id
	@Column(name= "Salary_Seq_No")
	@SequenceGenerator(name= "sqnce", sequenceName ="sqnce")
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator= "sqnce")
	private int id;
	
	@Column(name = "Salary_Amount")
	private Float salaryAmount;
	
	@Column(name= "Appraisal_Due_Date", columnDefinition= "DATE")
	private Date appraisalDueDate;
	
	private String lastPercentageAppraisal;
	
	@OneToOne(mappedBy="salary",cascade=CascadeType.ALL)
//	@Column(name = "Emp_Id")
	private Employee employee;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Float getSalaryAmount() {
		return salaryAmount;
	}

	public void setSalaryAmount(Float salaryAmount) {
		this.salaryAmount = salaryAmount;
	}

	public Date getAppraisalDueDate() {
		return appraisalDueDate;
	}

	public void setAppraisalDueDate(Date appraisalDueDate) {
		this.appraisalDueDate = appraisalDueDate;
	}

	public String getLastPercentageAppraisal() {
		return lastPercentageAppraisal;
	}

	public void setLastPercentageAppraisal(String lastPercentageAppraisal) {
		this.lastPercentageAppraisal = lastPercentageAppraisal;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Salary() {
	}

	public Salary(Float salaryAmount, Date appraisalDueDate, String lastPercentageAppraisal) {
		super();
		this.salaryAmount = salaryAmount;
		this.appraisalDueDate = appraisalDueDate;
		this.lastPercentageAppraisal = lastPercentageAppraisal;
	}

	@Override
	public String toString() {
		return String.format(
				"Salary [id=%s, salaryAmount=%s, appraisalDueDate=%s, lastPercentageAppraisal=%s, employee=%s]", id,
				salaryAmount, appraisalDueDate, lastPercentageAppraisal, employee);
	}
}
