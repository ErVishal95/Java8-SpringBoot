package com.vishal.JPAPracticeProject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.vishal.JPAPracticeProject.model.Address;
import com.vishal.JPAPracticeProject.model.Certification;
import com.vishal.JPAPracticeProject.model.Contact;
import com.vishal.JPAPracticeProject.model.Department;
import com.vishal.JPAPracticeProject.model.Employee;
import com.vishal.JPAPracticeProject.model.Project;
import com.vishal.JPAPracticeProject.model.Salary;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	
        System.out.println( "Hello World!" );
        
        entityManager.getTransaction().begin();
    
     // Department Object
        Department department = new Department("Software Development");
//        entityManager.persist(department);

    // Project Objects
        Project project1 = new Project("Mike Albert", "S/W Development", "1235", "3 years");
        project1.setDepartment(department);
        
        Project project2 = new Project("IBS Mall", "S/W Support", "45632", "5 years");
        project2.setDepartment(department);
        
        List<Project> projects = new ArrayList<>();
        projects.add(project1);
        projects.add(project2);
        department.setProjects(projects);

    //  Employee Objects
    	Employee employee1 = new Employee("Jay", "Veeru", null);
    	Employee employee2 = new Employee("Joy", "Roy", null);
    	
    	employee1.setProject(project1);
    	employee2.setProject(project1);
    	
    	List<Employee> employees = new ArrayList<>();
    	employees.add(employee1);
    	employees.add(employee2);
    	project1.setEmployees(employees);
    	
    //  Salary Objects
    	Salary salary = new Salary(5554.20f, Calendar.getInstance().getTime(), "10%");
    	salary.setEmployee(employee1);
    	employee1.setSalary(salary);
    
    //  Contact Objects	
    	Contact contact1 = new Contact(new Address("Major Mohit Marg", "Noida", "Uttar Pradesh", "India", 21001), 1023456789);
    	Contact contact2 = new Contact(new Address("Gandhi Marg", "New Delhi", "Delhi", "India", 0), 1042356789);
    	
     	employee1.setContact(contact1);
     	employee2.setContact(contact2);
     	
	//Certificate Object
		Certification certification1 = new Certification("Java8", "6 Months", "₹ 8999/-");
		Certification certification2 = new Certification("Spring framework", "2 Months", "₹ 5400/-");
		
		List<Certification> certifications = new ArrayList<>();
		certifications.add(certification1);
		certifications.add(certification2);
		
		employee1.setCertifications(certifications);
    	
    	entityManager.getTransaction().commit();
//        System.out.println(entityManager.find(Department.class, 1));
    }
}
