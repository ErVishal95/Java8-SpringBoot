package com.vishal.JPAPracticeProject.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Embeddable
public class Address implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Column(name = "street")
	private String street;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "country")
	private String country;

	@Column(name = "zipCode")
	private int zipCode;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

//	public Address(String street, String city, String state, String country) {
//		super();
//		this.street = street;
//		this.city = city;
//		this.state = state;
//		this.country = country;
//	}
	public Address(String street, String city, String state, String country, int zipCode) {
		super();
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zipCode = zipCode;
	}	

	@Override
	public String toString() {
		return String.format("PermanentAddress [street=%s, city=%s, state=%s, country=%s, zipCode=%s]", street, city,
				state, country, zipCode);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime*result + ((street == null)? 0: street.hashCode());
		result = prime*result + zipCode;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		if(this == obj)
			return true;
		if(getClass() != obj.getClass())
			return false;
		Address another = (Address) obj;
		if(street == null) {
			if(another.street!= null)
				return false;
		}
		else if(!street.equalsIgnoreCase(another.street))
			return false;
		if(zipCode!= another.zipCode)
			return false;
		return true;
	}
}
