package com.vishal.JPAPracticeProject.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Project")
public class Project {
	
	@Id @SequenceGenerator(name = "sq", sequenceName = "sq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sq")
	@Column(name = "project_Id", nullable = false)
	private int projectId;
	
	@Column(name = "project_Name", nullable = false, length = 40, updatable = true)
	private String p_Name;
	
	@Column(name = "project_Domain", nullable = false, length = 40, updatable = true)
	private String p_Domain;
	
	@Column(name = "project_Budget", nullable = false, length = 40, updatable = true)
	private String p_Budget;
	
	@Column(name = "project_Duration", nullable = false, length = 40, updatable = true)
	private String p_Duration;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Department_Id")
	private Department department;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "project")
	private List<Employee> employees;
	
	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getP_Name() {
		return p_Name;
	}

	public void setP_Name(String p_Name) {
		this.p_Name = p_Name;
	}

	public String getP_Domain() {
		return p_Domain;
	}

	public void setP_Domain(String p_Domain) {
		this.p_Domain = p_Domain;
	}

	public String getP_Budget() {
		return p_Budget;
	}

	public void setP_Budget(String p_Budget) {
		this.p_Budget = p_Budget;
	}

	public String getP_Duration() {
		return p_Duration;
	}

	public void setP_Duration(String p_Duration) {
		this.p_Duration = p_Duration;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public Project(String p_Name, String p_Domain, String p_Budget, String p_Duration) {
		super();
		this.p_Name = p_Name;
		this.p_Domain = p_Domain;
		this.p_Budget = p_Budget;
		this.p_Duration = p_Duration;
	}

	public Project() {
	}

	@Override
	public String toString() {
		return String.format("Project [projectId=%s, p_Name=%s, p_Domain=%s, p_Budget=%s, p_Duration=%s]", projectId,
				p_Name, p_Domain, p_Budget, p_Duration);
	}
	
}