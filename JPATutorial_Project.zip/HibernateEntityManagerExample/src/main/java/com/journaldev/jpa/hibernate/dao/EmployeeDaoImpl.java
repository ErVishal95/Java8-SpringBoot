package com.journaldev.jpa.hibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.journaldev.jpa.hibernate.model.Department;
import com.journaldev.jpa.hibernate.model.Employee;

public class EmployeeDaoImpl implements EmployeeDAO {
	@PersistenceContext
	EntityManager manager;

	public List<Employee> getAllEmployees() {
		return 	manager.createQuery("Select e from Employee e", Employee.class).getResultList();
	}

	public List<Department> getAllDepartments() {
		return 	manager.createQuery("Select e from Department e", Department.class).getResultList();
	}
	
	public Department getDepartmentById(Integer id) {
		return manager.find(Department.class, id);
	}

	public void addEmployee(Employee employee) {
		//Department to be set in Employee
		manager.persist(employee);
	}
}
