package com.journaldev.jpa.hibernate.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table (name="employee")
public class Employee implements Serializable{
    private static final long serialVersionUID = 1L;
    
    @SequenceGenerator(name= "Emp_Gen", sequenceName= "Emp_Seq")
    @Id
    @GeneratedValue(generator= "Emp_Gen",  strategy=GenerationType.SEQUENCE)
    private Integer id;
    
    @Column(name = "local_date", columnDefinition = "DATE")
//    @Temporal(TemporalType.DATE)
    private  Date date;
    
    @Transient
    private String check_id;
    
//    private volatile String volatileValueChack;
    @OrderBy("Name DESC")
	private String firstName;
   
 	private String lastName;
    private String email;
     
    @Embedded
    @AttributeOverrides({
    	@AttributeOverride (name = "street", column= @Column(name = "Emp_Street")),
    	@AttributeOverride (name = "city", column= @Column(name = "Emp_City")),
    	@AttributeOverride (name = "state", column= @Column(name = "Emp_State")),
    	@AttributeOverride (name = "zipCode", column= @Column(name = "Emp_zipCode")),
    	@AttributeOverride (name = "country", column= @Column(name = "Emp_Country")),
    })
    private Address address;
    
    @OneToOne(cascade = {CascadeType.ALL}, fetch= FetchType.LAZY)
    @JoinColumn(name = "Fin_S_No")
//    @PrimaryKeyJoinColumn
    private Finance finance;
    
    @ManyToOne( fetch = FetchType.EAGER,  cascade = CascadeType.ALL)
//    @JoinColumn(name = "Dep_Id", nullable = false, unique = true, updatable = true)
    @JoinColumn(name = "Dep_Id")
    private Department department;
     
    @ManyToOne( cascade = CascadeType.ALL)
    @JoinColumn(name = "project_Id")
    private Project project;
    
    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "Employees_Certificate", 
    			joinColumns = @JoinColumn(name = "Emp_Id"), 
    			inverseJoinColumns = @JoinColumn(name = "Course_Id",  referencedColumnName = "courseId"))
    private List<Certification> certifications = new ArrayList<Certification>();
    
    public Employee() {}
      
    public Employee(String name, Department department) {
        this.firstName = name;
        this.department = department;
    }
      
    public Employee(String name) {
        this.firstName = name;
    }
 
 
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

   public Date getDate() {
		return date;
	}

	public void setDate(Date date2) {
		this.date = date2;
	}

	public String getCheck_id() {
		return check_id;
	}

	public void setCheck_id(String check_id) {
		this.check_id = check_id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

//	public String getVolatileValueChack() {
//		return volatileValueChack;
//	}
//
//	public void setVolatileValueChack(String volatileValueChack) {
//		this.volatileValueChack = volatileValueChack;
//	}
	
	public Finance getFinance() {
		return finance;
	}

	public void setFinance(Finance finance) {
		this.finance = finance;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public List<Certification> getCertifications() {
		return certifications;
	}

	public void setCertifications(List<Certification> certifications) {
		this.certifications = certifications;
	}

	@Override
    public String toString() {
        return "EmployeeVO [id=" + id + ", firstName=" + firstName
                + ", lastName=" + lastName + ", email=" + email
                + ", department=" + department + "]";
    }
	
}