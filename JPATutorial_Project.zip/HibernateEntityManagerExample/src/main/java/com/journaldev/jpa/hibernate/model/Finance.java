package com.journaldev.jpa.hibernate.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "Finance")
public class Finance {
	@Id
	@Column(name= "Seq_Number")
	@SequenceGenerator(name= "sqnce", sequenceName ="sqnce")
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator= "sqnce")
	private int id;
	private Float salary;
	
	@Column(name= "Appraisal_Due_Date", columnDefinition= "DATE")
	private Date appraisalDueDate;
	
	private String lastPercentageAppraisal;
	
	@OneToOne(mappedBy="finance",cascade=CascadeType.ALL)
	private Employee employee;
	
	public Finance() {}
	
	public Finance(Float salary, Date appraisalDueDate, String lastPercentageAppraisal) {
		this.salary = salary;
		this.appraisalDueDate = appraisalDueDate;
		this.lastPercentageAppraisal = lastPercentageAppraisal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public Date getAppraisalDueDate() {
		return appraisalDueDate;
	}

	public void setAppraisalDueDate(Date appraisalDueDate) {
		this.appraisalDueDate = appraisalDueDate;
	}

	public String getLastPercentageAppraisal() {
		return lastPercentageAppraisal;
	}

	public void setLastPercentageAppraisal(String lastPercentageAppraisal) {
		this.lastPercentageAppraisal = lastPercentageAppraisal;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return String.format("Finance [id=%s, salary=%s, appraisalDueDate=%s, lastPercentageAppraisal=%s]", id, salary,
				appraisalDueDate, lastPercentageAppraisal);
	}
	
	
}
