package com.journaldev.jpa.hibernate.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Project")
public class Project {
	
	@Id @SequenceGenerator(name = "seq", sequenceName = "seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name = "project_Id", nullable = false)
	private int projectId;
	
	@Column(name = "project_Name", nullable = false, length = 40, updatable = true)
	private String p_Name;
	
	@Column(name = "project_Domain", nullable = false, length = 40, updatable = true)
	private String p_Domain;
	
	@Column(name = "project_Budget", nullable = false, length = 40, updatable = true)
	private String p_Budget;
	
	@Column(name = "project_Duration", nullable = false, length = 40, updatable = true)
	private String p_Duration;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Employee_Project", 
				joinColumns = @JoinColumn(name = "project_Id"), 
				inverseJoinColumns = @JoinColumn(name = "Emp_Id"))
	 @OrderBy("project_Id DESC")
	private Set<Employee> employees = new HashSet<Employee>();

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getP_Name() {
		return p_Name;
	}

	public void setP_Name(String p_Name) {
		this.p_Name = p_Name;
	}

	public String getP_Domain() {
		return p_Domain;
	}

	public void setP_Domain(String p_Domain) {
		this.p_Domain = p_Domain;
	}

	public String getP_Budget() {
		return p_Budget;
	}

	public void setP_Budget(String p_Budget) {
		this.p_Budget = p_Budget;
	}

	public String getP_Duration() {
		return p_Duration;
	}

	public void setP_Duration(String p_Duration) {
		this.p_Duration = p_Duration;
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	public Project() {}
	
	public Project(String p_Name, String p_Domain, String p_Budget, String p_Duration) {
		super();
		this.p_Name = p_Name;
		this.p_Domain = p_Domain;
		this.p_Budget = p_Budget;
		this.p_Duration = p_Duration;
	}

	@Override
	public String toString() {
		return String.format("Project [projectId=%s, p_Name=%s, p_Domain=%s, p_Budget=%s, p_Duration=%s, employees=%s]",
				projectId, p_Name, p_Domain, p_Budget, p_Duration, employees);
	}
	
	
}
