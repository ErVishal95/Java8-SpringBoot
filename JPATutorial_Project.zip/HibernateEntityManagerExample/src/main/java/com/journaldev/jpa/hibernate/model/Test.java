package com.journaldev.jpa.hibernate.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
	static List<Integer> l1 = new ArrayList<Integer>(Arrays.asList(0,5,1,9));
	static List<Integer> l2 = new ArrayList<Integer>();
//	Integer.sort(l1,l2) -> l2.
	static int i =10;
	public static void main(String[] args) {
		l2 = null;
		List<Integer> l1 = new ArrayList<Integer>(Arrays.asList(0,5,1,9));
		//Comparator<Integer> asd = (x1, x2) -> x2.compareTo(x1);
		//l1.sort(asd);
//		System.out.println(l1);
//		l2 = l1.stream().sorted((a,b)-> b.compareTo(a)).collect(Collectors.toList());
//		System.out.println(l2);
		 Test1 t = new Test1() {
			 int i= 20;
			public void check() {
				System.out.println(Test.i);
				System.out.println(this.i);
			}
			
		 };
		 t.check();
//		 System.out.println(i);
		
		
	}
}
