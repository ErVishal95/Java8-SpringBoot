package com.example.demo;


import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import model.Employee;
import model.Manager;
import model.TestFunctionalInterface;

import static com.example.demo.EmployeePredicate.*;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		
		//Manager manager = null;
		Set<Employee> managerSet = Manager.getManager();
		
		//ArrayList<String> list = new ArrayList<String>();
		//  al.forEach(String -> list.add(String.getName())); 		//1st way of iteration
		//al.stream().map(Employee::getName).forEach(list::add);	//2nd way of iteration
		
		//List<String> list = al.stream().map(Employee:: getName).collect(Collectors.toList());  //3rd way of iteration
		
		List<String> list = new LinkedList<String>();
		
		for(Employee manager: managerSet) {
			if(manager == null) continue;
			else {
				list.add(manager.getName());
			}
		}
		
		Stream<String> managerName = list.stream();
		//String MNames = managerName.collect(Collectors.joining());			   //1st way of Stream joining
		//String MNames = managerName.collect(Collectors.joining(", "));		   //2nd way of Stream joining
		String MNames = managerName.collect(Collectors.joining(", ", "{","}"));	   //3rd way of Stream joining
		System.out.println(MNames);
		
		//**********************************  calculating the salary   ************************************************
		float a = 0.0f;
		for(Employee e: managerSet) {
			if(e == null) continue;
			else {
				a = a+ e.getSalary();
			}
		}
		
		
		//********************************   Implementation of functional interface    *********************************
		TestFunctionalInterface tfi = (float x) -> {if(x> 1000000.0f) 
													System.out.print("Better to use BigInteger for this huge amount ");
													return x; };
		float salary = tfi.SalarySum(a);
		System.out.println(salary);
		
		//********************************   Implementation of Predicate interface    *********************************	
		List<Employee> emplist = (List<Employee>) Manager.getAllEmployees();
		//System.out.println(emplist);
		System.out.println(filterEmployee(emplist, isAgeGreaterThen(25)));
		
		System.out.println(filterEmployee(emplist, isAgeGreaterThenAndDepartmentIs(25, "IT")));
		
		System.out.println(filterEmployee(emplist, ageGreaterThenAndLessThen(25, 35)));
		
		//****************************************   Some more Stream filters use cases   *******************************
		
		Optional<Integer> maxAge = emplist.stream().map(Employee:: getAge).max(Comparator.naturalOrder());	//Max Age
		System.out.println(maxAge);
		
		System.out.println(filterEmployee(emplist, checkAgeLesserThen(maxAge)));
		
		Optional<Integer> minAge = emplist.stream().map(Employee:: getAge).min(Comparator.naturalOrder());	//Min Age
		System.out.println(minAge);
		
		Optional<Float> maxSalary = emplist.stream().map(Employee:: getSalary).max(Comparator.naturalOrder());	//Max Age
		System.out.println(maxSalary+" "+" "+maxSalary.get()+" "+Double.valueOf(maxSalary.get()));
		
		Optional<Float> minSalary = emplist.stream().map(Employee:: getSalary).min(Comparator.naturalOrder());	//Min Age
		System.out.println(minSalary+" "+" "+minSalary.get()+" "+Double.valueOf(minSalary.get()));
		
		Optional<Float> maxSalary2 = emplist.stream().map(Employee:: getSalary).sorted(Comparator.reverseOrder()).findFirst();  // Max Salary 2nd way
		System.out.println("Max Salary using sorted(Comparator.reverOrder())- "+maxSalary2);
		
		Optional<Float> maxSalary3 = emplist.stream().map(Employee:: getSalary).reduce(Float:: max);		// Max Salary 3rd way
		System.out.println("Max Salary using reduce()- "+maxSalary3);
		
		Optional<Float> firstSalaryData1 = emplist.stream().map(Employee:: getSalary).findFirst();   	//find first unordered salary
		System.out.println("find first unordered salary "+firstSalaryData1);
		Optional<Float> firstSalaryData2 = emplist.stream().map(Employee:: getSalary).sorted().findFirst();   	//find first ordered salary
		System.out.println("find first ordered salary "+firstSalaryData2);
		System.out.println();
		
		Optional<Float> lastSalary = emplist.stream().map(Employee:: getSalary).sorted(Comparator.reverseOrder()).findFirst();  //find Last ordered salary
		System.out.println("find Last ordered Salary using sorted(Comparator.reverOrder())- "+lastSalary);
		
		Stream<Float> distinctSalaryData = emplist.stream().map(Employee:: getSalary).sorted().distinct(); 	//Distinct salary data
		distinctSalaryData.forEach(i -> System.out.println("check All distinct salary data "+i));
		System.out.println();
		
		Stream<Float> limitSalaryData = emplist.stream().map(Employee:: getSalary).sorted().limit(4); 	//Limit of salary data upto 4
		limitSalaryData.forEach(i-> System.out.println("filtered first 4 employess salary: "+i));
		System.out.println();
		//System.out.println("Limit of salary data "+limitSalaryData);
		
		long count = emplist.stream().count();
		System.out.println("Total Objects available: "+count);
		
		float salarySum = (float)emplist.stream().map(Employee:: getSalary).mapToDouble(i-> i).sum();	//Sum of Employee Salaries
		System.out.println("Salary of Employee to be paid per month is: "+salarySum);
		
		emplist.stream().map(Employee:: getSalary)
				.mapToDouble( i-> i)
				.average().ifPresent(avg -> System.out.println("Average of salary is: "+avg));		// Average of salaries 
	}

}
