package com.example.demo;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import model.Employee;

public class EmployeePredicate {
	public static Predicate<Employee> isAgeGreaterThen(int age){
		return p-> p.getAge() > age ;
	}
	
	public static Predicate<Employee> checkAgeLesserThen(Optional<Integer> age){
		return p-> p.getAge() < age.get()-20;
	}
	
	public static Predicate<Employee> isAgeGreaterThenAndDepartmentIs(int age, String department){
		return p-> p.getAge() > age && p.getDepartment().equalsIgnoreCase(department);
	}
	
	public static Predicate<Employee> ageGreaterThenAndLessThen(int age1, int age2){
		return p-> p.getAge() > age1 && p.getAge() < age2;
	}
	
	public static List<Employee> filterEmployee(List<Employee> employees, Predicate<Employee> predicate){
		return employees.stream().filter(predicate).collect(Collectors.<Employee>toList());
	}
}
