package com.example.demo;

import java.util.function.BiFunction;
import java.util.function.BinaryOperator;

public class TestBinaryOperator {
	public static void main(String[] args) {
		BinaryOperator<Integer> op1= BinaryOperator.maxBy((a, b) -> ((a>b) ? 1 : (a==b ? 0 : -1 )));
		
		System.out.println(op1.apply(12, 54));
		
		BinaryOperator<Integer> op2= BinaryOperator.minBy((a, b) -> ((a>b) ? 1 : (a==b ? 0 : -1 )));
		
		System.out.println(op2.apply(12, 54));
		
	//BinaryOperator and Function Interfaces both are similar to BiFunction Interface with some enhanced facilities.
	//BiFunction interface have apply() and andThen() methods. BinaryOperator and Function interface have these methods by default.
	//BiFunction interface also have maxBy() and mibBY() methods which computes on two operands and return the same type of result
		
		BiFunction<Integer, Integer, Integer> op3 = (a, b) -> a+b;
		op3 = op3.andThen(a -> a*2);
		System.out.println(op3.apply(2, 5));
	}
}
