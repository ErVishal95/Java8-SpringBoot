package com.example.demo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class TestPredicate {
	
	public static void main(String[] args) {
		/*
		 * Scanner sc = new Scanner(System.in); int arr_size = sc.nextInt();
		 * 
		 * int arr[] = new int[arr_size]; for(int i=0; i< arr_size; i++) { arr[i] =
		 * sc.nextInt(); } for(int i=0; i< arr_size; i++) { System.out.println(arr[i]);
		 * }
		 */
		
		List<Integer> s= Arrays.asList(1,5,6,23,45,2);
		//s.forEach(i -> System.out.println(i));
		
		Predicate<Integer> p = i -> {if(i <20) System.out.println("number should be greater then 20 "+i);
										return false; 
									};
		for(Integer i: s) {
			if(p.test(i)) System.out.println(i);
		}
	}
}
