package com.example.demo;

import java.util.function.Function;

public class Test_Function_Interface {
	public static void main(String[] args) {
		
	//********************* Function interface using Strings as arguments  ****************************
		Function<String, String> fun = s -> s.substring(2);
		fun = fun.andThen(s -> s.concat("values") );
		
		System.out.println(fun.apply(String.join(",", "result", "controler")));
		System.out.println();
		
	//********************* Function interface using Floating point Data type as arguments  ****************************
		Function<Integer, Double> f2 = a-> a*100.0;
		f2 = f2.andThen(a -> 1000/a);
		System.out.println(f2.apply(5));
		
	//********************* Function interface with null pointer exception  ****************************	
		Function<Integer, Double> f3 = a-> a/10.0;
		try {
			f3 = f3.andThen(null);
			
		} catch (Exception e) {
			System.out.println("Error is: "+e);
		}
		
		 Function<Integer, Integer> i = Function.identity(); 
		  
	        System.out.println(i); 
	}
}
