package model;

import java.util.*;
import java.util.stream.Collectors;


public class Manager {

	private static Map<Integer, Employee> mngr = new HashMap<Integer, Employee>();
	
	static {
		/*
		 * Employee e1 = new Employee("Emp1", 35, "IT", 365552); mngr.put(1, e1);
		 * Employee e2 = new Employee("M1", 45, "IT", 365552); mngr.put(2, e2); Employee
		 * e3 = new Employee("M2", 42, "Finance", 665545); mngr.put(3, e3); Employee e4
		 * = new Employee("Emp2", 35, "IT", 365552); mngr.put(4, e4); Employee e5 = new
		 * Employee("M3", 35, "Admin", 25555545); mngr.put(5, e5); Employee e6 = new
		 * Employee("Emp3", 35, "IT", 365552); mngr.put(6, e6); Employee e7 = new
		 * Employee("Manager", 35, "BackEnd", 6654566); mngr.put(7, e7);
		 */
		
		//Manager 1
		Employee e1 = new Employee("M1", 45, "IT", 365552, null);
		mngr.put(1, e1);
		Employee e2 = new Employee("Manager2", 42, "Finance", 665545, e1);
		mngr.put(2, e2);
		Employee e3 = new Employee("Manager3", 35, "Admin", 255555, e1);
		mngr.put(3, e3);
		Employee e4 = new Employee("Manager4", 35, "BackEnd", 6654566, e1);
		mngr.put(4, e4);
		
		//Manager 2
		Employee e5 = new Employee("M2", 35, "IT", 523125, null);
		mngr.put(5, e5);
		Employee e6 = new Employee("Manager5", 42, "Finance", 665545, e5);
		mngr.put(6, e6);
		Employee e7 = new Employee("Manager6", 28, "Admin", 25555, e5);
		mngr.put(7, e7);
		Employee e8 = new Employee("Manager7", 22, "BackEnd", 6654566, e5);
		mngr.put(8, e8);
	}
	
	public static Set<Employee> getManager() {
		
		//List<Employee> list = mngr.values().stream().map(Employee:: getManager).collect(Collectors.toList());
		
		Set<Employee> set = new HashSet<Employee>(mngr.values().stream().map(Employee:: getManager).collect(Collectors.toList()));
		//set.addAll(list);
		
		//list.clear();
		System.out.println(set);
		//list = set.stream().map(Employee :: getName).collect(Collectors.toList());
		//return new ArrayList<Employee>(mngr.values());
		return set;
	}
	
	public static List<Employee> getAllEmployees(){
	  
		List<Employee> empList =  new ArrayList<Employee>();
		empList.addAll(mngr.values());
		//System.out.println(empList);
		return  empList;
	}
	
	
}
