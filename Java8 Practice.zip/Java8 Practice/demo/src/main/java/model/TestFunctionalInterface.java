package model;


@FunctionalInterface
public interface TestFunctionalInterface {
	 Float SalarySum(float a);
}
