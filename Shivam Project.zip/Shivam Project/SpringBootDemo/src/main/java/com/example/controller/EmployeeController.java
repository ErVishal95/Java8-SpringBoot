package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.flywaydemo.entity.Employee;
import com.example.service.EmployeeServiceImplementation;

@RestController
@RequestMapping("/SpringBootDemo")
public class EmployeeController {
	
	@Autowired
	EmployeeServiceImplementation employeeServiceImplementation;
	
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public List<Employee> getAllEmployees() {

		return employeeServiceImplementation.getAllEmployees();
	}
	
	@GetMapping("/employee/name/{employeeName}") 
    public Employee getEmployeeByName(@PathVariable(value = "employeeName") String empName) {
		
		return employeeServiceImplementation.getEmployeeByName(empName);	
	}
		
	@GetMapping("/employee/id/{id}") 
	public Employee getEmployeeById(@PathVariable(value = "id") Long employeeId) {
		
		return employeeServiceImplementation.getEmployeeById(employeeId); 
	  }
	 
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeServiceImplementation.createEmployee(employee);
	}
	
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable(value = "id") Long employeeId)
	{
		return employeeServiceImplementation.deleteEmployee(employeeId);
	}
	
	@PutMapping("employee/{id}")
	public Employee updateEmployee(@PathVariable(value = "id") Long employeeId, @RequestBody Employee empDetails)
	{
		return employeeServiceImplementation.updateEmployee(employeeId, empDetails);
	}
	
}
