package com.example.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.flywaydemo.entity.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployees();
	
	public Employee getEmployeeByName(String name);
	
	public Employee getEmployeeById(Long employeeId);
	
	public Employee createEmployee(Employee employee);
	
	public ResponseEntity<?> deleteEmployee(Long employeeId);
	
	public Employee updateEmployee (Long employeeId, Employee empDetails);
	
}
