package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import com.example.demo.repository.EmployeeRepo;
import com.example.exception.ResourceNotFoundException;
import com.example.flywaydemo.entity.Employee;

@Repository
public class EmployeeServiceImplementation implements EmployeeService{
	
	@Autowired
	EmployeeRepo employeeRepo;
	
	@Override
	public List<Employee> getAllEmployees()
	{
		return employeeRepo.findAll();
	}
	
	@Override
	public Employee getEmployeeByName(String name)
	{
		if (employeeRepo.findByEmployeeName(name)==null)
		{
			throw new ResourceNotFoundException("Employee", "Name", name);
		}
		
		return employeeRepo.findByEmployeeName(name);
	}
	
	@Override
	public Employee getEmployeeById(Long employeeId)
	{
		return employeeRepo.findById(employeeId) .orElseThrow(()-> new
				ResourceNotFoundException("Employee", "id", employeeId)); 
	}
	
	@Override
	public Employee createEmployee(Employee employee) {
		return employeeRepo.save(employee);
	}
	
	@Override
	public ResponseEntity<?> deleteEmployee(Long employeeId){
		
		Employee employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "id", employeeId));
		employeeRepo.delete(employee);
		
		return ResponseEntity.ok().build();
	}
	
	@Override
	public Employee updateEmployee(Long employeeId, Employee empDetails) {
		Employee emp = employeeRepo.findById(employeeId)
				.orElseThrow(()-> new ResourceNotFoundException("Employee", "id", employeeId));
		emp.setEmployeeName(empDetails.getEmployeeName());
		
		Employee updateEmp = employeeRepo.save(emp);
		
		return updateEmp;
		
	}
	
}
