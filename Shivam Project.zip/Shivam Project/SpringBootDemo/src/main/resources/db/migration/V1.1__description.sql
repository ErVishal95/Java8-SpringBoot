CREATE TABLE employee (
    id  LONG PRIMARY KEY AUTO_INCREMENT,
    employeeName VARCHAR(255),
    employeeSalary INT,
    employeeAge INT,
    profileImage VARCHAR(255)
);

INSERT INTO employee (employeeName, employeeSalary, employeeAge, profileImage) VALUES ("XYZ", 2222, 22, "ABC" );