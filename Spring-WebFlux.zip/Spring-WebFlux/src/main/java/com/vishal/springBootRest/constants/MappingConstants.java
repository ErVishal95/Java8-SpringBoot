package com.vishal.springBootRest.constants;

public interface MappingConstants {
	String Employee_Root = "employees";
	String All_Existing_Employees = "getAllEmployees";
	String Find_By_Id = "employee/{id}";
	String Add_Employee = "addEmployee";
	String Update_Employee = "updateEmployee/{id}";
	String Delete_By_Id = "empToBeDeleted/{id}";
	String Delete_All_Existing = "deletedAllEmployees";
}

