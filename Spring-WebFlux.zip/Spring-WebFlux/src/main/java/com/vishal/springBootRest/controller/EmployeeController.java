//package com.vishal.springBootRest.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseStatus;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.vishal.springBootRest.constants.MappingConstants;
//import com.vishal.springBootRest.model.Employee;
//import com.vishal.springBootRest.service.EmployeeService;
//
//import reactor.core.publisher.Flux;
//import reactor.core.publisher.Mono;
//
//@RestController
//@RequestMapping(MappingConstants.Employee_Root)
//public class EmployeeController {
//	private final EmployeeService employeeService;
//
//	@Autowired
//	public EmployeeController(@Lazy EmployeeService employeeService) {
//		this.employeeService = employeeService;
//	}
//
//	@PostMapping(value = "/create")
//	@ResponseStatus(HttpStatus.CREATED)
//	@ResponseBody
//	public Mono<Employee> create(@RequestBody Employee e) {
//		return employeeService.create(e);
//	}
//
//	@RequestMapping(value = "getAllEmployees", method = RequestMethod.GET, produces = MediaType.TEXT_EVENT_STREAM_VALUE)
//	public ResponseEntity<Flux<Employee>> findAll() {
//		Flux<Employee> emps = employeeService.findAll();
//		return new ResponseEntity<Flux<Employee>>(emps, HttpStatus.OK);
//	}
//
//	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
//	public ResponseEntity<Mono<Employee>> findById(@PathVariable("id") int id) {
//		Mono<Employee> e = employeeService.findById(id);
//		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
//		return new ResponseEntity<Mono<Employee>>(e, status);
//	}
//
//	@RequestMapping(value = "Name/{name}", method = RequestMethod.GET)
//	public ResponseEntity<Flux<Employee>> findByName(@PathVariable("name") String name) {
//		Flux<Employee> e = employeeService.findByName(name);
//		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
//		return new ResponseEntity<Flux<Employee>>(e, status);
//	}
//
//	@RequestMapping(value = "/update", method = RequestMethod.PUT)
//	@ResponseStatus(HttpStatus.OK)
//	public Mono<Employee> update(@RequestBody Employee e) {
//		return employeeService.update(e);
//	}
//
//	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
//	@ResponseStatus(HttpStatus.OK)
//	public void delete(@PathVariable("id") Integer id) {
//		employeeService.delete(id).subscribe();
//	}
//
//}
