package com.vishal.springBootRest.handler;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.BodyInserters.fromPublisher;
import static org.springframework.web.reactive.function.server.ServerResponse.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.util.UriComponentsBuilder;

import com.vishal.springBootRest.model.Employee;
import com.vishal.springBootRest.service.EmployeeService;

import reactor.core.publisher.Mono;

@Component
public class EmployeeHandler {

	private final EmployeeService employeeService;
	
	@Autowired
	public EmployeeHandler(@Lazy EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	public Mono<ServerResponse> getEmployee(ServerRequest request) {
	    String id = request.pathVariable("id");
	    final Mono<Employee> employee = employeeService.findById(id);
	    return employee
	        .flatMap(emp -> ok().contentType(APPLICATION_JSON).body(fromPublisher(employee, Employee.class)))
	        .switchIfEmpty(notFound().build());
	  }
	
	public Mono<ServerResponse> createEmployee(ServerRequest request) {
		Mono<Employee> employee = request.bodyToMono(Employee.class);
		
		 return created(UriComponentsBuilder.fromPath("employee/").build().toUri())
			        .contentType(APPLICATION_JSON)
			        .body(
			            fromPublisher(
			            		employee.flatMap(employeeService::create), Employee.class));
	}

	public Mono<ServerResponse> getAllEmployees(ServerRequest request) {
		return ok().contentType(APPLICATION_JSON)
		        .body(fromPublisher(employeeService.findAll(), Employee.class));
	}

	public Mono<ServerResponse> updateEmployee(ServerRequest request) {
	    String id = request.pathVariable("id");
	    final Mono<Employee> employee = request.bodyToMono(Employee.class);
	   
	    return employeeService
	        .findById(id)
	        .flatMap(
	            old ->
	                ok().contentType(APPLICATION_JSON)
	                    .body(
	                        fromPublisher(
	                            employee
	                                .flatMap(emp -> employeeService.update(emp)),
	                            Employee.class)))
	        .switchIfEmpty(notFound().build());
	  }


	public Mono<ServerResponse> deleteById(ServerRequest request) {
		String id = request.pathVariable("id");
		return employeeService.findById(id)
		        .flatMap(emp -> noContent().build(employeeService.delete(id)))
		        .switchIfEmpty(notFound().build());
	}
	
}
