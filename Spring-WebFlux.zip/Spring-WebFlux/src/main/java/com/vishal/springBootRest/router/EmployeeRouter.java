package com.vishal.springBootRest.router;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
import static org.springframework.web.reactive.function.server.RequestPredicates.DELETE;
import static org.springframework.web.reactive.function.server.RequestPredicates.PUT;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RequestPredicates.contentType;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.vishal.springBootRest.handler.EmployeeHandler;

@Configuration
public class EmployeeRouter {

	@Bean
	public RouterFunction<ServerResponse> route(EmployeeHandler employeeHandler) {
		return RouterFunctions.route(GET("/employee/{id}").and(accept(APPLICATION_JSON)), employeeHandler::getEmployee)
				.andRoute(GET("/employees").and(accept(APPLICATION_JSON)), employeeHandler::getAllEmployees)
				.andRoute(POST("/employees").and(accept(APPLICATION_JSON)).and(contentType(APPLICATION_JSON)),
						employeeHandler::createEmployee)
				.andRoute(
						PUT("/employee/update/{id}").and(accept(APPLICATION_JSON)).and(contentType(APPLICATION_JSON)),
						employeeHandler::updateEmployee)
				.andRoute(DELETE("/employee/{id}"), employeeHandler::deleteById);
	}
}
