package com.vishal.springBootRest.service;

import com.vishal.springBootRest.model.Employee;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface EmployeeService {
	public Mono<Employee> create(Employee e);

	public Mono<Employee> findById(String id);

	public Mono<Employee> update(Employee e);

	public Mono<Void> delete(String id);

	public Flux<Employee> findAll();

	public Flux<Employee> findByName(String name);
}
