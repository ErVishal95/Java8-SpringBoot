package com.vishal.springBootRest.service;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.vishal.springBootRest.dao.EmployeeRepository;
import com.vishal.springBootRest.model.Employee;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EmployeeserviceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepo;

	@Override
	public Mono<Employee> create(Employee e) {
		return employeeRepo.save(e);
	}

	@Override
	public Mono<Employee> findById(String id) {
		return employeeRepo.findById(id);
	}

	@Override
	public Mono<Employee> update(Employee e) {
		return employeeRepo.save(e);
	}

	@Override
	public Mono<Void> delete(String id) {
		return employeeRepo.deleteById(id);
	}

	@Override
	public Flux<Employee> findAll() {
		return employeeRepo.findAll();
	}

	@Override
	public Flux<Employee> findByName(String name) {
		return employeeRepo.findByName(name);
	}

}
