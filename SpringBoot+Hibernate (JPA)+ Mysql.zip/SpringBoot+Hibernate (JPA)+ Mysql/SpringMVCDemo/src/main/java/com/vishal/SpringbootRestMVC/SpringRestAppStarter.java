package com.vishal.SpringbootRestMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan({"com.vishal.SpringbootRestMVC.controller", "com.vishal.SpringbootRestMVC.dao", "com.vishal.SpringbootRestMVC.service", "com.vishal.SpringbootRestMVC.model"})
@EnableAutoConfiguration
@SpringBootApplication(scanBasePackages = {"com.vishal"})
public class SpringRestAppStarter {
	public static void main(String[] args) {
		SpringApplication.run(SpringRestAppStarter.class, args);
	}
}
