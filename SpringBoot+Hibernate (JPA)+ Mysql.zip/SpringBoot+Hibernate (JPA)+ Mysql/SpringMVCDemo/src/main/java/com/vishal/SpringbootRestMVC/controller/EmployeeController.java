package com.vishal.SpringbootRestMVC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.vishal.SpringbootRestMVC.model.CustomErrorType;
import com.vishal.SpringbootRestMVC.model.Employee;
import com.vishal.SpringbootRestMVC.service.EmpServiceImpl;

@RestController
@RequestMapping(path = "/employees")

public class EmployeeController {

	
	  @Autowired EmpServiceImpl empServiceImpl;
	
//******************************** Get All Employees record *************************************************************************************//	  
	@GetMapping(path = "/", produces= "application/json") 
	public List<Employee> getAllEmployees(){
	   return empServiceImpl.collectAllEmployees(); 
	}

//********************************* Get Employee record by ID *************************************************************************************//
	@GetMapping(path = "/employee/{id}", produces= "application/json") 
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") int id){
		 
		if(empServiceImpl.findEmployeeById(id)== null){
			return new ResponseEntity<>(new CustomErrorType("User with Id "+ id+" not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(empServiceImpl.findEmployeeById(id), HttpStatus.OK);
	}

//********************************* Create Employee record *************************************************************************************//
	@PostMapping(path = "/addEmployee", consumes= "application/json", produces= "application/json")
	public ResponseEntity<?> creatEmployee(@RequestBody Employee employee, UriComponentsBuilder ucBuilder)
	{
	  System.out.println(employee+"   "+employee.getEmployee_name()); 
		
	  if( !empServiceImpl.isExist(employee)) {
		  return new ResponseEntity<CustomErrorType>(new CustomErrorType("User with Employee_Name- "+employee.getEmployee_name()+" already exist"), HttpStatus.CONFLICT);
	  }
	  
	  //Integer i= empServiceImpl.collectAllEmployees().size()+1; employee.setId(i);
	  empServiceImpl.addEmployee(employee);
	  
	  HttpHeaders headers = new HttpHeaders();
	  headers.setLocation(ucBuilder.path("/employees/addEmployee/{id}").buildAndExpand(employee.getId()).toUri()); 
	  return new ResponseEntity<Employee>(headers, HttpStatus.CREATED); 
	}
	 
	

//********************************* Update Employee record using ID *************************************************************************************//	
	  @PutMapping(path = "/updateEmployee/{id}", consumes = "application/json", produces= "application/json") 
	  public ResponseEntity<?> updateEmployee(@PathVariable("id") int id, @RequestBody Employee e){
		
		  Employee employee =  empServiceImpl.findEmployeeById(id);
		  if(employee== null) {
			  return new ResponseEntity<Object>(new CustomErrorType("Unable to update Employee with ID- "+id+" as Employee with such details not found"), HttpStatus.NOT_FOUND);
		  }
//		  employee.setEmployee_age(e.getEmployee_age());
//		  employee.setEmployee_name(e.getEmployee_name());
//		  employee.setEmployee_salary(e.getEmployee_salary());
//		  employee.setProfile_image(e.getProfile_image());
		  e.setId(id);
		  empServiceImpl.updateEmployee(e, id);
		  
		  return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	  
	  }
	  
	  //@DeleteMapping available for deleting the data
	//********************************* Delete Employee record using ID *************************************************************************************//	
	  @RequestMapping(value = "/empToBeDeleted/{id}", method= RequestMethod.DELETE)
	  public ResponseEntity<?> deleteEmployee(@PathVariable("id") int id){
		
		  Employee employee =  empServiceImpl.findEmployeeById(id);
		  if(employee== null) {
			  return new ResponseEntity<Object>(new CustomErrorType("Unable to delete Employee with ID- "+id+" as Employee with such details not found"), HttpStatus.NOT_FOUND);
		  }
		  
		  empServiceImpl.deleteEmployeeById(id);
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	  }

//********************************* Delete All Employee record *************************************************************************************//	
	  @DeleteMapping(path = "/deletedAllEmployees/", produces = "application/json")
	  public ResponseEntity<?> deleteAllEmployee(){
		
		empServiceImpl.deleteAllEmployee();
		return new ResponseEntity<Employee>(HttpStatus.NO_CONTENT);
	  }
}
