package com.vishal.SpringbootRestMVC.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.SpringbootRestMVC.model.Employee;

public interface EmployeeDao extends JpaRepository<Employee, Integer>{

}
