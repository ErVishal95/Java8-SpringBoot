package com.vishal.SpringbootRestMVC.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import com.vishal.SpringbootRestMVC.model.Employee;

@Repository("empdao")
public class EmployeeDaoImpl{
	
	private final EmployeeDao employeeDao;

	@Autowired
	public EmployeeDaoImpl(@Lazy EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
	
	public List<Employee> getAllEmployees(){
		return employeeDao.findAll();
	}
	
	public Optional<Employee> getEmployeeById(int id){
		if(employeeDao.existsById(id)) {
			return employeeDao.findById(id);
		}
		return null;
	}
	
	public Employee addEmployee(Employee emp){
		return employeeDao.save(emp);
	}
	
	
	  public Employee updateEmployee(Employee emp, int id){
		  if(employeeDao.existsById(id)) {
			  return employeeDao.save(emp); 
		  }
	  return null; }
	 
	
	/*
	 * public Employee updateEmployee(Employee emp){ return employeeDao.save(emp); }
	 */
	
	public void deleteEmployeeById(int id){
		if(employeeDao.existsById(id))
			employeeDao.deleteById(id);
	}
	public void deleteAllEmployee(){
		employeeDao.deleteAll();
	}
	
	/*
	 * private List<Employee> employeesList = new LinkedList<Employee>(); public
	 * List<Employee> listEmployees() { employeesList.add(new Employee(01, "Jay",
	 * 35, 652500.0, null)); employeesList.add(new Employee(02, "Vijay", 42,
	 * 522500.0, null)); employeesList.add(new Employee(03, "veeru", 36, 222500.0,
	 * null)); employeesList.add(new Employee(04, "Dany", 31, 452500.0, null));
	 * employeesList.add(new Employee(05, "Karan", 41, 852500.0, null)); return
	 * employeesList; } public List<Employee> getEmployeesList() {
	 * 
	 * //System.out.println(employeesList); return employeesList; //return
	 * listEmployees(); }
	 * 
	 * public void setEmployeesList(Employee employee) {
	 * employeesList.add(employee);
	 * 
	 * }
	 */
	

}
