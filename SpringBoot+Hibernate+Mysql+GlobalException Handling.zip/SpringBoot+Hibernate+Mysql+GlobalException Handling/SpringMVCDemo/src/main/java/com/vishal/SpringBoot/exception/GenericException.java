package com.vishal.SpringBoot.exception;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseStatus;

@Component
@ResponseStatus(HttpStatus.NOT_FOUND)
public class GenericException extends RuntimeException {
	
	private static final long serialVersionUID = -5490004891018552027L;
	private String errorMessage;
	private String errorCause;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public GenericException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}
	
	public GenericException() {
	}

	public String getErrorCause() {
		return errorCause;
	}

	public void setErrorCause(String errorCause) {
		this.errorCause = errorCause;
	}

	public GenericException(String errorMessage, String errorCause) {
		super();
		this.errorMessage = errorMessage;
		this.errorCause = errorCause;
	}
	
	
	
}
