package com.vishal.SpringBoot.exception;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GloableExceptionHandler extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(GenericException.class)
    public final ResponseEntity<Object> handleGenericException(GenericException ex, WebRequest request) {
        
        List<String> details = new ArrayList<>();
        details.add(ex.getErrorCause());
        ErrorResponse error = new ErrorResponse(ex.getErrorMessage(), details);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }
//	@ExceptionHandler
//    public ResponseEntity<ErrorResponse> handleException(GenericException ine){
//	 	List<String> details = new ArrayList<>();
//	 	details.add(ine.getErrorCause());
//	 
//	 	ErrorResponse errorResponse = new ErrorResponse();
//        errorResponse.setMessage(ine.getErrorMessage());
//        errorResponse.setDetails(details);
//       
//        return new ResponseEntity<ErrorResponse>(errorResponse,HttpStatus.NOT_FOUND);
//    }

	@ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
       
        List<String> details = new ArrayList<>();
        try {
            details.add(ex.toString());
        } catch (Exception e) {
           details.add("Server not available to process this request");
        }

        ErrorResponse error = new ErrorResponse("Please check, Its a Server Error", details);
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	 @Override
	    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
	        
	        List<String> details = new ArrayList<>();
	        for (ObjectError error : ex.getBindingResult().getAllErrors()) {
	            details.add(error.getDefaultMessage());
	        }
	        ErrorResponse error = new ErrorResponse("Validation Failed", details);
	        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	    }
	
//	@ExceptionHandler
//    public ResponseEntity<ErrorResponse> handleException(Exception ex){
//		ErrorResponse errorResponse = new ErrorResponse();
//       // errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
//        errorResponse.setMessage(ex.getMessage());
//       // errorResponse.setTimeStamp(System.currentTimeMillis());
//        return new ResponseEntity<ErrorResponse>(errorResponse,HttpStatus.BAD_REQUEST);
//    }
	
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter( MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
	    String error = ex.getParameterName() + " parameter is missing";
	    List<String> details = new ArrayList<>();
	    details.add(error);
	    ErrorResponse apiError =  new ErrorResponse(ex.getLocalizedMessage(), details);
	    return new ResponseEntity<Object>(
	      apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler({ ConstraintViolationException.class })
	public ResponseEntity<Object> handleConstraintViolation( ConstraintViolationException ex, WebRequest request) {
	    List<String> details = new ArrayList<String>();
	    for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {
	    	details.add(violation.getRootBeanClass().getName() + " " + 
	          violation.getPropertyPath() + ": " + violation.getMessage());
	    }
	    ErrorResponse apiError =  new ErrorResponse(ex.getLocalizedMessage(), details);
	    return new ResponseEntity<Object>(
	      apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}

}
