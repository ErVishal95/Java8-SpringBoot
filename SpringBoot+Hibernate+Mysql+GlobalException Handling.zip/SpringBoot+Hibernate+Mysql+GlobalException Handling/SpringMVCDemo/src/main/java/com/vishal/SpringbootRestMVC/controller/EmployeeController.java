package com.vishal.SpringbootRestMVC.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import com.vishal.SpringBoot.constants.MappingConstants;
import com.vishal.SpringbootRestMVC.model.Employee;
import com.vishal.SpringbootRestMVC.service.EmpServiceImpl;

@RestController
//@RequestMapping(path = "/employees")
@RequestMapping(MappingConstants.Employee_Root)

public class EmployeeController {
	public final EmpServiceImpl empServiceImpl;
	
	@Autowired   
	public EmployeeController(@Lazy EmpServiceImpl empServiceImpl) {
		this.empServiceImpl = empServiceImpl;
	}

// Get All Employees record 
//	@GetMapping(path = "/", produces= "application/json") 
	@GetMapping(value = MappingConstants.All_Existing_Employees, produces= "application/json") 
	public List<Employee> getAllEmployees(){
	   return empServiceImpl.collectAllEmployees();
	   //empServiceImpl.collectAllEmployees();
	}

// Get Employee record by ID
//	@GetMapping(path = "/employee/{id}", produces= "application/json") 
	@GetMapping(value = MappingConstants.Find_By_Id, produces= "application/json")
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") int id){
		return new ResponseEntity<Employee>(empServiceImpl.findEmployeeById(id), HttpStatus.OK);
	}

// Create Employee record 
//	@PostMapping(path = "/addEmployee", consumes= "application/json", produces= "application/json")
	@PostMapping(value = MappingConstants.Add_Employee, consumes= "application/json", produces= "application/json")
	public ResponseEntity<?> creatEmployee(@RequestBody Employee employee, UriComponentsBuilder ucBuilder){
		empServiceImpl.addEmployee(employee);
	  HttpHeaders headers = new HttpHeaders();
	  headers.setLocation(ucBuilder.path("/employees/employee/{id}").buildAndExpand(employee.getId()).toUri()); 
	  return new ResponseEntity<Employee>(headers, HttpStatus.CREATED); 
	}

// Update Employee record using ID 	
//	  @PutMapping(path = "/updateEmployee/{id}", consumes = "application/json", produces= "application/json") 
	  @PutMapping(value = MappingConstants.Update_Employee, consumes = "application/json", produces= "application/json")
	  public ResponseEntity<?> updateEmployee(@PathVariable("id") int id, @RequestBody Employee e){
		  e.setId(id);
		  empServiceImpl.updateEmployee(e, id);
		  return new ResponseEntity<Employee>(e,HttpStatus.OK);
	  }
//Delete Employee record using ID 	
//	  @RequestMapping(value = "/empToBeDeleted/{id}", method= RequestMethod.DELETE)
	  @RequestMapping(value = MappingConstants.Delete_By_Id, method= RequestMethod.DELETE)
	  public ResponseEntity<?> deleteEmployee(@PathVariable("id") int id){
		  empServiceImpl.deleteEmployeeById(id);
		  return new ResponseEntity<String>("Given Recored for Id:  "+id+" deleted successfully", HttpStatus.OK);
	  }

// Delete All Employee record 	
//	  @DeleteMapping(path = "/deletedAllEmployees", produces = "application/json")
	  @DeleteMapping(value = MappingConstants.Delete_All_Existing, produces = "application/json")
	  public ResponseEntity<?> deleteAllEmployee(){
		empServiceImpl.deleteAllEmployee();
		return new ResponseEntity<String>("Employee data flushed", HttpStatus.NO_CONTENT);
	  }
}
