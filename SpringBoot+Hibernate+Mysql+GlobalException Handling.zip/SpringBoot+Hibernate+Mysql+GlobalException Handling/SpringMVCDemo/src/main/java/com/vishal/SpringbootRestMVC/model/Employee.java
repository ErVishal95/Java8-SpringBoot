package com.vishal.SpringbootRestMVC.model;

import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component

@Entity
@Table(name= "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String employee_name;
	private int employee_age;
	private double  employee_salary;
	private Blob profile_image;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public int getEmployee_age() {
		return employee_age;
	}
	public void setEmployee_age(int employee_age) {
		this.employee_age = employee_age;
	}
	public double getEmployee_salary() {
		return employee_salary;
	}
	public void setEmployee_salary(double employee_salary) {
		this.employee_salary = employee_salary;
	}
	public Blob getProfile_image() {
		return profile_image;
	}
	public void setProfile_image(Blob profile_image) {
		this.profile_image = profile_image;
	}
	
	public Employee(int id, String employee_name, int employee_age, double employee_salary, Blob profile_image) {
		super();
		this.id = id;
		this.employee_name = employee_name;
		this.employee_age = employee_age;
		this.employee_salary = employee_salary;
		this.profile_image = profile_image;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", employee_name=" + employee_name + ", employee_age=" + employee_age
				+ ", employee_salary=" + employee_salary + ", profile_image=" + profile_image + "]";
	}
	
	
}
