package com.vishal.SpringbootRestMVC.model;

import java.util.*;

import com.vishal.SpringbootRestMVC.model.Employee;

public class Employees{
	private List<Employee> empList;

	public List<Employee> getEmpList() {
		if(empList.isEmpty()) {
			empList= new ArrayList<Employee>();
		}
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	
	

}
