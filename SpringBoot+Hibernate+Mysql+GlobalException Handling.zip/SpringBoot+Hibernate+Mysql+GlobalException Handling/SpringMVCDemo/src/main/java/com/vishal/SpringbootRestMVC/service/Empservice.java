package com.vishal.SpringbootRestMVC.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.vishal.SpringbootRestMVC.model.Employee;

//@Service
public interface Empservice {
	public List<Employee> collectAllEmployees();
	public Employee findEmployeeById(int id);
	public void deleteEmployeeById(int id);
	public void deleteAllEmployee();
	public void addEmployee(Employee emp);
	public Employee updateEmployee(Employee emp, int id);
	public boolean isExist(Employee employee);
	//public boolean findByName(String name);
}
