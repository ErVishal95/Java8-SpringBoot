package com.vishal.utils;
import org.springframework.stereotype.Service;
import com.vishal.SpringBoot.exception.GenericException;

@Service("commonUtils")
public class CommonUtils {

	public String getCauseForException(Throwable throwable) {
		GenericException genericException = getExceptionObject(throwable);
		return genericException.getErrorMessage()+" "+genericException.getErrorCause();
	}

	private GenericException getExceptionObject(Throwable throwable) {
		GenericException genericException;
		if(throwable instanceof GenericException) 
			genericException = (GenericException) throwable;
		else
			genericException = (GenericException) throwable.getCause();
		return genericException;
	}
}
