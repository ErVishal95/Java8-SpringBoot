package com.vishal.SpringBootRest.service;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.SpringBootRest.model.*;
 
public interface UserService  {
     
//    User findById(long id);
//     
//    User findByName(String name);
//     
//    void saveUser(User user);
//     
//    void updateUser(User user);
//     
//    void deleteUserById(long id);
// 
//    List<User> findAllUsers();
//     
//    void deleteAllUsers();
//     
//    boolean isUserExist(User user);
	
	public List<User> getAllUsers();
	public User getUserById(long id);
	public User creteOrUpdateUser(User user);
	public void deleteById(Long id);
	public boolean isUserExist(User user);
	public void saveUser(User user);
     
}