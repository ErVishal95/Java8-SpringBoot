package com.vishal.SpringBoot.constants;

public interface DummyRestApiConstants {
	String All_Employees = "http://dummy.restapiexample.com/api/v1/employeesss";
	String Fetch_Employee = "http://dummy.restapiexample.com/api/v1/employee/{id}";
	String Create_Employee = "http://dummy.restapiexample.com/api/v1/create";
	String Update_Employee = "http://dummy.restapiexample.com/api/v1/update/{id}";
	String Delete_Employee = "http://dummy.restapiexample.com/api/v1/delete/{id}";
}
