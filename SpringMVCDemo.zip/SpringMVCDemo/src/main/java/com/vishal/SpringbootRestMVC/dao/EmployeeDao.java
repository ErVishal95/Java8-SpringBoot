package com.vishal.SpringbootRestMVC.dao;

import java.util.*;

import org.springframework.stereotype.Repository;
import com.vishal.SpringbootRestMVC.model.Employee;

@Repository("empdao")
public class EmployeeDao{
	
	private   List<Employee> employeesList = new LinkedList<Employee>();
	
	public  List<Employee> listEmployees() {
		employeesList.add(new Employee(01, "Jay", 35, 652500.0, null));
		employeesList.add(new Employee(02, "Vijay", 42, 522500.0, null));
		employeesList.add(new Employee(03, "veeru", 36, 222500.0, null));
		employeesList.add(new Employee(04, "Dany", 31, 452500.0, null));
		employeesList.add(new Employee(05, "Karan", 41, 852500.0, null));
		return employeesList;
	}

	public  List<Employee> getEmployeesList() {
		
		//System.out.println(employeesList);
		return employeesList;
		//return listEmployees();
	}

	public  void setEmployeesList(Employee employee) {
		employeesList.add(employee);
		
	}
	
	

}
