package com.vishal.SpringbootRestMVC.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import com.vishal.SpringbootRestMVC.model.Employee;

@Repository("empdao")
public class EmployeeDaoImpl{
	
	private final EmployeeDao employeeDao;

	@Autowired
	public EmployeeDaoImpl(@Lazy EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
	
	public List<Employee> getAllEmployees(){
		return employeeDao.findAll();
	}
	
	public Optional<Employee> getEmployeeById(int id){
		return employeeDao.findById(id);
	}
	
	public Employee addEmployee(Employee emp){
		return employeeDao.save(emp);
	}
	
	
	public Employee updateEmployee(Employee emp, int id){
		  if(employeeDao.existsById(id))
			  return employeeDao.save(emp); 
	  return null; 
	}
	
	public void deleteEmployeeById(int id){
		if(employeeDao.existsById(id))
			employeeDao.deleteById(id);
	}
	public void deleteAllEmployee(){
		employeeDao.deleteAll();
	}
	
}
