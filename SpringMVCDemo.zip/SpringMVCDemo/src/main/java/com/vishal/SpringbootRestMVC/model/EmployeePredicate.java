package com.vishal.SpringbootRestMVC.model;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;
@Component
public class EmployeePredicate {
	
	public  Predicate<Employee> checkEmpID(int id){
	return p -> p.getId()== id;
	}
	
	public  Predicate<Employee> checkEmpName(String name){
		return p -> p.getEmployee_name().equals(name);
		}
	
	public  List<Employee> filterEmployee(List<Employee> employees, Predicate<Employee> predicate){
		return employees
				.stream()
				.filter(predicate)
				.collect(Collectors.toList());
	}
	
}
