package com.vishal.SpringbootRestMVC.service;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vishal.SpringBoot.constants.DummyRestApiConstants;
import com.vishal.SpringBoot.exception.GenericException;
import com.vishal.SpringbootRestMVC.dao.EmployeeDaoImpl;
import com.vishal.SpringbootRestMVC.dao.EmployeeDaoImpl;
import com.vishal.SpringbootRestMVC.model.Employee;
import com.vishal.SpringbootRestMVC.model.EmployeePredicate;
import com.vishal.utils.CommonUtils;
import com.vishal.utils.ExceptionCauseUtils;
import com.vishal.utils.RestTemplateUtils;

@Service("empServiceImpl")
public class EmpServiceImpl implements Empservice {

	public final EmployeeDaoImpl empdao;
	public final EmployeePredicate empPredicate;
	public final ExceptionCauseUtils exceptionCauseUtils;
	public final CommonUtils commonUtils;
	public final RestTemplateUtils restTemplateUtils;
	
	@Autowired
	public EmpServiceImpl(@Lazy EmployeeDaoImpl empdao, 
						  @Lazy EmployeePredicate empPredicate,
						  @Lazy CommonUtils commonUtils,
						  @Lazy RestTemplateUtils restTemplateUtils,
						  @Lazy ExceptionCauseUtils exceptionCauseUtils) {
		this.empdao = empdao;
		this.empPredicate = empPredicate;
		this.exceptionCauseUtils = exceptionCauseUtils;
		this.commonUtils = commonUtils;
		this.restTemplateUtils = restTemplateUtils;
	}

	@Override
	public List<Employee> collectAllEmployees() {
		List<Employee> list = null;
		list = empdao.getAllEmployees().stream().collect(Collectors.toList());
		if(list.isEmpty()) {
//			throw new GenericException("Employees record Not found", "No data found in database");
			exceptionCauseUtils.throughExceptionIfRecordNotFound("Sorry!! No Data Available in Database, Employee List is blank");
		}
		return list;
	}
	
	@Override
	public Employee findEmployeeById(int id) {
		if(empPredicate.filterEmployee(empdao.getAllEmployees(), empPredicate.checkEmpID(id)).isEmpty()) {
//			throw new GenericException("Employee Not found", "No data found in database");
			exceptionCauseUtils.throughExceptionIfEmployeeNotFound("Not Found Error!! Failed to process operation data for id "+id);
		}
		 
		return empPredicate.filterEmployee(empdao.getAllEmployees(), empPredicate.checkEmpID(id)).stream().findFirst().get();
	}

	@Override
	public void addEmployee(Employee emp) {
		if(!isExist(emp))
			throw new GenericException("Employee already exists", "Employee Already exist in database, can not add same data again");
		empdao.addEmployee(emp);
	}
	
	public Employee updateEmployee(Employee emp, int id){
		findEmployeeById(id);
		return empdao.updateEmployee(emp, id);
	}
	
	@Override
	public void deleteEmployeeById(int id) {
		findEmployeeById(id);
		empdao.deleteEmployeeById(id);
	}

	@Override
	public void deleteAllEmployee() {
		empdao.deleteAllEmployee();
	}

	@Override
	public boolean isExist(Employee employee) {
		String name= employee.getEmployee_name();
		System.out.println(name);
		return empPredicate.filterEmployee(empdao.getAllEmployees(), empPredicate.checkEmpName(name)).isEmpty();
	}
	
	@Override
	public List<Employee> getAllEmployees(){
		List<Employee> list= null;
		try {
			list = restTemplateUtils.getObjectFromApi(DummyRestApiConstants.All_Employees, Employee.class);
		} catch (Exception e) {
			exceptionCauseUtils.throughExceptionIfRecordNotFetched(commonUtils.getCauseForException(e));
		}
		return list;
	}
}
