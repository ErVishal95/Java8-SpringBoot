package com.vishal.SpringbootRestMVC.service;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vishal.SpringbootRestMVC.dao.EmployeeDao;
import com.vishal.SpringbootRestMVC.model.Employee;
import com.vishal.SpringbootRestMVC.model.EmployeePredicate;

@Service("empServiceImpl")
public class EmpServiceImpl implements Empservice {

	@Autowired
	EmployeeDao empdao;
	@Autowired
	EmployeePredicate empPredicate;
	@Autowired
	Employee emp;

	/*
	 * public static Predicate<Employee> checkEmpID(int id) { return p -> p.getId()
	 * == id; }
	 */
	/*
	 * public static Predicate<Employee> checkEmpName(String name){ return p ->
	 * p.getEmployee_name() == name; }
	 */

	@Override
	public List<Employee> collectAllEmployees() {
		List<Employee> list = empdao.getEmployeesList().stream().collect(Collectors.toList());
		//return empdao.getEmployeesList();
		return list;
	}

	@Override
	public void addEmployee(Employee emp) {
		empdao.setEmployeesList(emp);
	}

	@Override
	public void deleteEmployeeById(int id) {
		for (Employee e : empdao.getEmployeesList()) {
			if (e.getId() == id)
				empdao.getEmployeesList().remove(e);
		}
	}

	@Override
	public void deleteAllEmployee() {
		empdao.getEmployeesList().clear();
	}

	@Override
	public Employee findEmployeeById(int id) {
		//System.out.println(empPredicate.filterEmployee(collectAllEmployees(), empPredicate.checkEmpID(id)));
		if(empPredicate.filterEmployee(collectAllEmployees(), empPredicate.checkEmpID(id)).isEmpty())
			return null;
		else 
			return empPredicate.filterEmployee(collectAllEmployees(), empPredicate.checkEmpID(id)).stream().findFirst().get();
	}

	/*
	 * @Override 
	 * public boolean findByName(String name) {
	 * //System.out.println(empPredicate.filterEmployee(collectAllEmployees(),
	 * checkEmpName(name)).stream().findFirst().get());
	 * System.out.println("Print Object if present:- "+empPredicate.filterEmployee(
	 * this.collectAllEmployees(), EmployeePredicate.checkEmpName(name))); boolean
	 * flag= EmployeePredicate.filterEmployee(collectAllEmployees(),
	 * EmployeePredicate.checkEmpName(name)).isEmpty();
	 * System.out.println("Print boolean value- false, if object present:- "
	 * +empPredicate.filterEmployee(collectAllEmployees(),
	 * EmployeePredicate.checkEmpName(name)).isEmpty()); System.out.println(flag);
	 * return flag; }
	 */
	@Override
	public boolean isExist(Employee employee) {
		String name= employee.getEmployee_name();
		System.out.println(name);
		return empPredicate.filterEmployee(collectAllEmployees(), empPredicate.checkEmpName(name)).isEmpty();
	}
}
