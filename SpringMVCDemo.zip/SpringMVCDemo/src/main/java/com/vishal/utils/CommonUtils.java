package com.vishal.utils;
import java.lang.reflect.Type;
import java.util.List;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vishal.SpringBoot.exception.GenericException;

@Service("commonUtils")
public class CommonUtils {
	
	public <T> List<T> convertJSONObjectToList(JSONObject jsonObject, Class<T> requestedClassType){
		List<T> requestedObject = null;
		Type typeOfT = TypeToken.getParameterized(List.class, requestedClassType).getType();
		requestedObject =  new Gson().fromJson(jsonObject.toString(), typeOfT);
		return requestedObject;
	}
	
	public String getCauseForException(Throwable throwable) {
		GenericException genericException = getExceptionObject(throwable);
		return genericException.getErrorMessage()+" "+genericException.getErrorCause();
	}

	private GenericException getExceptionObject(Throwable throwable) {
		GenericException genericException;
		if(throwable instanceof GenericException) 
			genericException = (GenericException) throwable;
		else
			genericException = (GenericException) throwable.getCause();
		return genericException;
	}
}
