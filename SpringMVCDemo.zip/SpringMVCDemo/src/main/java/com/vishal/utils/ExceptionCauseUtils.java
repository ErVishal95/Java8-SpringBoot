package com.vishal.utils;

import java.text.MessageFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.vishal.SpringBoot.exception.GenericException;

@Service("exceptionCauseUtils")
@PropertySource("classpath:exception_messages.properties")
public class ExceptionCauseUtils {
	public final Environment env;
	private static final String SPACE = " ";
	
	@Autowired
	public ExceptionCauseUtils(@Lazy Environment env) {
		this.env = env;
	}
	
	public void throughExceptionIfEmployeeNotFound(String cause) {
		throw new GenericException(env.getProperty("FIND_BY_ID")+ SPACE, cause);
	}
	
	public void throughExceptionIfRecordNotFound(String cause) {
		throw new GenericException(env.getProperty("FIND_ALL_EMPLOYEES")+ SPACE, cause);		
	}
	
	public void throughExceptionIfRecordNotFetched(String cause) {
		throw new GenericException(env.getProperty("NOT_ABLE_TO_FETCH_DATA")+ SPACE, cause);		
	}
	
	public void throughExceptionIfAPIResultFatchFails(String apiUrl, Exception e) {
		GenericException genericException = (GenericException) e;
		throw new GenericException(MessageFormat.format(env.getProperty("RESPONSE_FETCH_FAILED"), genericException.getErrorMessage()+SPACE+genericException.getErrorCause()+SPACE+apiUrl));
	}
	
}
