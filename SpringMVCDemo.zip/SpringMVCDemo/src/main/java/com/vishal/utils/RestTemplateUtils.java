package com.vishal.utils;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.vishal.SpringBoot.exception.GenericException;

@Component
public class RestTemplateUtils {

	private CommonUtils commonUtils;
	private ExceptionCauseUtils exceptionCauseUtils;
	private final RestTemplate restTemplate;
	@SuppressWarnings("unused")
	private final Environment env;

	@Autowired
	public RestTemplateUtils(
			@Lazy CommonUtils commonUtils, 
			@Lazy ExceptionCauseUtils exceptionCauseUtils,
			@Lazy Environment env, 
			@Lazy RestTemplate restTemplate) {
		this.commonUtils = commonUtils;
		this.exceptionCauseUtils = exceptionCauseUtils;
		this.env = env;
		this.restTemplate = restTemplate;
	}

	@SuppressWarnings({ "rawtypes"})
	public <T> List<T> getObjectFromApi(String apiUrl, Class<T> requestedClassType) {
		List<T> output = null;
		try {
			
			HttpEntity entity = setHttpHeaders();
			output = (List<T>) getResponseFromDummyAPI(apiUrl, entity, requestedClassType);
		} catch (Exception e) {
			exceptionCauseUtils.throughExceptionIfAPIResultFatchFails(apiUrl, e);
		}
		return output;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HttpEntity setHttpHeaders() {

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new HttpEntity(headers);
	}

	@SuppressWarnings("rawtypes")
	private <T> List<T> getResponseFromDummyAPI(String apiUrl, HttpEntity entity, Class<T> requestedType) {
		try {
			ResponseEntity<List<T>> employeeResponse = restTemplate.exchange(apiUrl, 
					HttpMethod.GET, 
					null,
					new ParameterizedTypeReference<List<T>>() {
				});
			
			return employeeResponse.getBody();
		} catch (Exception e) {
			throw new GenericException(e.getMessage());
		}
	}

}
