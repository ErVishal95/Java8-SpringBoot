package com.vishal;

import java.time.LocalDateTime;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class DataSessionScope {
	private String name = "Session Mode";

	public DataSessionScope() {
		System.out.println("DataSession Scope has been called : "+LocalDateTime.now()+" called");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
