//package com.vishal;
//
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//
//public class MyApp {
//	public static void main(String[] args) {
//		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
//		ctx.register(MyConfiguration.class);
//		ctx.refresh();
//		
////		MyBean mb1 = ctx.getBean(MyBean.class);
////		System.out.println(mb1.hashCode());
////		
////		MyBean mb2 = ctx.getBean(MyBean.class);
////		System.out.println(mb2.hashCode());
//		
//		SingletonBean singletonBean1 = ctx.getBean(SingletonBean.class);
//		PrototypeBean prototypeBean1 = singletonBean1.getPrototypeBean();
//		
////		SingletonBean singletonBean2 = ctx.getBean(SingletonBean.class);
//		PrototypeBean prototypeBean2 = singletonBean1.getPrototypeBean();
//		
////		@Test
////		Assert.assertTrue(prototypeBean1.equals(prototypeBean2) );
////		org.springframework.util.Assert.isTrue(prototypeBean1.equals(prototypeBean2), "The same instance should vbe return");
//		ctx.close();
//	}
//}
package com.vishal;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

@Configuration
public class MyApp {

//    @Bean
//    @Scope(value= "prototype",  proxyMode = ScopedProxyMode.TARGET_CLASS)
//    public PrototypeBean prototypeBean() {
//        return new PrototypeBean();
//    }
//
//    @Bean
//    public SingletonBean singletonBean() {
//        return new SingletonBean();
//    }

    public static void main(String[] args) throws InterruptedException {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.register(MyConfiguration.class);
        context.refresh();
        SingletonBean bean = context.getBean(SingletonBean.class);
        bean.showMessage();
//        Thread.sleep(1000);

        bean = context.getBean(SingletonBean.class);
        bean.showMessage();
    }
}