package com.vishal;

public class MyBean {

	public MyBean() {
		System.out.println("MyBean instance created");
	}
 
}
