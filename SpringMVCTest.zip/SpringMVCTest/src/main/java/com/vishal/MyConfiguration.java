package com.vishal;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

@Configuration
public class MyConfiguration {
	
//	@Bean
//	@Scope(value = "prototype") / @Scope(value = "singleton")  
//	public MyBean myBean() {
//		return new MyBean();
//	}
	
	@Bean
	@Scope(value = "prototype",  proxyMode = ScopedProxyMode.TARGET_CLASS)
	public PrototypeBean prototypeBean() {
		return new PrototypeBean();
	}
	
	@Bean
//	@Scope(value = "singleton")
	public SingletonBean singletonBean() {
		return new SingletonBean();
	}
}
