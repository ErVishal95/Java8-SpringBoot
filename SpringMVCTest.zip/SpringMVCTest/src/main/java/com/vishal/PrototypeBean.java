package com.vishal;

import java.time.LocalDateTime;

public class PrototypeBean {

	
	private String dateTimeString = LocalDateTime.now().toString();

    public String getDateTime() {
        return dateTimeString;
    }
	
	public PrototypeBean() {
		System.out.println("prototype Bean scope");
	}
	
}
