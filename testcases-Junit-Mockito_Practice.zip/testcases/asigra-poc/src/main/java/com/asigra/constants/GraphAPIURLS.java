package com.asigra.constants;

public interface GraphAPIURLS {

    //All Microsoft Graph API URLs
    String ALL_USERS = "https://graph.microsoft.com/v1.0/users?$top=999&$select=id,displayName,userPrincipalName,assignedLicenses";
    String ALL_GROUPS = "https://graph.microsoft.com/v1.0/groups?$top=999&$select=id,displayName,userPrincipalName";

    //user mailbox
    String USER_MAILBOX_CHILD_FOLDER_DETAILS = "https://graph.microsoft.com/v1.0/users/%s/mailFolders/%s/childFolders?$top=999&$select=id,displayName";
    String USER_MAILBOX_FOLDER_MSGS = "https://graph.microsoft.com/v1.0/users/%s/mailFolders/%s/messages?$top=999&$select=id,subject";

    //calendar and events related data
    String USER_ROOT_CALENDARS = "https://graph.microsoft.com/v1.0/users/%s/calendars?$top=999&$select=id,name";
    String USER_CALENDAR_EVENTS = "https://graph.microsoft.com/v1.0/users/%s/calendars/%s/events?$top=999&$select=id,subject";

    //user journals
    String USER_JOURNALS = "https://graph.microsoft.com/v1.0/users/%s/messages?$search=\"kind:journals\"";

    String USER_ARCHIVE_FOLDERS_BATCH_REQUEST_URL = "users/%s/mailFolders/archivemsgfolderroot?$top=999&$select=id,displayName";

    //sharepoint
    String ALL_SHAREPOINT_ROOT_FOLDERS = "https://graph.microsoft.com/v1.0/sites?search=*&$top=999&$select=id,name,displayName,webUrl,root";
    String SHAREPOINT_SUBSITES = "https://graph.microsoft.com/v1.0/sites/%s/sites?$top=999&$select=id,name,displayName,webUrl";
    String SHAREPOINT_SUBSITE_LISTS = "https://graph.microsoft.com/v1.0/sites/%s/lists?$top=999&$select=id,name,displayName,webUrl";

    //onedrive
    String USER_ONEDRIVE_DETAILS = "https://graph.microsoft.com/v1.0/users/%s/drives/%s/root/children?$top=999&$select=id,name,webUrl";
    String USER_ONEDRIVE_ITEM_DETAILS = "https://graph.microsoft.com/v1.0/users/%s/drive/items/%s/children?$top=999&$select=id,name,webUrl";

    //batch requests
    String GRAPH_BATCH_REQUEST_URL = "https://graph.microsoft.com/v1.0/$batch";
    String GRAPH_BETA_BATCH_REQUEST_URL = "https://graph.microsoft.com/beta/$batch";

    //user mailbox batch request
    String USER_EXCHANGE_MAILBOX_BATCH_REQUEST_URL = "users/%s/mailFolders?$top=999&$select=id,displayName";

    //archive batch request
    String USER_ARCHIVE_BATCH_REQUEST_URL = "users/%s/mailFolders/archivemsgfolderroot/childFolders?$top=999&$select=id,displayName";

    String USER_ARCHIVE_SUB_FOLDERS_BATCH_REQUEST_URL = "users/%s/mailFolders/%s/childFolders?$top=999&$select=id,displayName";
    String USER_ARCHIVE_FOLDER_FILES_BATCH_REQUEST_URL = "users/%s/mailFolders/%s/messages?$top=999&$select=id,subject";

    //share point batch request
    String SHAREPOINT_SUBSITES_BATCH_REQUEST_URL = "sites/%s/sites?$top=999&$select=id,name,displayName,webUrl";
    String SHAREPOINT_SUBSITE_LISTS_BATCH_REQUEST_URL = "sites/%s/lists?$top=999&$select=id,name,displayName,webUrl";

    //one drive batch request
    String USER_ALL_ONEDRIVES_BATCH_REQUEST_URL = "users/%s/drives?$top=999&$select=id,name,webUrl";

    //root contact folders and contacts batch request
    String USER_ROOT_CONTACTS_FOLDERS_BATCH_REQUEST_URL = "users/%s/contactFolders?$top=999&$select=id,displayName";
    String USER_ROOT_CONTACTS_BATCH_REQUEST_URL = "users/%s/contacts?$top=999&$select=id,displayName";

    //folder level contact sub folders and contacts
    String USER_CONTACT_SUB_FOLDERS_BATCH_REQUEST_URL = "users/%s/contactFolders/%s/contactFolders?$top=999&$select=id,displayName";
    String USER_CONTACTS_IN_FOLDER_BATCH_REQUEST_URL = "users/%s/contactFolders/%s/contacts?$top=999&$select=id,displayName";

    //tasks
    String USER_ROOT_TASK_FOLDERS = "users/%s/outlook/taskfolders?$top=999&$select=id,name";
    String USER_FOLDER_TASKS = "users/%s/outlook/taskfolders/%s/tasks?$top=999&$select=id,subject";



}
