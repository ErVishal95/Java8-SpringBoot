package com.asigra.constants;

public interface MappingConstants {

    //Rest controller Request Mappings
    String DOMAIN_ROOT = "domain";
    String GRAPH_ROOT = "graph";
    String EWS_ROOT = "ews";

    //mappings for user and groups
    String ALL_EXISTING_USERS = "domain/{domain}/users";
    String ALL_EXISTING_GROUPS = "domain/{domain}/groups";

    //mappings for publicfolder folders
    String USER_ROOT_EXCHANGE_FOLDERS = "domain/{domain}/users/{userId}/folders";
    String SUB_FOLDERS_OF_EXCHANGE_FOLDER = "domain/{domain}/users/{userId}/folders/{folderId}/folders";
    String ALL_MESSAGES_OF_EXCHANGE_FOLDER = "domain/{domain}/users/{userId}/folders/{folderId}/files";

    //mappings for archive folders
    String ALL_USERS_WITH_ARCHIVE_ENABLED = "domain/{domain}/archive/folders/realtime/{realtime}";
    String USER_ROOT_ARCHIVE_FOLDERS = "domain/{domain}/archive/users/{userId}/folders";
    String USER_ARCHIVE_FOLDER_CONTENTS = "domain/{domain}/archive/users/{userId}/folders/{folderId}/contents";

    //mappings for sharepoint folders
    String SHARE_POINT_ROOT_FOLDERS_IN_DOMAIN = "domain/{domain}/sharepoint/realtime/{realtime}";
    String SHARE_POINT_SITE_CONTENTS = "domain/{domain}/sharepoint/{siteId}/contents";

    //mappings for onedrives folders
    String ONE_DRIVE_ROOT_FOLDERS_ALL_USERS_IN_DOMAIN = "domain/{domain}/one-drive/realtime/{realtime}";
    String ONE_DRIVE_ROOT_FOLDER_CONTENTS = "domain/{domain}/one-drive/users/{userId}/drives/{driveId}/contents";
    String ONE_DRIVE_ROOT_FOLDER_FILES = "domain/{domain}/one-drive/users/{userId}/items/{itemId}/contents";

    //mappings for public folders
    String ALL_EXISTING_PUBLIC_FOLDERS = "domain/{domain}/public-folders";
    String SUB_FOLDERS_OF_PUBLIC_FOLDER = "domain/{domain}/public-folder/folders";
    String FILES_OF_A_PUBLIC_FOLDER = "domain/{domain}/public-folder/files";

    //mappings for contact/calender/task/journals
    String USER_ROOT_CALENDARS = "domain/{domain}/users/{userId}/calendars";
    String USER_CALENDAR_EVENTS = "domain/{domain}/users/{userId}/calendars/{calendarId}";

    String USER_ROOT_CONTACTS = "domain/{domain}/users/{userId}/contacts";
    String USER_CONTACT_FOLDER_CONTENTS = "domain/{domain}/users/{userId}/contacts/{contactFolderId}";

    String USER_ROOT_TASKS = "domain/{domain}/users/{userId}/tasks";
    String USER_TASK_FOLDER_CONTENTS = "domain/{domain}/users/{userId}/tasks/{taskFolderId}";

    String USER_JOURNALS = "domain/{domain}/users/{userId}/journals";
}
