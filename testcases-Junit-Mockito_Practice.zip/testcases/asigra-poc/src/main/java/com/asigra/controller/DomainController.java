package com.asigra.controller;

import com.asigra.constants.MappingConstants;
import com.asigra.model.domain.Domain;
import com.asigra.model.domain.DomainEntity;
import com.asigra.service.DomainService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.List;

@RestController
@RequestMapping(MappingConstants.DOMAIN_ROOT)
@CrossOrigin
@Api(value = "Domain Controller")
public class DomainController {

    private static final Logger logger = LogManager.getLogger(DomainController.class);
    private final DomainService domainService;

    @Autowired
    public DomainController(@Lazy DomainService domainService) {
        this.domainService = domainService;
    }

    @ApiOperation(value = "Get properties of a domain", response = DeferredResult.class)
    @GetMapping("{domain}")
    public ResponseEntity<Object> getDomainProperties(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getDomainProperties domain api function executed for domain " + domain);
        Domain domainProperties = domainService.getDomainProperties(domain);
        logger.debug(" domainProperties " + domainProperties);
        /*http://localhost:8084/domain/asigrainc*/

        String builder = "{" +
                "\"username\"" + ":" + "\"" + domainProperties.getUserName() + "\"," +
                "\"clientid\"" + ":" + "\"" + domainProperties.getClientId() + "\"" +
                "}";
        return ResponseEntity.ok(builder);
    }

    @ApiOperation(value = "Get details of all domains available in the application ", response = DeferredResult.class)
    @GetMapping("cached")
    public ResponseEntity<Object> getCachedOneDrivesForAllDomains() {
        logger.debug(" getAllCachedOneDrives domain api function executed for all domains ");
        /*http://localhost:8084/domain/cached*/

        List<DomainEntity> domainOneDrives = domainService.getAllCachedOneDrives();
        StringBuilder builder = new StringBuilder();

        builder.append("{");
        builder.append("[");
        for (DomainEntity domainOneDrive : domainOneDrives) {
            logger.debug(" domainOneDrive " + domainOneDrive);
            builder.append("{");
            builder.append("\"domain\"" + ":" + "\"").append(domainOneDrive.getDomainName()).append("\"");
            builder.append("\"Cached drives\"" + ":" + "\"").append(domainOneDrive.getOneDrives().size()).append("\"");
            builder.append("}");
        }
        builder.append("]");
        builder.append("}");

        return ResponseEntity.ok(builder.toString());
    }
}
