package com.asigra.controller;

import com.asigra.constants.MappingConstants;
import com.asigra.model.common.File;
import com.asigra.model.publicfolder.PublicFolder;
import com.asigra.service.EWSService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

@RestController
@RequestMapping(MappingConstants.EWS_ROOT)
@PropertySource("classpath:keys.properties")
@Api(value = "EWS APIS")
public class EWSRestController {

    private static final Logger logger = LogManager.getLogger(EWSRestController.class);
    private final EWSService EWSService;
    private final Environment env;

    @Autowired
    public EWSRestController(@Lazy EWSService EWSService,
                             @Lazy Environment env) {
        this.EWSService = EWSService;
        this.env = env;
    }

    @ApiOperation(value = "Get all public folders for all users in a domain", response = PublicFolder.class)
    @GetMapping(value = MappingConstants.ALL_EXISTING_PUBLIC_FOLDERS)
    public List<PublicFolder> getPublicRootFolders(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getPublicRootFolders ews api function executed", domain);

        return EWSService.getPublicRootFolders(domain);
    }

    @GetMapping(value = MappingConstants.SUB_FOLDERS_OF_PUBLIC_FOLDER)
    @ApiOperation(value = "Get all sub-folders in a public folder", response = PublicFolder.class)
    public List<PublicFolder> getSubFoldersOfAPublicFolder(
            @ApiParam(value = "Folder Id", required = true) @RequestParam("folderId") String folderId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain) throws UnsupportedEncodingException {
        logger.debug(" getSubFoldersOfAPublicFolder ews api function executed", folderId, domain);
        folderId = URLDecoder.decode(folderId, env.getProperty("default_encoding"));
        return EWSService.getSubFoldersOfAPublicFolder(folderId, domain);
    }

    @GetMapping(value = MappingConstants.FILES_OF_A_PUBLIC_FOLDER)
    @ApiOperation(value = "Get all files in a public folder", response = File.class)
    public List<File> getAllFilesOfAPublicFolder(
            @ApiParam(value = "Folder Id", required = true) @RequestParam("folderId") String folderId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain) throws UnsupportedEncodingException {
        logger.debug(" getAllFilesOfAPublicFolder ews api function executed", folderId, domain);
        folderId = URLDecoder.decode(folderId, env.getProperty("default_encoding"));
        return EWSService.getAllFilesOfAPublicFolder(folderId, domain);
    }
}
