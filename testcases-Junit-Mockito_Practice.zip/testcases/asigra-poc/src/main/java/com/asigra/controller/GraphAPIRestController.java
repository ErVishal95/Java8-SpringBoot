package com.asigra.controller;

import com.asigra.constants.MappingConstants;
import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.common.File;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.calendar.Calendar;
import com.asigra.model.exchange.calendar.CalendarEvent;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.journal.Journal;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.sharepoint.SharePointSiteContent;
import com.asigra.model.user.User;
import com.asigra.service.DriveService;
import com.asigra.service.ExchangeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(MappingConstants.GRAPH_ROOT)
@Api(value = "Graph REST APIS")
public class GraphAPIRestController {

    private static final Logger logger = LogManager.getLogger(GraphAPIRestController.class);
    private final ExchangeService exchangeService;
    private final DriveService driveService;

    @Autowired
    public GraphAPIRestController(@Lazy ExchangeService exchangeService,
                                  @Lazy DriveService driveService) {
        this.exchangeService = exchangeService;
        this.driveService = driveService;
    }

    @ApiOperation(value = "Get all existing users in a domain", response = User.class)
    @GetMapping(value = MappingConstants.ALL_EXISTING_USERS)
    public List<User> getUserList(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getUserList exchangeService api function executed", domain);

        return exchangeService.getUserList(domain, true);
    }

    @ApiOperation(value = "Get all existing groups for all users in a domain", response = User.class)
    @GetMapping(value = MappingConstants.ALL_EXISTING_GROUPS)
    public List<User> getGroupList(
            @ApiParam(value = "Domain name", required = true) @PathVariable String domain) {
        logger.debug(" getExistingGroupList exchangeService api function executed", domain);

        return exchangeService.getGroupList(domain);
    }

    @ApiOperation(value = "Get all mail folders of a user in a domain", response = ExchangeFolder.class)
    @GetMapping(value = MappingConstants.USER_ROOT_EXCHANGE_FOLDERS)
    public List<ExchangeObject>
    getUserRootExchangeFolders(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getUserRootExchangeFolders exchangeService api function executed", userId, domain);

        return exchangeService.getUserRootExchangeFolders(userId, domain);
    }

    @ApiOperation(value = "Get all subfolders of a mailbox folder", response = ExchangeFolder.class)
    @GetMapping(value = MappingConstants.SUB_FOLDERS_OF_EXCHANGE_FOLDER)
    public List<ExchangeFolder> getMailboxSubFolders(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Folder Id", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getAllSubFoldersOfAFolder exchangeService api function executed", userId, folderId, domain);

        return exchangeService.getMailboxSubFolders(userId, folderId, domain);
    }

    @ApiOperation(value = "Get all emails in a mailbox folder", response = File.class)
    @GetMapping(value = MappingConstants.ALL_MESSAGES_OF_EXCHANGE_FOLDER)
    public List<File> getAllEmailsOfFolder(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Folder Id", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain) {
        logger.debug(" getAllEmailsOfFolder exchangeService api function executed" + " userId ", userId, folderId, domain);

        return exchangeService.getAllEmailsOfFolder(userId, folderId, domain);
    }

    @ApiOperation(value = "Get root calender folders of a user in a domain", response = Calendar.class)
    @GetMapping(value = MappingConstants.USER_ROOT_CALENDARS)
    public List<Calendar>
    getUserRootCalendars(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain
    ) {
        logger.debug(" getUserRootCalendars exchangeService api function executed", userId, domain);

        return exchangeService.getUserRootCalendars(userId, domain);
    }

    @ApiOperation(value = "Get calendar events for a calender folder of a user in a domain", response = CalendarEvent.class)
    @GetMapping(value = MappingConstants.USER_CALENDAR_EVENTS)
    public List<CalendarEvent>
    getUserCalendarEvents(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain,
            @ApiParam(value = "Calendar Id", required = true) @PathVariable("calendarId") String calendarId) {
        logger.debug(" getUserCalenders exchangeService api function executed", userId, domain);

        return exchangeService.getUserCalendarEvents(userId, domain, calendarId);
    }

    @ApiOperation(value = "Get journals of a user in a domain", response = Journal.class)
    @GetMapping(value = MappingConstants.USER_JOURNALS)
    public List<Journal>
    getUserJournals(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain
    ) {
        logger.debug(" getUserJournals exchangeService api function executed", userId, domain);

        return exchangeService.getUserJournals(userId, domain);
    }

    @ApiOperation(value = "Get user contact subfolders and root contacts of a user in a domain", response = ContactObject.class)
    @GetMapping(value = MappingConstants.USER_ROOT_CONTACTS)
    public List<ContactObject>
    getUserRootContacts(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain
    ) {
        logger.debug(" getUserRootContacts exchangeService api function executed", userId, domain);
        return exchangeService.getUserContactFolderContents(userId, domain, null);
    }

    @ApiOperation(value = "Get contact sub folders and contacts in a contact folder of a user in a domain", response = ContactObject.class)
    @GetMapping(value = MappingConstants.USER_CONTACT_FOLDER_CONTENTS)
    public List<ContactObject>
    getUserContactFolderContents(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain,
            @ApiParam(value = "Contact folder Id", required = true) @PathVariable("contactFolderId") String contactFolderId) {
        logger.debug(" getUserContactFolderContents exchangeService api function executed", userId, domain);

        return exchangeService.getUserContactFolderContents(userId, domain, contactFolderId);
    }

    @ApiOperation(value = "Get tasks folders of a user in a domain", response = ContactObject.class)
    @GetMapping(value = MappingConstants.USER_ROOT_TASKS)
    public List<TaskObject>
    getUserRootTasks(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain
    ) {
        logger.debug(" getUserRootTasks exchangeService api function executed", userId, domain);

        return exchangeService.getUserTaskFolderContents(userId, domain, null);
    }

    @ApiOperation(value = "Get tasks folders and tasks for a task folder of a user in a domain", response = ContactObject.class)
    @GetMapping(value = MappingConstants.USER_TASK_FOLDER_CONTENTS)
    public List<TaskObject>
    getUserTaskFolderContents(
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Domain Name", required = true) @PathVariable("domain") String domain,
            @ApiParam(value = "Task folder Id", required = true) @PathVariable("taskFolderId") String taskFolderId) {
        logger.debug(" getUserTaskFolderContents exchangeService api function executed", userId, domain);

        return exchangeService.getUserTaskFolderContents(userId, domain, taskFolderId);
    }


    @ApiOperation(value = "Get users in a domain who have archive enabled", response = User.class)
    @GetMapping(value = MappingConstants.ALL_USERS_WITH_ARCHIVE_ENABLED)
    public List<User> getUsersHavingArchiveFolders(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "Is Updated Details Required", required = true) @PathVariable boolean realtime) {
        logger.debug(" getUsersHavingArchiveFolder exchangeService api function executed", domain, realtime);

        return exchangeService.getUsersHavingArchiveFolders(domain, realtime);
    }

    @ApiOperation(value = "Get all root archive folders for a user in a domain", response = ArchiveObject.class)
    @GetMapping(value = MappingConstants.USER_ROOT_ARCHIVE_FOLDERS)
    public List<ArchiveObject> getUserRootArchiveFolders(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId) {
        logger.debug(" getUserRootArchiveFolders exchangeService api function executed", domain, userId);

        return exchangeService.getUserRootArchiveFolders(domain, userId);
    }

    @ApiOperation(value = "Get folders and files for an archive folder of a user in a domain", response = ArchiveObject.class)
    @GetMapping(value = MappingConstants.USER_ARCHIVE_FOLDER_CONTENTS)
    public List<ArchiveObject> getUserArchiveFolderContents(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "User Id", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Folder Id", required = true) @PathVariable("folderId") String folderId) {
        logger.debug(" getUserArchiveFolderContents exchangeService api function executed", domain, userId, folderId);

        return exchangeService.getUserArchiveFolderContents(domain, userId, folderId);
    }

    @ApiOperation(value = "Get all SharePoint root folders for all users in a domain", response = SharePoint.class)
    @GetMapping(value = MappingConstants.SHARE_POINT_ROOT_FOLDERS_IN_DOMAIN)
    public List<SharePoint> getSharePointRootFoldersInADomain(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "Is Updated Details Required", required = true) @PathVariable boolean realtime) {
        logger.debug(" getSharePointRootFoldersInADomain exchangeService api function executed", domain, realtime);

        return driveService.getSharePointRootFoldersInDomain(domain, realtime);
    }

    @ApiOperation(value = "Get SharePoint root publicfolder contents", response = SharePointSiteContent.class)
    @GetMapping(value = MappingConstants.SHARE_POINT_SITE_CONTENTS)
    public List<SharePointSiteContent> getSharePointSiteContents(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "Site Id", required = true) @PathVariable String siteId) {
        logger.debug(" getSharePointSiteContents exchange service function executed", domain, siteId);

        return driveService.getSharePointSiteContents(domain, siteId);

    }

    @ApiOperation(value = "Get all OneDrive root folders for all users in a domain", response = OneDrive.class)
    @GetMapping(value = MappingConstants.ONE_DRIVE_ROOT_FOLDERS_ALL_USERS_IN_DOMAIN)
    public List<OneDrive> getOneDriveRootFoldersForAllUsersInADomain(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "Is Updated Details Required", required = true) @PathVariable boolean realtime) {
        logger.debug(" getOneDriveRootFoldersForAllUsersInADomain exchange service function executed", domain);

        return driveService.getOneDriveRootFoldersForAllUsersInDomain(domain, realtime);

    }

    @ApiOperation(value = "Get all OneDrive folders present in the root folder", response = OneDrive.class)
    @GetMapping(value = MappingConstants.ONE_DRIVE_ROOT_FOLDER_CONTENTS)
    public List<OneDrive> getContentsOfTheRootDrive(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "User Id", required = true) @PathVariable String userId,
            @ApiParam(value = "Drive Id", required = true) @PathVariable String driveId) {
        logger.debug(" getOneDriveFilesOfAFolder exchangeService api function executed", domain, userId, driveId);

        return driveService.getContentsOfTheRootDrive(userId, driveId, domain);
    }

    @ApiOperation(value = "Get all OneDrive files present in a OneDrive folder", response = OneDrive.class)
    @GetMapping(value = MappingConstants.ONE_DRIVE_ROOT_FOLDER_FILES)
    public List<OneDrive> getOneDriveFilesOfAFolder(
            @ApiParam(value = "Domain Name", required = true) @PathVariable String domain,
            @ApiParam(value = "User Id", required = true) @PathVariable String userId,
            @ApiParam(value = "Drive Id", required = true) @PathVariable String itemId) {
        logger.debug(" getOneDriveFilesOfAFolder exchangeService api function executed", domain, userId, itemId);

        return driveService.getContentsOfOneDriveFolder(userId, itemId, domain);
    }
}
