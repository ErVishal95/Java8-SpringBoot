package com.asigra.exception;

public class AccessTokenInvalidException extends RuntimeException {
    public AccessTokenInvalidException(String exception) {
        super(exception);
    }
}
