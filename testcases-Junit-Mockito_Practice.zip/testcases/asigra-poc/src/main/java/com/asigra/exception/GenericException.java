package com.asigra.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class GenericException extends RuntimeException {
    private String error;
    private String errorCause;

    public GenericException(String error) {
        super(error);
        this.error = error;
    }

    public GenericException(String error, String errorCause) {
        super(error);
        this.error = error;
        this.errorCause = errorCause;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getErrorCause() {
        return errorCause;
    }

    public void setErrorCause(String errorCause) {
        this.errorCause = errorCause;
    }
}