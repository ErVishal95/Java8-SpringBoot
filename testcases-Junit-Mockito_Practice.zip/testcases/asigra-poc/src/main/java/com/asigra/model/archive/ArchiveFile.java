package com.asigra.model.archive;

import com.asigra.model.common.File;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a archive file in a domain")
public class ArchiveFile extends File {
    public ArchiveFile() {
    }

    public ArchiveFile(String id, String subject) {
        super(id, subject);
    }
}
