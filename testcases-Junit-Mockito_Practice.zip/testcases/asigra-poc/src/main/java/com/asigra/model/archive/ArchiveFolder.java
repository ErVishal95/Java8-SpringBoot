package com.asigra.model.archive;

import com.asigra.model.common.Folder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of archive folder in a domain")
public class ArchiveFolder extends Folder {
    public ArchiveFolder() {
    }

    public ArchiveFolder(String id, String displayName) {
        super(id, displayName);
    }
}
