package com.asigra.model.archive;

import com.asigra.model.common.File;
import com.asigra.model.common.Folder;
import com.asigra.model.common.batch.BatchOutput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about child folders and files in a archive folder")
public class ArchiveObject implements BatchOutput {
    List<Folder> archiveFolderList = new ArrayList<>();
    List<File> archiveFileList = new ArrayList<>();

    public List<Folder> getArchiveFolderList() {
        return archiveFolderList;
    }

    public void setArchiveFolderList(List<Folder> archiveFolderList) {
        this.archiveFolderList = archiveFolderList;
    }

    public List<File> getArchiveFileList() {
        return archiveFileList;
    }

    public void setArchiveFileList(List<File> archiveFileList) {
        this.archiveFileList = archiveFileList;
    }
}
