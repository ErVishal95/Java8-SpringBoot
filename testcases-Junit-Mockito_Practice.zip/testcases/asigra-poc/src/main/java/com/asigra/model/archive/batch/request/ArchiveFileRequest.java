package com.asigra.model.archive.batch.request;

import com.asigra.model.common.batch.BatchRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the ArchiveFile batch request")
public class ArchiveFileRequest extends BatchRequest {
    public ArchiveFileRequest() {
    }

    public ArchiveFileRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
