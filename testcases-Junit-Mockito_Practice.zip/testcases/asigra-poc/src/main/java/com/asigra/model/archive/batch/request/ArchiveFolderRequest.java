package com.asigra.model.archive.batch.request;

import com.asigra.model.common.batch.BatchRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the ArchiveFolder batch request")
public class ArchiveFolderRequest extends BatchRequest {
    public ArchiveFolderRequest() {
    }

    public ArchiveFolderRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
