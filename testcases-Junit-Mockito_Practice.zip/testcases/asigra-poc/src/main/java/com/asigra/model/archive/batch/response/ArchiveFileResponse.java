package com.asigra.model.archive.batch.response;

import com.asigra.model.common.batch.BatchResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the ArchiveFolder batch response")
public class ArchiveFileResponse extends BatchResponse {
    public ArchiveFileResponse() {
    }

    public ArchiveFileResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
