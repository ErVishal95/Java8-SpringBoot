package com.asigra.model.archive.batch.response;

import com.asigra.model.common.batch.BatchResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the ArchiveFolder batch response")
public class ArchiveFolderResponse extends BatchResponse {
    public ArchiveFolderResponse() {
    }

    public ArchiveFolderResponse(String id, String status, Body body) {
        super(id, status, body);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
