package com.asigra.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a OneDrive")
public class Drive {

    @ApiModelProperty(notes = "Id of the OneDrive")
    private String id;

    @ApiModelProperty(notes = "Name of the OneDrive")
    private String name;

    @ApiModelProperty(notes = "URL of the OneDrive")
    private String webUrl;

    @ApiModelProperty(notes = "User Id of the cached OneDrive")
    private String oneDriveUserId;

    public Drive() {
    }

    public Drive(String id, String name, String webUrl, String oneDriveUserId) {
        this.id = id;
        this.name = name;
        this.webUrl = webUrl;
        this.oneDriveUserId = oneDriveUserId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getOneDriveUserId() {
        return oneDriveUserId;
    }

    public void setOneDriveUserId(String oneDriveUserId) {
        this.oneDriveUserId = oneDriveUserId;
    }
}
