package com.asigra.model.common;

import com.asigra.model.common.batch.BatchOutputEntry;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a file")
public class File implements BatchOutputEntry {

    @ApiModelProperty(notes = "Id of the file")
    private String id;

    @ApiModelProperty(notes = "Name of the file")
    private String subject;

    public File() {
    }

    public File(String id, String subject) {
        this.id = id;
        this.subject = subject;
    }

    public File(Builder builder) {
        this.id = builder.id;
        this.subject = builder.subject;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "File{" +
                "id='" + getId() + '\'' +
                ", subject='" + getSubject() + '\'' +
                '}';
    }

    public static class Builder {
        private String id;
        private String subject;

        private Builder() {
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public File build() {
            return new File(this);
        }
    }
}
