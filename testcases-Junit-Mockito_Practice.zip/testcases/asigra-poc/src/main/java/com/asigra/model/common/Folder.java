package com.asigra.model.common;

import com.asigra.model.common.batch.BatchOutputEntry;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a folder")
public class Folder implements BatchOutputEntry {

    @ApiModelProperty(notes = "Id of the folder")
    private String id;
    @ApiModelProperty(notes = "Display name of the folder")
    private String displayName;

    public Folder() {
    }

    public Folder(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
    }

    public Folder(Builder builder) {
        this.id = builder.id;
        this.displayName = builder.displayName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return "Folder{" +
                "id='" + getId() + '\'' +
                ", displayName='" + getDisplayName() + '\'' +
                '}';
    }

    public static class Builder {
        private String id;
        private String displayName;

        private Builder() {
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setDisplayName(String displayName) {
            this.displayName = displayName;
            return this;
        }

        public Folder build() {
            return new Folder(this);
        }
    }
}
