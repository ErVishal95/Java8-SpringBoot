package com.asigra.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a SharePoint")
public class Share extends Folder {

    @ApiModelProperty(notes = "URL of the SharePoint")
    private String webUrl;

    public Share() {

    }

    public Share(String webUrl) {
        this.webUrl = webUrl;
    }

    public Share(String id, String displayName, String webUrl) {
        super(id, displayName);
        this.webUrl = webUrl;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }
}
