package com.asigra.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a SharePoint content")
public class SharePointContent extends Share {

    @ApiModelProperty(notes = "Name of the SharePoint content")
    String name;

    public SharePointContent(String name, String webUrl) {
        super(webUrl);
        this.name = name;
    }

    public SharePointContent(String id, String name, String displayName, String webUrl) {
        super(id, displayName, webUrl);
        this.name = name;
    }

    public SharePointContent(Builder builder) {
        this.setId(builder.id);
        this.name = builder.name;
        this.setDisplayName(builder.displayName);
        this.setWebUrl(builder.webUrl);
    }

    public static class Builder {
        private String id;
        private String name;
        private String displayName;
        private String webUrl;

        private Builder() {
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setDisplayName(String displayName) {
            this.displayName = displayName;
            return this;
        }

        public Builder setWebUrl(String webUrl) {
            this.webUrl = webUrl;
            return this;
        }

        public SharePointContent build() {
            return new SharePointContent(this);
        }
    }

}
