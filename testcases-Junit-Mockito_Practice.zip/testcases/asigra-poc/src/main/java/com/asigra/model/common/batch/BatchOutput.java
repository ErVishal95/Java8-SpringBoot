package com.asigra.model.common.batch;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Output type for batch response")
public interface BatchOutput {
}
