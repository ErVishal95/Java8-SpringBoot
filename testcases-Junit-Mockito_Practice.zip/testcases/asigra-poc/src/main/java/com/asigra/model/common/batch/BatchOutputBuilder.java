package com.asigra.model.common.batch;

import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.common.File;
import com.asigra.model.common.Folder;
import com.asigra.model.common.SharePointContent;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.task.TaskFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.sharepoint.SharePointSiteContent;

public class BatchOutputBuilder {

    private BatchOutputBuilder() {

    }
    public static class Builder {
        ExchangeObject exchangeObject = new ExchangeObject();
        ContactObject contactObject = new ContactObject();
        ArchiveObject archiveObject = new ArchiveObject();
        TaskObject taskObject = new TaskObject();
        SharePointSiteContent sharePointSiteContent = new SharePointSiteContent();

        private Builder() {
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public ExchangeObject getExchangeObject() {
            return this.exchangeObject;
        }

        public ContactObject getContactObject() {
            return this.contactObject;
        }

        public ArchiveObject getArchiveObject() {
            return this.archiveObject;
        }

        public TaskObject getTaskObject() {
            return this.taskObject;
        }

        public SharePointSiteContent getSharePointSiteContent() {
            return this.sharePointSiteContent;
        }

        public Builder buildExchangeObjectFolderList(Folder exchangeFolder) {
            this.exchangeObject.getExchangeFolderList().add(exchangeFolder);
            return this;
        }

        public Builder buildContactObjectFolderList(Folder contactFolder) {
            this.contactObject.getContactFolders().add(contactFolder);
            return this;
        }

        public Builder buildContactObjectContactList(Folder contact) {
            this.contactObject.getContacts().add(contact);
            return this;
        }

        public Builder buildArchiveObjectFolderList(Folder archiveFolder) {
            this.archiveObject.getArchiveFolderList().add(archiveFolder);
            return this;
        }

        public Builder buildArchiveObjectFileList(File archiveFile) {
            this.archiveObject.getArchiveFileList().add(archiveFile);
            return this;
        }

        public Builder buildTaskObjectFolderList(TaskFolder taskFolder) {
            this.taskObject.getTaskFolders().add(taskFolder);
            return this;
        }

        public Builder buildTaskObjectTaskList(File task) {
            this.taskObject.getTasks().add(task);
            return this;
        }

        public Builder buildSharePointSiteContentSubSites(SharePointContent subSite) {
            this.sharePointSiteContent.getSubSites().add(subSite);
            return this;
        }

        public Builder buildSharePointSiteContentLists(SharePointContent list) {
            this.sharePointSiteContent.getLists().add(list);
            return this;
        }
    }

}
