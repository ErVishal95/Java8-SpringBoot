package com.asigra.model.common.batch;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Batch output entry type for batch response")
public interface BatchOutputEntry {
}
