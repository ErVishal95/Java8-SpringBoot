package com.asigra.model.common.batch;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the batch request")
public class BatchRequest {
    @ApiModelProperty(notes = "Id of the batch request")
    private String id;

    @ApiModelProperty(notes = "Graph REST API URL")
    private String url;

    @ApiModelProperty(notes = "Graph REST API Request Method (GET/POST")
    private String method;

    protected BatchRequest() {
    }

    protected BatchRequest(String id, String url, String method) {
        this.id = id;
        this.url = url;
        this.method = method;
    }

    private String getId() {
        return id;
    }

    private String getUrl() {
        return url;
    }

    private String getMethod() {
        return method;
    }

    @Override
    public String toString() {
        return "BatchRequest{" +
                "id='" + getId() + '\'' +
                ", url='" + getUrl() + '\'' +
                ", method='" + getMethod() + '\'' +
                '}';
    }
}
