package com.asigra.model.common.batch;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about the batch response")
public class BatchResponse {

    @ApiModelProperty(notes = "Id of the batch response")
    private String id;

    @ApiModelProperty(notes = "Status of the batch request")
    private String status;

    @ApiModelProperty(notes = "Output of the batch request")
    private Body body;

    protected BatchResponse() {
    }

    protected BatchResponse(String id, String status, Body body) {
        this.id = id;
        this.status = status;
        this.body = body;
    }

    public String getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }

    public Body getBody() {
        return body;
    }

    @Override
    public String toString() {
        return "BatchResponse{" +
                "id='" + id + '\'' +
                ", status='" + status + '\'' +
                ", body=" + body +
                '}';
    }

    public class Body {
        List<Value> value;

        public List<Value> getValue() {
            return value;
        }

        @Override
        public String toString() {
            return "Body{" +
                    "value=" + value +
                    '}';
        }
    }

    public class Value {
        String id;
        String name;
        String displayName;
        String subject;
        String webUrl;

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getSubject() {
            return subject;
        }

        public String getWebUrl() {
            return webUrl;
        }

        @Override
        public String toString() {
            return "Value{" +
                    "id='" + id + '\'' +
                    ", name='" + name + '\'' +
                    ", displayName='" + displayName + '\'' +
                    ", subject='" + subject + '\'' +
                    ", webUrl='" + webUrl + '\'' +
                    '}';
        }
    }

}
