package com.asigra.model.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import microsoft.exchange.webservices.data.core.ExchangeService;

@ApiModel(description = "All details of a domain")
public class Domain {

    @ApiModelProperty(notes = "Name of the domain")
    private String domainName;

    @ApiModelProperty(notes = "Client Id of the domain")
    private String clientId;

    @ApiModelProperty(notes = "Client secret of the domain")
    private String clientSecret;

    @ApiModelProperty(notes = "Name of the admin user of the domain")
    private String userName;

    @ApiModelProperty(notes = "Password of the admin user of the domain")
    private String password;

    @ApiModelProperty(notes = "Access token of the domain")
    private String accessToken;

    @ApiModelProperty(notes = "Access token of task for the domain")
    private String taskAccessToken;

    @ApiModelProperty(notes = "EWS service object of the domain")
    private ExchangeService exchangeEWSService;

    public Domain() {
    }

    public Domain(String domainName, String clientId, String clientSecret, String userName, String password) {
        this.domainName = domainName;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.userName = userName;
        this.password = password;
    }

    public String getDomainName() {
        return domainName;
    }

    public String getClientId() {
        return clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTaskAccessToken() {
        return taskAccessToken;
    }

    public void setTaskAccessToken(String taskAccessToken) {
        this.taskAccessToken = taskAccessToken;
    }

    public ExchangeService getExchangeEWSService() {
        return exchangeEWSService;
    }

    public void setExchangeEWSService(ExchangeService exchangeEWSService) {
        this.exchangeEWSService = exchangeEWSService;
    }

    @Override
    public String toString() {
        return "Domain{" +
                "domainName='" + domainName + '\'' +
                ", clientId='" + clientId + '\'' +
                ", clientSecret='" + clientSecret + '\'' +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
