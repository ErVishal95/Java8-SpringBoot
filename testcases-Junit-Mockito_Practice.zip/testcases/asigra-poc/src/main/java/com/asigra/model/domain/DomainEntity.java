package com.asigra.model.domain;

import com.asigra.model.drive.OneDrive;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.user.User;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "domain", uniqueConstraints = {
        @UniqueConstraint(columnNames = "domain_id")})
@ApiModel(description = "All details of a domain cached in the application")
public class DomainEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "domain_id", unique = true, nullable = false)
    @ApiModelProperty(notes = "Id of the cached domain")
    private Long id;

    @Column(name = "domain_name")
    @ApiModelProperty(notes = "Name of the cached domain")
    private String domainName;

    @OneToMany(
            fetch = FetchType.EAGER,
            mappedBy = "domainEntity",
            cascade = CascadeType.ALL)
    @Fetch(value = FetchMode.SUBSELECT)
    @ApiModelProperty(notes = "List of all cached OneDrives in the domain")
    private List<OneDrive> oneDrives = new ArrayList<>();

    @OneToMany(
            fetch = FetchType.EAGER,
            mappedBy = "domainEntity",
            cascade = CascadeType.ALL)
    @Fetch(value = FetchMode.SUBSELECT)
    @ApiModelProperty(notes = "List of all cached SharePoints in the domain")
    private List<SharePoint> sharePoints = new ArrayList<>();

    @OneToMany(
            fetch = FetchType.EAGER,
            mappedBy = "domainEntity",
            cascade = CascadeType.ALL)
    @Fetch(value = FetchMode.SUBSELECT)
    @ApiModelProperty(notes = "List of all cached users with archive folders in the domain")
    private List<User> usersWithArchiveFolders = new ArrayList<>();

    public DomainEntity() {
        //Create a default object
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public List<OneDrive> getOneDrives() {
        return oneDrives;
    }

    public void setOneDrives(List<OneDrive> oneDrives) {
        this.oneDrives = oneDrives;
    }

    public List<SharePoint> getSharePoints() {
        return sharePoints;
    }

    public void setSharePoints(List<SharePoint> sharePoints) {
        this.sharePoints = sharePoints;
    }

    public List<User> getUsersWithArchiveFolders() {
        return usersWithArchiveFolders;
    }

    public void setUsersWithArchiveFolders(List<User> usersWithArchiveFolders) {
        this.usersWithArchiveFolders = usersWithArchiveFolders;
    }
}

