package com.asigra.model.drive;

import com.asigra.model.common.batch.BatchOutput;
import com.asigra.model.domain.DomainEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "domain_one_drives")
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a OneDrive")
public class OneDrive implements BatchOutput {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    @JsonIgnore
    private Long identifier;

    @Column(name = "one_drive_id")
    @ApiModelProperty(notes = "Id of the cached OneDrive")
    private String id;

    @Column(name = "one_drive_name")
    @ApiModelProperty(notes = "Name of the cached OneDrive")
    private String name;

    @Column(name = "one_drive_url")
    @ApiModelProperty(notes = "URL of the cached OneDrive")
    private String webUrl;

    @Column(name = "one_drive_user_id")
    @ApiModelProperty(notes = "User Id of the cached OneDrive")
    private String oneDriveUserId;

    @ManyToOne
    @JsonIgnore
    private DomainEntity domainEntity;

    public OneDrive() {
    }

    public OneDrive(String oneDriveId, String name, String webUrl, String oneDriveUserId) {
        this.id = oneDriveId;
        this.name = name;
        this.webUrl = webUrl;
        this.oneDriveUserId = oneDriveUserId;
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getOneDriveUserId() {
        return oneDriveUserId;
    }

    public void setOneDriveUserId(String oneDriveUserId) {
        this.oneDriveUserId = oneDriveUserId;
    }

    public DomainEntity getDomainEntity() {
        return domainEntity;
    }

    public void setDomainEntity(DomainEntity domainEntity) {
        this.domainEntity = domainEntity;
    }
}
