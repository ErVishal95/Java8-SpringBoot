package com.asigra.model.drive.batch.request;

import com.asigra.model.common.batch.BatchRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of OneDrive batch request")
public class OneDriveRequest extends BatchRequest {
    public OneDriveRequest() {
    }

    public OneDriveRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
