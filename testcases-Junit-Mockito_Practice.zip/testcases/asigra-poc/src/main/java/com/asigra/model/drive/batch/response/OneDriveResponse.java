package com.asigra.model.drive.batch.response;

import com.asigra.model.common.batch.BatchResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of OneDrive batch response")
public class OneDriveResponse extends BatchResponse {
    public OneDriveResponse() {
    }

    public OneDriveResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}


