package com.asigra.model.exchange;

import com.asigra.model.common.Folder;
import com.asigra.model.common.batch.BatchOutput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of exchange object in a domain")
public class ExchangeObject implements BatchOutput {
    List<Folder> exchangeFolderList = new ArrayList<>();

    public ExchangeObject() {
        //create a default object
    }

    public List<Folder> getExchangeFolderList() {
        return exchangeFolderList;
    }

    public void setExchangeFolderList(List<Folder> exchangeFolderList) {
        this.exchangeFolderList = exchangeFolderList;
    }
}
