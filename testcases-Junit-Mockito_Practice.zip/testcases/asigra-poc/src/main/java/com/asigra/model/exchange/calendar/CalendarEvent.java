package com.asigra.model.exchange.calendar;

import com.asigra.model.common.File;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalendarEvent extends File {
    public CalendarEvent() {
    }

    public CalendarEvent(String id, String subject) {
        super(id, subject);
    }
}
