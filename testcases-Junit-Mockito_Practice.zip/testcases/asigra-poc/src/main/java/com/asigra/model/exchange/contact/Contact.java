package com.asigra.model.exchange.contact;

import com.asigra.model.common.Folder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a contact in a domain")
public class Contact extends Folder {
    public Contact() {
    }

    public Contact(String id, String displayName) {
        super(id, displayName);
    }
}
