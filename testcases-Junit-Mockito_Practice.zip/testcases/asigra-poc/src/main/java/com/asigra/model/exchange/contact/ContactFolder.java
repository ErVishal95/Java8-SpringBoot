package com.asigra.model.exchange.contact;

import com.asigra.model.common.Folder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of contact folder in a domain")
public class ContactFolder extends Folder {
    public ContactFolder() {
    }

    public ContactFolder(String id, String displayName) {
        super(id, displayName);
    }
}
