package com.asigra.model.exchange.contact;

import com.asigra.model.common.Folder;
import com.asigra.model.common.batch.BatchOutput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a contact object in a domain")
public class ContactObject implements BatchOutput {
    List<Folder> contactFolders = new ArrayList<>();
    List<Folder> contacts = new ArrayList<>();

    public List<Folder> getContactFolders() {
        return contactFolders;
    }

    public void setContactFolders(List<Folder> contactFolders) {
        this.contactFolders = contactFolders;
    }

    public List<Folder> getContacts() {
        return contacts;
    }

    public void setContacts(List<Folder> contacts) {
        this.contacts = contacts;
    }
}
