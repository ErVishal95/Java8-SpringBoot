package com.asigra.model.exchange.contact.batch.request;

import com.asigra.model.common.batch.BatchRequest;

public class ContactFolderBatchRequest extends BatchRequest {
    public ContactFolderBatchRequest() {
    }

    public ContactFolderBatchRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
