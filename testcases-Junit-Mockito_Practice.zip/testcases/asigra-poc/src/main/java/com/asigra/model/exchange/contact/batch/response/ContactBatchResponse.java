package com.asigra.model.exchange.contact.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class ContactBatchResponse extends BatchResponse {
    public ContactBatchResponse() {
    }

    public ContactBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
