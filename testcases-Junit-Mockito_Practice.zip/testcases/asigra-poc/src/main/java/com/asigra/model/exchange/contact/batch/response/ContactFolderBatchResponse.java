package com.asigra.model.exchange.contact.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class ContactFolderBatchResponse extends BatchResponse {
    public ContactFolderBatchResponse() {
    }

    public ContactFolderBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
