package com.asigra.model.exchange.journal;

import com.asigra.model.common.File;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a Journal")
public class Journal extends File {
    public Journal() {
    }

    public Journal(String id, String subject) {
        super(id, subject);
    }
}
