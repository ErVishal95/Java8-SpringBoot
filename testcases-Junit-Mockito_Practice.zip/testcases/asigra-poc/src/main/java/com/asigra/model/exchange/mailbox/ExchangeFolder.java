package com.asigra.model.exchange.mailbox;

import com.asigra.model.common.Folder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of exchange folder in a domain")
public class ExchangeFolder extends Folder {
    public ExchangeFolder() {
    }

    public ExchangeFolder(String id, String displayName) {
        super(id, displayName);
    }
}
