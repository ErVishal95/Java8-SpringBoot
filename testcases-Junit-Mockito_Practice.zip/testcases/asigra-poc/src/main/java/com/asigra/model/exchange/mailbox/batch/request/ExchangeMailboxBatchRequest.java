package com.asigra.model.exchange.mailbox.batch.request;

import com.asigra.model.common.batch.BatchRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of exchange mailbox batch request")
public class ExchangeMailboxBatchRequest extends BatchRequest {
    public ExchangeMailboxBatchRequest() {
    }

    public ExchangeMailboxBatchRequest(String id, String url, String method) {
        super(id, url, method);
    }

}
