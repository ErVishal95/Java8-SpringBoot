package com.asigra.model.exchange.mailbox.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class ExchangeMailboxBatchResponse extends BatchResponse {
    public ExchangeMailboxBatchResponse() {
    }

    public ExchangeMailboxBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
