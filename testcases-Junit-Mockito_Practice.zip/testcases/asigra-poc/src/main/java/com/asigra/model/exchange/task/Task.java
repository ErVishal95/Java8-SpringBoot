package com.asigra.model.exchange.task;

import com.asigra.model.common.File;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a task")
public class Task extends File {
    public Task() {
    }

    public Task(String id, String subject) {
        super(id, subject);
    }

    public Task(Builder builder) {
        super(builder);
    }
}
