package com.asigra.model.exchange.task;

import com.asigra.model.common.batch.BatchOutputEntry;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about a task folder")
public class TaskFolder implements BatchOutputEntry {
    String id;
    String name;

    public TaskFolder() {
    }

    public TaskFolder(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
