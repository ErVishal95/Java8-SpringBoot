package com.asigra.model.exchange.task;

import com.asigra.model.common.File;
import com.asigra.model.common.batch.BatchOutput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details about child folders and files in a task folder")
public class TaskObject implements BatchOutput {
    List<TaskFolder> taskFolders = new ArrayList<>();
    List<File> tasks = new ArrayList<>();

    public List<TaskFolder> getTaskFolders() {
        return taskFolders;
    }

    public void setTaskFolders(List<TaskFolder> taskFolders) {
        this.taskFolders = taskFolders;
    }

    public List<File> getTasks() {
        return tasks;
    }

    public void setTasks(List<File> tasks) {
        this.tasks = tasks;
    }
}
