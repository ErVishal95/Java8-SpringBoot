package com.asigra.model.exchange.task.batch.request;

import com.asigra.model.common.batch.BatchRequest;

public class TaskBatchRequest extends BatchRequest {
    public TaskBatchRequest() {
    }

    public TaskBatchRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
