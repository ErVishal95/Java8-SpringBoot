package com.asigra.model.exchange.task.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class TaskBatchResponse extends BatchResponse {
    public TaskBatchResponse() {
    }

    public TaskBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
