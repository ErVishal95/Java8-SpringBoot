package com.asigra.model.exchange.task.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class TaskFolderBatchResponse extends BatchResponse {
    public TaskFolderBatchResponse() {
    }

    public TaskFolderBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
