package com.asigra.model.publicfolder;

import com.asigra.model.common.Folder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of public publicfolder in a domain")
public class PublicFolder extends Folder {
    public PublicFolder() {
        //Create a default object
    }
}
