package com.asigra.model.sharepoint;

import com.asigra.model.domain.DomainEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "domain_share_points")
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a SharePoint publicfolder in a domain")
public class SharePoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    @JsonIgnore
    private Long identifier;

    @Column(name = "share_point_id")
    @ApiModelProperty(notes = "Id of the cached SharePoint")
    private String id;

    @Column(name = "share_point_name")
    @ApiModelProperty(notes = "Name of the cached SharePoint")
    private String name;

    @Column(name = "share_point_url")
    @ApiModelProperty(notes = "URL of the cached SharePoint")
    private String webUrl;

    @ManyToOne
    @JsonIgnore
    private DomainEntity domainEntity;

    @Transient
    @JsonIgnore
    @ApiModelProperty(notes = "SharePoint root publicfolder flag")
    private Object root;


    public SharePoint() {
    }

    public SharePoint(String id, String name, Object root, String webUrl) {
        this.id = id;
        this.name = name;
        this.root = root;
        this.webUrl = webUrl;
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getRoot() {
        return root;
    }

    public void setRoot(Object root) {
        this.root = root;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public DomainEntity getDomainEntity() {
        return domainEntity;
    }

    public void setDomainEntity(DomainEntity domainEntity) {
        this.domainEntity = domainEntity;
    }
}
