package com.asigra.model.sharepoint;

import com.asigra.model.common.SharePointContent;
import com.asigra.model.common.batch.BatchOutput;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of the content of a SharePoint folder in a domain")
public class SharePointSiteContent implements BatchOutput {

    @ApiModelProperty(notes = "List of all sub-sites in a SharePoint folder")
    private List<SharePointContent> subSites = new ArrayList<>();

    @ApiModelProperty(notes = "List of all lists in a SharePoint folder")
    private List<SharePointContent> lists = new ArrayList<>();

    public List<SharePointContent> getSubSites() {
        return subSites;
    }

    public void setSubSites(List<SharePointContent> subSites) {
        this.subSites = subSites;
    }

    public List<SharePointContent> getLists() {
        return lists;
    }

    public void setLists(List<SharePointContent> lists) {
        this.lists = lists;
    }
}
