package com.asigra.model.sharepoint.batch.request;

import com.asigra.model.common.batch.BatchRequest;

public class SharePointSubSiteBatchRequest extends BatchRequest {
    public SharePointSubSiteBatchRequest() {
    }

    public SharePointSubSiteBatchRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
