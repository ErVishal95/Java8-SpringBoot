package com.asigra.model.sharepoint.batch.request;

import com.asigra.model.common.batch.BatchRequest;

public class SharePointSubSiteListBatchRequest extends BatchRequest {
    public SharePointSubSiteListBatchRequest() {
    }

    public SharePointSubSiteListBatchRequest(String id, String url, String method) {
        super(id, url, method);
    }
}
