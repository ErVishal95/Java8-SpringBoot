package com.asigra.model.sharepoint.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class SharePointSubSiteBatchResponse extends BatchResponse {
    public SharePointSubSiteBatchResponse() {
    }

    public SharePointSubSiteBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
