package com.asigra.model.sharepoint.batch.response;

import com.asigra.model.common.batch.BatchResponse;

public class SharePointSubSiteListBatchResponse extends BatchResponse {
    public SharePointSubSiteListBatchResponse() {
    }

    public SharePointSubSiteListBatchResponse(String id, String status, Body body) {
        super(id, status, body);
    }
}
