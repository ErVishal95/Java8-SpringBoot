package com.asigra.model.sharepoint.site.contents;

import com.asigra.model.common.SharePointContent;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a SharePoint sub-site in a domain")
public class SharePointSubSite extends SharePointContent {

    public SharePointSubSite(String name, String webUrl) {
        super(name, webUrl);
    }

    public SharePointSubSite(String id, String name, String displayName, String webUrl) {
        super(id, name, displayName, webUrl);
    }

}
