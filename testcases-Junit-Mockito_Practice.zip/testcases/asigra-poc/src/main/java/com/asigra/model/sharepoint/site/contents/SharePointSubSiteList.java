package com.asigra.model.sharepoint.site.contents;

import com.asigra.model.common.SharePointContent;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "All details of a SharePoint sub-site list in a domain")
public class SharePointSubSiteList extends SharePointContent {
    public SharePointSubSiteList(String webUrl, String name) {
        super(webUrl, name);
    }

    public SharePointSubSiteList(String id, String name, String displayName, String webUrl) {
        super(id, name, displayName, webUrl);
    }
}
