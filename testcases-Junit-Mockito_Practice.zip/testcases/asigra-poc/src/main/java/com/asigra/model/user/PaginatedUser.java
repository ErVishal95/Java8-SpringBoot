package com.asigra.model.user;

import java.util.List;

public class PaginatedUser {

    public PaginatedUser() {
        //Create a default object
    }

    private List<User> userList;

    public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }
}
