package com.asigra.model.user;

import com.asigra.model.common.batch.BatchOutput;
import com.asigra.model.domain.DomainEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "domain_users_with_archive_folders")
@ApiModel(description = "All details of users in the application for a domain")
@JsonIgnoreProperties(ignoreUnknown = true)
public class User implements BatchOutput {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    @JsonIgnore
    private Long identifier;

    @Column(name = "user_id")
    @ApiModelProperty(notes = "Id of the user")
    private String id;

    @Column(name = "user_display_name")
    @ApiModelProperty(notes = "Name of the user")
    private String displayName;

    @Column(name = "user_principal_name")
    @ApiModelProperty(notes = "Principal name of the user")
    private String userPrincipalName;

    @ManyToOne
    @JsonIgnore
    private DomainEntity domainEntity;

    @Transient
    @JsonIgnore
    private List<?> assignedLicenses;

    public User() {
    }

    public User(String userId, String displayName, String userPrincipalName) {
        this.id = userId;
        this.displayName = displayName;
        this.userPrincipalName = userPrincipalName;
    }

    public Long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Long identifier) {
        this.identifier = identifier;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getUserPrincipalName() {
        return userPrincipalName;
    }

    public void setUserPrincipalName(String userPrincipalName) {
        this.userPrincipalName = userPrincipalName;
    }

    public List<?> getAssignedLicenses() {
        return assignedLicenses;
    }

    public void setAssignedLicenses(List<?> assignedLicenses) {
        this.assignedLicenses = assignedLicenses;
    }

    public DomainEntity getDomainEntity() {
        return domainEntity;
    }

    public void setDomainEntity(DomainEntity domainEntity) {
        this.domainEntity = domainEntity;
    }

    @Override
    public String toString() {
        return "User{" +
                ", id='" + id + '\'' +
                "displayName='" + displayName + '\'' +
                "userPrincipalName='" + userPrincipalName + '\'' +
                '}';
    }

}
