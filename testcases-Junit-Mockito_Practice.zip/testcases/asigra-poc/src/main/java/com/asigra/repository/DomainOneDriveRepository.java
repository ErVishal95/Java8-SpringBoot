package com.asigra.repository;

import com.asigra.model.domain.DomainEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DomainOneDriveRepository extends CrudRepository<DomainEntity, Long> {
    Optional<DomainEntity> findByDomainName(String domainName);
}

