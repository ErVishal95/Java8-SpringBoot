package com.asigra.service;

import com.asigra.model.archive.batch.request.ArchiveFolderRequest;
import com.asigra.model.archive.batch.response.ArchiveFolderResponse;
import com.asigra.model.common.batch.BatchOutput;
import com.asigra.model.common.batch.BatchRequest;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.drive.batch.request.OneDriveRequest;
import com.asigra.model.drive.batch.response.OneDriveResponse;
import com.asigra.model.user.User;

import java.util.List;

public interface BatchService {

    /**
     * Fetch all OneDrive details for all users in a domain
     *
     * @param domain, domain name for which OneDrive details are fetched
     * @param allUsers, all available users in the domain
     * @param oneDriveObjectType, Output type of the object
     * @param oneDriveRequestObjectType, batch request
     * @param oneDriveResponseObjectType, batch response
     * @param oneDriveBatchRequestUrl, OneDrive batch request URL
     * @return
     */
    List<OneDrive> fetchOneDriveDataFromGraphUsingBatch(
            String domain,
            List<User> allUsers,
            Class<OneDrive> oneDriveObjectType,
            Class<OneDriveRequest> oneDriveRequestObjectType,
            Class<OneDriveResponse> oneDriveResponseObjectType,
            String oneDriveBatchRequestUrl);

    /**
     * Fetch all users having archive enabled
     * @param domain
     * @param allUsers
     * @param userObjectType
     * @param archiveFolderRequestObjectType
     * @param archiveFolderResponseObjectType
     * @param archiveBatchRequestUrl
     * @return
     */
    List<User> fetchUsersWithArchiveEnabledFromGraphUsingBatch(
            String domain,
            List<User> allUsers,
            Class<User> userObjectType,
            Class<ArchiveFolderRequest> archiveFolderRequestObjectType,
            Class<ArchiveFolderResponse> archiveFolderResponseObjectType,
            String archiveBatchRequestUrl);

    /**
     * Fetch data from graph using batches
     * @param domain
     * @param batchRequestList
     * @param batchObjectType
     * @param <T>
     * @return
     */
    <T extends BatchOutput> T fetchGenericDataFromGraphUsingBatch(
            String domain,
            List<BatchRequest> batchRequestList,
            Class<T> batchObjectType

    );

}