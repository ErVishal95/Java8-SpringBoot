package com.asigra.service;

import com.asigra.model.domain.DomainEntity;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.user.User;

import java.util.List;
import java.util.Optional;

public interface CacheService {

    /**
     * Fetch domain entity object from the in-memory db
     *
     * @param domain, name of the domain
     * @return
     */
    Optional<DomainEntity> getDomainEntityFromDB(String domain);

    /**
     * Cache OneDrives to db
     * @param domain
     * @param allOneDrives
     */
    void cacheOneDrivesToDB(String domain, List<OneDrive> allOneDrives);

    /**
     * Cache SharePoints to the db
     * @param domain
     * @param allSharePoints
     */
    void cacheSharePointsToDB(String domain, List<SharePoint> allSharePoints);

    /**
     * Cache UserWithArchiveFolders to the db
     * @param domain
     * @param usersWithArchiveFolders
     */
    void cacheUserWithArchiveFoldersToDB(String domain, List<User> usersWithArchiveFolders);

}
