package com.asigra.service;


import com.asigra.model.domain.Domain;
import com.asigra.model.domain.DomainEntity;
import microsoft.exchange.webservices.data.core.ExchangeService;

import java.util.List;


public interface DomainService {

    /**
     * load domain details from the db
     *
     * @param domain,   name of the domain
     * @param username, name of the user
     * @param password, password of the user
     */
    void loadDomainProperties(String domain, String username, String password);

    /**
     * Get domain metadata from the properties file
     * @param domain, name of the domain
     * @return
     */
    Domain getDomainProperties(String domain);

    /**
     * Get ExchangeServiceObject to fetch public folders
     * @param domain, name of the domain
     * @return
     */
    ExchangeService getExchangeEWSService(String domain);

    /**
     * Get all cached OneDrives
     * @return
     */
    List<DomainEntity> getAllCachedOneDrives();
}
