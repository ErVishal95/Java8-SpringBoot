package com.asigra.service;

import com.asigra.model.drive.OneDrive;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.sharepoint.SharePointSiteContent;
import com.asigra.model.user.User;

import java.util.List;

public interface DriveService {

    /**
     * Get SharePoint root folders
     *
     * @param domain,     name of the domain
     * @param isRealTime, fetch updated data from Graph
     * @return
     */
    List<SharePoint> getSharePointRootFoldersInDomain(String domain, boolean isRealTime);

    /**
     * Get contents of the SharePoint site
     * @param domain, name of the domain
     * @param siteId, id of the SharePoint folder
     * @return
     */
    List<SharePointSiteContent> getSharePointSiteContents(String domain, String siteId);

    /**
     * Get OneDrive root folders
     * @param domain, name of the domain
     * @param realTime, fetch updated data from Graph
     * @return
     */
    List<OneDrive> getOneDriveRootFoldersForAllUsersInDomain(String domain, boolean realTime);

    /**
     * Get OneDrive data using bacth APIS
     * @param domain, name of the domain
     * @param userList, list of all existing users
     * @return
     */
    List<OneDrive> getUserOneDriveDataFromBatch(String domain, List<User> userList);

    /**
     * Get contents of the OneDrive
     * @param userId, id of the user
     * @param driveId, id of the OneDrive folder
     * @param domain, name of the domain
     * @return
     */
    List<OneDrive> getContentsOfTheRootDrive(String userId, String driveId, String domain);

    /**
     * Get contents of a OneDrive folder
     * @param userId, id of the user
     * @param itemId, id of the OneDrive folder
     * @param domain, name of the domain
     * @return
     */
    List<OneDrive> getContentsOfOneDriveFolder(String userId, String itemId, String domain);
}
