package com.asigra.service;

import com.asigra.model.common.File;
import com.asigra.model.publicfolder.PublicFolder;

import java.util.List;

public interface EWSService {

    /**
     * Get all public folders of a domain
     *
     * @param domain, name of the domain
     * @return
     */
    List<PublicFolder> getPublicRootFolders(String domain);

    /**
     * Get sub folders of a public folder
     * @param folderId, id of the folder
     * @param domain, name of the domain
     * @return
     */
    List<PublicFolder> getSubFoldersOfAPublicFolder(String folderId, String domain);

    /**
     * Get all files of a public folder
     * @param folderId, id of the folder
     * @param domain, name of the domain
     * @return
     */
    List<File> getAllFilesOfAPublicFolder(String folderId, String domain);
}
