package com.asigra.service;

import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.common.File;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.calendar.Calendar;
import com.asigra.model.exchange.calendar.CalendarEvent;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.journal.Journal;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.user.User;

import java.util.List;

public interface ExchangeService {

    /**
     * Get users existing in a domain
     *
     * @param domain,            name of the domain
     * @param licensedUsersOnly, fetch licensed users
     * @return
     */
    List<User> getUserList(String domain, boolean licensedUsersOnly);

    /**
     * Get groups in a domain
     * @param domain, name of the domain
     * @return
     */
    List<User> getGroupList(String domain);

    /**
     * Get user root exchange folder
     * @param userId, id of the user
     * @param domain, name of the domain
     * @return
     */
    List<ExchangeObject> getUserRootExchangeFolders(String userId, String domain);

    /**
     * Get archive folders for a user in a domain
     * @param domain, name of the domain
     * @param userId, id of the user
     * @return
     */
    List<ArchiveObject> getUserRootArchiveFolders(String domain, String userId);

    /**
     * Get archive folder contents
     * @param domain, name of the domain
     * @param userId, id of the user
     * @param folderId, id of the folder
     * @return
     */
    List<ArchiveObject> getUserArchiveFolderContents(String domain, String userId, String folderId);

    /**
     * Get list of users with archive enabled using batch service
     * @param domain, name of the domain
     * @param userList, list of all the users
     * @return
     */
    List<User> getUsersWithArchiveEnabledFromBatch(String domain, List<User> userList);

    /**
     * Get mailbox sub folders for a user
     * @param userId, id of the user
     * @param folderId, id of the folder
     * @param domain, name of the domain
     * @return
     */
    List<ExchangeFolder> getMailboxSubFolders(String userId, String folderId, String domain);

    /**
     * Get all emails in a mailbox folder
     * @param userId, id of the user
     * @param folderId, id of the folder
     * @param domain, name of the domain
     * @return
     */
    List<File> getAllEmailsOfFolder(String userId, String folderId, String domain);

    /**
     * Get list of users with archive emabled for a domain
     * @param domain, name of the domain
     * @param realTime, fetch updated details of the user
     * @return
     */
    List<User> getUsersHavingArchiveFolders(String domain, boolean realTime);

    /**
     * Get user root calendars
     * @param userId, id of the user
     * @param domain, name of the domain
     * @return
     */
    List<Calendar> getUserRootCalendars(String userId, String domain);

    /**
     * Get calendar events for a user calendar
     * @param userId, id of the user
     * @param domain, domain name
     * @param calenderId, id of the calendar folder
     * @return
     */
    List<CalendarEvent> getUserCalendarEvents(String userId, String domain, String calenderId);

    /**
     * Get user contact folder contents
     * @param userId, id of the user
     * @param domain, domain name
     * @param contactFolderId, id of the contact folder
     * @return
     */
    List<ContactObject> getUserContactFolderContents(String userId, String domain, String contactFolderId);

    /**
     * Get task folder contents for a user task folder
     * @param userId, id of the user
     * @param domain, domain name
     * @param taskFolderId
     * @return
     */
    List<TaskObject> getUserTaskFolderContents(String userId, String domain, String taskFolderId);

    /**
     * Get journals for a user in a domain
     * @param userId, id of the user
     * @param domain, domain name
     * @return
     */
    List<Journal> getUserJournals(String userId, String domain);
}
