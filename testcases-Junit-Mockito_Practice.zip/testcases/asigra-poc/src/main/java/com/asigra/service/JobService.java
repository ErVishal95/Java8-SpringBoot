package com.asigra.service;

public interface JobService {
    /**
     * Cache OneDrive, UsersWithArchiveEnabled and SharePoint data
     */
    void cacheDomainLevelDetails();

}
