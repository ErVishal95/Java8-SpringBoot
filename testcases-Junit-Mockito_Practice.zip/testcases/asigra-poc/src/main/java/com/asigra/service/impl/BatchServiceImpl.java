package com.asigra.service.impl;

import com.asigra.constants.GraphAPIURLS;
import com.asigra.constants.KeyConstants;
import com.asigra.model.archive.ArchiveFile;
import com.asigra.model.archive.ArchiveFolder;
import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.archive.batch.request.ArchiveFolderRequest;
import com.asigra.model.archive.batch.response.ArchiveFolderResponse;
import com.asigra.model.common.File;
import com.asigra.model.common.Folder;
import com.asigra.model.common.SharePointContent;
import com.asigra.model.common.batch.*;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.drive.batch.request.OneDriveRequest;
import com.asigra.model.drive.batch.response.OneDriveResponse;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.contact.Contact;
import com.asigra.model.exchange.contact.ContactFolder;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.task.Task;
import com.asigra.model.exchange.task.TaskFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.sharepoint.SharePointSiteContent;
import com.asigra.model.sharepoint.site.contents.SharePointSubSite;
import com.asigra.model.sharepoint.site.contents.SharePointSubSiteList;
import com.asigra.model.user.User;
import com.asigra.service.BatchService;
import com.asigra.service.utils.CommonUtils;
import com.asigra.service.utils.ExceptionReportUtils;
import com.asigra.service.utils.GraphUtils;
import com.google.common.collect.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BatchServiceImpl implements BatchService {

    private static final Logger logger = LogManager.getLogger(BatchServiceImpl.class);
    private final GraphUtils graphUtils;
    private final CommonUtils commonUtils;
    private final ExceptionReportUtils exceptionReportUtils;

    @Autowired
    public BatchServiceImpl(@Lazy GraphUtils graphUtils,
                            @Lazy CommonUtils commonUtils,
                            @Lazy ExceptionReportUtils exceptionReportUtils) {
        this.graphUtils = graphUtils;
        this.commonUtils = commonUtils;
        this.exceptionReportUtils = exceptionReportUtils;
    }

    @Override
    public List<OneDrive> fetchOneDriveDataFromGraphUsingBatch(
            String domain,
            List<User> allUsers,
            Class<OneDrive> oneDriveObjectType,
            Class<OneDriveRequest> oneDriveRequestObjectType,
            Class<OneDriveResponse> oneDriveResponseObjectType,
            String oneDriveBatchRequestUrl) {
        logger.debug(" fetchOneDriveDataFromGraphUsingBatch batch service function executed ", domain);
        return fetchDataFromGraphUsingBatch(domain, allUsers, oneDriveObjectType, oneDriveRequestObjectType, oneDriveResponseObjectType, oneDriveBatchRequestUrl);

    }

    @Override
    public List<User> fetchUsersWithArchiveEnabledFromGraphUsingBatch(
            String domain,
            List<User> allUsers,
            Class<User> userObjectType,
            Class<ArchiveFolderRequest> archiveFolderRequestObjectType,
            Class<ArchiveFolderResponse> archiveFolderResponseObjectType,
            String archiveBatchRequestUrl) {
        logger.debug(" fetchUsersWithArchiveEnabledFromGraphUsingBatch batch service function executed domain ", domain);
        return fetchDataFromGraphUsingBatch(domain, allUsers, userObjectType, archiveFolderRequestObjectType, archiveFolderResponseObjectType, archiveBatchRequestUrl);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends BatchOutput> T fetchGenericDataFromGraphUsingBatch(
            String domain,
            List<BatchRequest> batchRequestList,
            Class<T> batchObjectType

    ) {
        logger.debug(" fetchGenericDataFromGraphUsingBatch batch service function executed domain ", domain);

        T outputObject = null;

        boolean taskObjectRequest = false;

        if (batchObjectType.getSimpleName().equalsIgnoreCase(TaskObject.class.getSimpleName())) {
            taskObjectRequest = true;
        }

        batchRequestList.stream()
                .forEach(batchRequest ->
                        logger.debug(" request given to the batch api " + batchRequest));

        Instant startProcessingTimeForBatchRequest = Instant.now();

        String responseFromBatchRequest = graphUtils.getResponseFromBatchRequest(
                taskObjectRequest ? GraphAPIURLS.GRAPH_BETA_BATCH_REQUEST_URL : GraphAPIURLS.GRAPH_BATCH_REQUEST_URL,
                batchRequestList,
                domain,
                taskObjectRequest
        );

        Instant endProcessingTimeForBatchRequest = Instant.now();

        logger.debug(" time in seconds to fetch batch response  " + " = " + Duration.between(
                startProcessingTimeForBatchRequest,
                endProcessingTimeForBatchRequest).getSeconds());

        List<BatchResponse> batchResponseList = commonUtils.convertJSONStringToList(responseFromBatchRequest, BatchResponse.class);
        logger.debug(" number of entries in the batch response " + batchResponseList.size());

        BatchOutputBuilder.Builder batchOutputBuilder = BatchOutputBuilder.Builder.newInstance();

        for (BatchResponse batchResponse : batchResponseList) {
            if (batchResponse.getStatus().equalsIgnoreCase(String.valueOf(HttpStatus.OK.value()))) {
                getDataFromBatchResponseForSuccessCase(batchOutputBuilder, batchResponse);
            }
        }

        outputObject = getBatchOutputObjectFromBuilder(batchObjectType, outputObject, batchOutputBuilder);

        return outputObject;
    }

    private void getDataFromBatchResponseForSuccessCase(BatchOutputBuilder.Builder batchOutputBuilder, BatchResponse batchResponse) {
        List<BatchResponse.Value> batchResponseValue = batchResponse.getBody().getValue();

        switch (batchResponse.getId()) {
            case KeyConstants.EXCHANGE_MAILBOX_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder.buildExchangeObjectFolderList(
                                createBatchOutputEntry(batchResponseObj, ExchangeFolder.class)));
                break;
            case KeyConstants.EXCHANGE_CONTACT_FOLDERS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildContactObjectFolderList(
                                        createBatchOutputEntry(batchResponseObj, ContactFolder.class)));
                break;
            case KeyConstants.EXCHANGE_CONTACTS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildContactObjectContactList(
                                        createBatchOutputEntry(batchResponseObj, Contact.class)));
                break;
            case KeyConstants.ARCHIVE_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildArchiveObjectFolderList(
                                        createBatchOutputEntry(batchResponseObj, ArchiveFolder.class)));
                break;
            case KeyConstants.ARCHIVE_SUB_FOLDERS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildArchiveObjectFolderList(
                                        createBatchOutputEntry(batchResponseObj, ArchiveFolder.class)));
                break;
            case KeyConstants.ARCHIVE_FOLDERS_FILES_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildArchiveObjectFileList(
                                        createBatchOutputEntry(batchResponseObj, ArchiveFile.class)));
                break;
            case KeyConstants.SHAREPOINT_SUBSITES_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildSharePointSiteContentSubSites(
                                        createBatchOutputEntry(batchResponseObj, SharePointSubSite.class)));
                break;
            case KeyConstants.SHAREPOINT_SUBSITE_LISTS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildSharePointSiteContentLists(
                                        createBatchOutputEntry(batchResponseObj, SharePointSubSiteList.class)));
                break;
            case KeyConstants.EXCHANGE_TASK_FOLDERS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildTaskObjectFolderList(
                                        new TaskFolder(batchResponseObj.getId(), batchResponseObj.getName())));
                break;
            case KeyConstants.EXCHANGE_TASKS_BATCH_ID:
                batchResponseValue.stream().
                        forEach(batchResponseObj -> batchOutputBuilder
                                .buildTaskObjectTaskList(
                                        createBatchOutputEntry(batchResponseObj, Task.class)));
                break;
            default:
                logger.error("case of no response object");
                break;
        }
    }

    private <T extends BatchOutput> T getBatchOutputObjectFromBuilder(Class<T> batchObjectType, T outputObject, BatchOutputBuilder.Builder batchOutputBuilder) {
        if (batchObjectType == ExchangeObject.class) {
            outputObject = (T) batchOutputBuilder.getExchangeObject();

        } else if (batchObjectType == ContactObject.class) {
            outputObject = (T) batchOutputBuilder.getContactObject();

        } else if (batchObjectType == ArchiveObject.class) {
            outputObject = (T) batchOutputBuilder.getArchiveObject();

        } else if (batchObjectType == SharePointSiteContent.class) {
            outputObject = (T) batchOutputBuilder.getSharePointSiteContent();

        } else if (batchObjectType == TaskObject.class) {
            outputObject = (T) batchOutputBuilder.getTaskObject();
        }
        return outputObject;
    }

    @SuppressWarnings("unchecked")
    private <T extends BatchOutputEntry> T createBatchOutputEntry(BatchResponse.Value batchResponseObj, Class<T> entryObjectType) {
        T entryObject = null;

        if (SharePointContent.class.isAssignableFrom(entryObjectType)) {
            SharePointContent sharePointContentEntry = SharePointContent.Builder.newInstance()
                    .setId(batchResponseObj.getId())
                    .setName(batchResponseObj.getName())
                    .setDisplayName(batchResponseObj.getDisplayName())
                    .setWebUrl(batchResponseObj.getWebUrl())
                    .build();

            entryObject = (T) sharePointContentEntry;
        } else if (Folder.class.isAssignableFrom(entryObjectType)) {
            Folder folderEntry = Folder.Builder.newInstance()
                    .setId(batchResponseObj.getId())
                    .setDisplayName(batchResponseObj.getDisplayName())
                    .build();

            entryObject = (T) folderEntry;
        } else if (File.class.isAssignableFrom(entryObjectType)) {
            File fileEntry = File.Builder.newInstance()
                    .setId(batchResponseObj.getId())
                    .setSubject(batchResponseObj.getSubject())
                    .build();

            entryObject = (T) fileEntry;

        }
        return entryObject;
    }

    private <T extends BatchOutput, Y extends BatchRequest, Z extends BatchResponse> List<T> fetchDataFromGraphUsingBatch(
            String domain,
            List<User> allUpdatedUsers,
            Class<T> outputObjectType,
            Class<Y> batchRequestType,
            Class<Z> batchResponseType,
            String batchRequestUrl) {
        return getResponseFromBatchService(domain,
                allUpdatedUsers, outputObjectType, batchRequestType, batchResponseType, batchRequestUrl);
    }

    private <T, Y extends BatchRequest, Z extends BatchResponse> List<T> getResponseFromBatchService(
            String domain,
            List<User> users,
            Class<T> outputObjectType,
            Class<Y> batchRequestType,
            Class<Z> batchResponseType,
            String batchRequestUrl) {
        logger.debug(" getResponseFromBatchService batch service function executed", domain + " number of all users " + users.size());
        List<Y> allBatchRequestUrls = createBatchRequest(users, batchRequestUrl, batchRequestType);
        Instant startProcessingTimeForAllBatches = Instant.now();
        List<T> allRootFolders = getDataFromGraphInBatches(domain, allBatchRequestUrls, outputObjectType, batchResponseType);
        Instant endProcessingTimeForAllBatches = Instant.now();
        logger.debug(" time in seconds to fetch data for all batches " + Duration.between(startProcessingTimeForAllBatches, endProcessingTimeForAllBatches).getSeconds());

        return allRootFolders;
    }

    private <Y> List<Y> createBatchRequest(List<User> users, String batchRequestUrl, Class<Y> batchRequestType) {
        logger.debug(" createBatchRequest batch service function executed" + " number of all users " + users.size());

        return users.stream().map(user -> getBatchRequestObject(
                batchRequestType,
                user.getId(),
                String.format(batchRequestUrl, (Object[]) new String[]{user.getId()}),
                RequestMethod.GET.name())).collect(Collectors.toList()
        );
    }

    @SuppressWarnings("unchecked")
    private <T, Y extends BatchRequest, Z extends BatchResponse> ArrayList<T> getDataFromGraphInBatches(
            String domain,
            List<Y> allBatchRequestUrls,
            Class<T> outputObjectType,
            Class<Z> batchResponseType) {

        logger.debug(" getDataFromGraphInBatches batch service function executed", domain);

        ArrayList<T> allRootFolders = new ArrayList(0);
        int batchSizeForOneDriveRequests = KeyConstants.DEFAULT_GRAPH_REQUESTS_BATCH_SIZE_;
        int currentBatchNumber = 0;

        for (List<Y> requestBatch : Lists.partition(allBatchRequestUrls,
                batchSizeForOneDriveRequests)) {
            try {
                currentBatchNumber = currentBatchNumber + 1;
                Instant startProcessingTimeForBatchRequest = Instant.now();
                String responseFromBatch = graphUtils.getResponseFromBatchRequest(GraphAPIURLS.GRAPH_BATCH_REQUEST_URL, requestBatch, domain, false);
                Instant endProcessingTimeForBatchRequest = Instant.now();
                logger.debug(" time in seconds to fetch " + outputObjectType + " data for batch number " + currentBatchNumber + " = " +
                        Duration.between(startProcessingTimeForBatchRequest, endProcessingTimeForBatchRequest).getSeconds());

                List<Z> responseFromBatchRequest = commonUtils.convertJSONStringToList(responseFromBatch, batchResponseType);
                getSingleBatchExecutionOutput(allRootFolders, responseFromBatchRequest, outputObjectType, batchResponseType);
            } catch (Exception e) {
                exceptionReportUtils.throwExceptionIfGraphUtilsBatchRequestFetchFailed(domain, allBatchRequestUrls, e.getMessage());
                logger.error(e);
            }
        }
        return allRootFolders;
    }

    @SuppressWarnings("unchecked")
    private <T, Z extends BatchResponse> void getSingleBatchExecutionOutput(
            List<T> rootFolders,
            List<Z> responseFromBatchRequest,
            Class<T> outputObjectType,
            Class<Z> batchResponseType) {
        logger.debug(" getSingleBatchExecutionOutput batch service function executed" + " responseFromBatchRequest " + responseFromBatchRequest + " number of all rootFolders " + rootFolders.size());
        for (BatchResponse batchResponse : responseFromBatchRequest) {
            if (batchResponse.getStatus().equalsIgnoreCase(String.valueOf(HttpStatus.OK.value()))) {
                Z batchResponseObject = getBatchResponseObject(batchResponseType, batchResponse.getId(), batchResponse.getStatus(), batchResponse.getBody());

                List<BatchResponse.Value> batchResponseValue = batchResponseObject.getBody().getValue();
                if (outputObjectType == OneDrive.class) {
                    BatchResponse.Value successResponse = batchResponseValue.get(0);
                    OneDrive userOneDrive = new OneDrive();
                    userOneDrive.setId(successResponse.getId());
                    userOneDrive.setName(successResponse.getName());
                    userOneDrive.setWebUrl(successResponse.getWebUrl());
                    userOneDrive.setOneDriveUserId(batchResponseObject.getId());

                    rootFolders.add((T) userOneDrive);
                } else if (outputObjectType == User.class) {
                    User userWithArchiveFolder = new User();
                    userWithArchiveFolder.setId(batchResponse.getId());
                    rootFolders.add((T) userWithArchiveFolder);
                }
            }
        }
    }

    private <Y> Y getBatchRequestObject(Class<Y> batchRequestType, String id, String url, String method) {
        Y batchRequestObject = null;
        try {
            Constructor<Y> constructor = batchRequestType.getConstructor(String.class, String.class, String.class);
            batchRequestObject = constructor.newInstance(id, url, method);
        } catch (NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
            logger.error(e);
        }
        return batchRequestObject;
    }

    public <Z extends BatchResponse> Z getBatchResponseObject(Class<Z> batchResponseType, String id, String status, BatchResponse.Body body) {
        Z batchResponseObject = null;
        try {
            Constructor<Z> constructor = batchResponseType.getConstructor(String.class, String.class, BatchResponse.Body.class);
            batchResponseObject = constructor.newInstance(id, status, body);
        } catch (NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
            logger.error(e);
        }
        return batchResponseObject;
    }
}


