package com.asigra.service.impl;

import com.asigra.model.domain.DomainEntity;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.user.User;
import com.asigra.repository.DomainOneDriveRepository;
import com.asigra.service.CacheService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CacheServiceImpl implements CacheService {

    private final DomainOneDriveRepository domainOneDriveRepository;
    private static final Logger logger = LogManager.getLogger(CacheServiceImpl.class);

    @Autowired
    public CacheServiceImpl(@Lazy DomainOneDriveRepository domainOneDriveRepository) {
        this.domainOneDriveRepository = domainOneDriveRepository;
    }

    @Override
    public void cacheOneDrivesToDB(String domain, List<OneDrive> allOneDrives) {
        try {
            Optional<DomainEntity> domainFromDB = getDomainEntityFromDB(domain);
            if (domainFromDB.isPresent()) {
                DomainEntity domainEntityFromDB = domainFromDB.get();
                domainEntityFromDB.setOneDrives(allOneDrives);
            } else {
                DomainEntity domainEntity = new DomainEntity();
                domainEntity.setDomainName(domain);
                allOneDrives.forEach(oneDriveEntity -> oneDriveEntity.setDomainEntity(domainEntity));
                domainEntity.getOneDrives().addAll(allOneDrives);
                saveDomainObjectToDB(domainEntity);
            }
            logger.debug(" number of all onedrives cached to db " + allOneDrives.size());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void cacheSharePointsToDB(String domain, List<SharePoint> allSharePoints) {
        try {
            Optional<DomainEntity> domainFromDB = getDomainEntityFromDB(domain);

            if (domainFromDB.isPresent()) {
                DomainEntity domainEntityFromDB = domainFromDB.get();

                if (!domainEntityFromDB.getSharePoints().isEmpty()) {
                    domainEntityFromDB.setSharePoints(allSharePoints);
                } else {
                    DomainEntity domainEntity = new DomainEntity();
                    domainEntity.setDomainName(domain);
                    allSharePoints
                            .forEach(sharePoint -> sharePoint.setDomainEntity(domainEntityFromDB));
                    domainEntityFromDB.getSharePoints().addAll(allSharePoints);
                    saveDomainObjectToDB(domainEntityFromDB);
                }
            }

            logger.debug(" number of all sharepoints cached to db " + allSharePoints.size());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void cacheUserWithArchiveFoldersToDB(String domain, List<User> userList) {
        try {
            Optional<DomainEntity> domainEntityFromDB = getDomainEntityFromDB(domain);

            if (domainEntityFromDB.isPresent()) {
                DomainEntity domainFromDB = domainEntityFromDB.get();

                if (!domainFromDB.getUsersWithArchiveFolders().isEmpty()) {
                    domainFromDB.setUsersWithArchiveFolders(userList);
                } else {
                    DomainEntity domainEntity = new DomainEntity();
                    domainEntity.setDomainName(domain);
                    userList
                            .forEach(userArchiveFolderEntity -> userArchiveFolderEntity.setDomainEntity(domainFromDB));
                    domainFromDB.getUsersWithArchiveFolders().addAll(userList);
                    saveDomainObjectToDB(domainFromDB);
                }
            }
            logger.debug(" number of all usersWithArchiveFolders cached to db " + userList.size());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public Optional<DomainEntity> getDomainEntityFromDB(String domain) {
        logger.debug(" getDomainEntityFromDB function of cache service executed" + " domain " + domain);
        return domainOneDriveRepository.findByDomainName(domain);
    }

    private DomainEntity saveDomainObjectToDB(DomainEntity domainEntity) {
        return domainOneDriveRepository.save(domainEntity);
    }
}
