package com.asigra.service.impl;

import com.asigra.exception.GenericException;
import com.asigra.model.domain.Domain;
import com.asigra.model.domain.DomainEntity;
import com.asigra.repository.DomainOneDriveRepository;
import com.asigra.service.DomainService;
import com.asigra.service.utils.ExceptionReportUtils;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
        @PropertySource("classpath:domain.properties")
public class DomainServiceImpl implements DomainService {

    private static final Logger logger = LogManager.getLogger(DomainServiceImpl.class);
    private final DomainOneDriveRepository domainOneDriveRepository;
    private final ExceptionReportUtils exceptionReportUtils;
    private final Environment env;
    private final Map<String, Domain> domainMap = new HashMap<>();

    @Autowired
    public DomainServiceImpl(@Lazy DomainOneDriveRepository domainOneDriveRepository,
                             @Lazy ExceptionReportUtils exceptionReportUtils,
                             @Lazy Environment env) {
        this.domainOneDriveRepository = domainOneDriveRepository;
        this.exceptionReportUtils = exceptionReportUtils;
        this.env = env;
    }

    @Override
    public void loadDomainProperties(String domain, String username, String password) {
        Domain domainProperties;
        try {
            if (domainMap.containsKey(domain)) {
                Domain domainObj = domainMap.get(domain);
                if (domainObj == null) {
                    throw new GenericException("Configuration details not available for domain " + domain);
                }
            }
            domainProperties = fetchDomainProperties(domain, username, password);

            if (domainProperties == null) {
                throw new GenericException("Configuration details not available for domain " + domain);
            }
            domainMap.put(domain, domainProperties);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfDomainConfigurationFetchFailed(domain, e.getMessage());
        }

    }

    @Override
    public Domain getDomainProperties(String domain) {
        return loadDomainPropertiesFromCache(domain);
    }

    @Override
    public ExchangeService getExchangeEWSService(String domain) {
        Domain domainObj = loadDomainPropertiesFromCache(domain);

        ExchangeService exchangeService = null;

        if (domainObj != null) {
            exchangeService = domainObj.getExchangeEWSService();
        }
        return exchangeService;
    }

    @Override
    public List<DomainEntity> getAllCachedOneDrives() {
        return StreamSupport.stream(domainOneDriveRepository.findAll().spliterator(), false)
                .collect(Collectors.toList());
    }

    private Domain fetchDomainProperties(String domain, String username, String password) {
        Domain domainObj;
        try {
            domainObj = new Domain(domain,
                    env.getProperty(domain + "_" + env.getProperty("client_id_key")),
                    env.getProperty(domain + "_" + env.getProperty("client_secret_key")),
                    username,
                    password);

            if (domainObj.getClientId() == null ||
                    domainObj.getClientSecret() == null ||
                    domainObj.getUserName() == null ||
                    domainObj.getPassword() == null) {
                domainObj = null;

            } else {
                ExchangeService exchangeServiceFromCredentials = getExchangeEWSServiceFromCredentials(domain, username, password);

                if (exchangeServiceFromCredentials == null) {
                    domainObj = null;
                } else {
                    domainObj.setAccessToken(null);
                    domainObj.setExchangeEWSService(exchangeServiceFromCredentials);
                }
            }

        } catch (Exception e) {
            logger.error(" Error in fetchDomainProperties function " + e.getMessage());
            domainObj = null;
        }

        return domainObj;
    }

    private ExchangeService getExchangeEWSServiceFromCredentials(String domain, String username, String password) {
        ExchangeService exchangeService = null;
        try {
            ExchangeCredentials credentials = new WebCredentials(username, password);
            exchangeService = new ExchangeService();
            exchangeService.setUrl(new URI(Objects.requireNonNull(env.getProperty("exchange.url"))));
            exchangeService.setCredentials(credentials);

        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExchangeServiceCreationFailed(domain, username, e.getMessage());
            exchangeService = null;
        }

        return exchangeService;
    }

    private Domain loadDomainPropertiesFromCache(String domain) {
        Domain domainObj = domainMap.get(domain);
        if (domainObj == null) {
            exceptionReportUtils.throwExceptionIfDomainFromCacheFetchFailed(domain, ">> details for domain " + domain + " is not available in the system");
        }
        return domainObj;
    }
}
