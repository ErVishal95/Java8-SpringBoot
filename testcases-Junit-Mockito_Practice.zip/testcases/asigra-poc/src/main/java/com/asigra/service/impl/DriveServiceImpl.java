package com.asigra.service.impl;

import com.asigra.constants.GraphAPIURLS;
import com.asigra.constants.KeyConstants;
import com.asigra.exception.GenericException;
import com.asigra.model.common.batch.BatchRequest;
import com.asigra.model.domain.DomainEntity;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.drive.batch.request.OneDriveRequest;
import com.asigra.model.drive.batch.response.OneDriveResponse;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.sharepoint.SharePointSiteContent;
import com.asigra.model.sharepoint.batch.request.SharePointSubSiteBatchRequest;
import com.asigra.model.sharepoint.batch.request.SharePointSubSiteListBatchRequest;
import com.asigra.model.user.User;
import com.asigra.service.BatchService;
import com.asigra.service.CacheService;
import com.asigra.service.DriveService;
import com.asigra.service.ExchangeService;
import com.asigra.service.utils.CommonUtils;
import com.asigra.service.utils.ExceptionReportUtils;
import com.asigra.service.utils.GraphUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DriveServiceImpl implements DriveService {

    private final ExchangeService exchangeService;
    private final GraphUtils graphUtils;
    private final CommonUtils commonUtils;
    private static final Logger logger = LogManager.getLogger(DriveServiceImpl.class);
    private final ExceptionReportUtils exceptionReportUtils;
    private final BatchService batchService;
    private final CacheService cacheService;

    @Autowired
    public DriveServiceImpl(@Lazy ExchangeService exchangeService,
                            @Lazy GraphUtils graphUtils,
                            @Lazy CommonUtils commonUtils,
                            @Lazy CacheService cacheService,
                            @Lazy ExceptionReportUtils exceptionReportUtils,
                            @Lazy BatchService batchService) {
        this.commonUtils = commonUtils;
        this.graphUtils = graphUtils;
        this.exchangeService = exchangeService;
        this.cacheService = cacheService;
        this.exceptionReportUtils = exceptionReportUtils;
        this.batchService = batchService;
    }

    @Override
    public List<SharePoint> getSharePointRootFoldersInDomain(String domain, boolean realTime) {
        logger.debug(" getSharePointRootFoldersInDomain drive service function executed", domain, realTime);
        List<SharePoint> allSharePointRootFoldersInADomain = null;
        String sharePointRootFolderURL = GraphAPIURLS.ALL_SHAREPOINT_ROOT_FOLDERS;
        try {
            if (!realTime) {
                logger.debug(" get sharepoints from cache if available");
                Optional<DomainEntity> domainOneDriveEntity = cacheService.getDomainEntityFromDB(domain);
                if (domainOneDriveEntity.isPresent()) {
                    logger.debug(" domain sharepoint details already present in the cache table ");
                    logger.debug(" count of all cached user share points" + " allSharePointSites " + domainOneDriveEntity.get().getSharePoints().size());
                    allSharePointRootFoldersInADomain = domainOneDriveEntity.get().getSharePoints();
                } else {
                    logger.debug(" domain sharepoint details not present in the cache table, not fetching the details using batch service now ");
                }
            } else {
                allSharePointRootFoldersInADomain = getRootSharePointSites(
                        graphUtils.getObjectFromGraphService(sharePointRootFolderURL, SharePoint.class, domain)
                );

                cacheService.cacheSharePointsToDB(domain, allSharePointRootFoldersInADomain);
            }

        } catch (GenericException genericException) {
            exceptionReportUtils.throwExceptionIfSharePointFoldersInDomainFetchFailed(domain, commonUtils.getCauseForException(genericException));
        }

        if (allSharePointRootFoldersInADomain != null) {
            logger.debug(" count of share point root folders in a domain " + allSharePointRootFoldersInADomain.size());
        }

        return allSharePointRootFoldersInADomain;
    }

    @Override
    public List<SharePointSiteContent> getSharePointSiteContents(String domain, String siteId) {
        logger.debug(" getSharePointSiteContents drive service function executed", domain, siteId);
        SharePointSiteContent sharePointSiteContent = batchService.fetchGenericDataFromGraphUsingBatch(domain, getSharePointSiteContentBatchRequestList(siteId), SharePointSiteContent.class);
        return Collections.singletonList(sharePointSiteContent);
    }

    @Override
    public List<OneDrive> getOneDriveRootFoldersForAllUsersInDomain(String domain, boolean realTime) {
        logger.debug(" getUserOneDriveData drive service function executed", domain, realTime);
        List<OneDrive> allUserOneDrives = null;

        if (!realTime) {
            logger.debug(" get onedrives from cache if available");
            Optional<DomainEntity> domainOneDriveEntity = cacheService.getDomainEntityFromDB(domain);
            if (domainOneDriveEntity.isPresent()) {
                logger.debug(" domain onedrive details already present in the cache table ");
                logger.debug(" count of all cached user one drives" + " allUserOneDrives " + domainOneDriveEntity.get().getOneDrives().size());
                allUserOneDrives = domainOneDriveEntity.get().getOneDrives();
            } else {
                logger.debug(" domain onedrive details not present in the cache table, not fetching the details using batch service now ");
            }
        } else {
            List<User> userList = exchangeService.getUserList(domain, false);
            allUserOneDrives = getUserOneDriveDataFromBatch(domain, userList);
            cacheService.cacheOneDrivesToDB(domain, allUserOneDrives);
        }
        return allUserOneDrives;
    }

    @Override
    public List<OneDrive> getContentsOfTheRootDrive(String userId, String driveId, String domain) {
        logger.debug(" getContentsOfTheRootDrive drive service function executed", userId, driveId, domain);
        List<OneDrive> userOneDriveContentsOfAFolder = new ArrayList<>();
        try {
            String userOneDriveSubFoldersURL = String.format(GraphAPIURLS.USER_ONEDRIVE_DETAILS, (Object[]) new String[]{userId, driveId});
            userOneDriveContentsOfAFolder = graphUtils.getObjectFromGraphService(userOneDriveSubFoldersURL, OneDrive.class, domain);
            userOneDriveContentsOfAFolder.forEach(oneDrive -> oneDrive.setOneDriveUserId(userId));
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfOneDriveContentsFetchFailed(userId, driveId, commonUtils.getCauseForException(e));
        }
        logger.debug(" Count of all the sub folders and files " + userOneDriveContentsOfAFolder.size());

        return userOneDriveContentsOfAFolder;
    }

    @Override
    public List<OneDrive> getContentsOfOneDriveFolder(String userId, String itemId, String domain) {
        logger.debug(" getContentsOfOneDriveFolder drive service function executed", userId, itemId, domain);
        List<OneDrive> oneDrives = new ArrayList<>();

        String userOneDriveFilesURL = String.format(GraphAPIURLS.USER_ONEDRIVE_ITEM_DETAILS, (Object[]) new String[]{userId, itemId});
        try {
            oneDrives = graphUtils.getObjectFromGraphService(userOneDriveFilesURL, OneDrive.class, domain);
            addOneDriveUserIdForOneDrives(userId, oneDrives);
        } catch (GenericException genericException) {
            exceptionReportUtils.throwExceptionIfOneDriveFolderContentsFetchFailed(userId, itemId, commonUtils.getCauseForException(genericException));
        }
        logger.debug(" Count of all the files in the one drive folder " + oneDrives.size());

        return oneDrives;
    }

    private void addOneDriveUserIdForOneDrives(String userId, List<OneDrive> oneDrives) {
        oneDrives.forEach(oneDrive -> oneDrive.setOneDriveUserId(userId));
    }

    private List<SharePoint> getRootSharePointSites(List<SharePoint> allSharePointSites) {
        logger.debug(" getRootSharePointSites drive service function executed" + " number of all allSharePointSites " + allSharePointSites.size());
        allSharePointSites = allSharePointSites.stream()
                .filter(sharePoint -> sharePoint.getRoot() != null)
                .collect(Collectors.toList());
        return allSharePointSites;
    }

    private List<BatchRequest> getSharePointSiteContentBatchRequestList(String siteId) {
        List<BatchRequest> sharePointContentBatchRequestList = new ArrayList<>();

        SharePointSubSiteBatchRequest sharePointSubSiteBatchRequest = new SharePointSubSiteBatchRequest(
                KeyConstants.SHAREPOINT_SUBSITES_BATCH_ID,
                String.format(GraphAPIURLS.SHAREPOINT_SUBSITES_BATCH_REQUEST_URL, siteId),
                RequestMethod.GET.name()
        );

        SharePointSubSiteListBatchRequest sharePointSubSiteListBatchRequest = new SharePointSubSiteListBatchRequest(
                KeyConstants.SHAREPOINT_SUBSITE_LISTS_BATCH_ID,
                String.format(GraphAPIURLS.SHAREPOINT_SUBSITE_LISTS_BATCH_REQUEST_URL, siteId),
                RequestMethod.GET.name()
        );

        sharePointContentBatchRequestList.add(sharePointSubSiteBatchRequest);
        sharePointContentBatchRequestList.add(sharePointSubSiteListBatchRequest);

        return sharePointContentBatchRequestList;
    }

    @Override
    public List<OneDrive> getUserOneDriveDataFromBatch(String domain, List<User> userList) {
        List<OneDrive> allUserOneDrives;
        allUserOneDrives = batchService.fetchOneDriveDataFromGraphUsingBatch(
                domain,
                userList,
                OneDrive.class,
                OneDriveRequest.class,
                OneDriveResponse.class,
                GraphAPIURLS.USER_ALL_ONEDRIVES_BATCH_REQUEST_URL);
        logger.debug(" count of all updated user one drives" + " allUserOneDrives " + allUserOneDrives.size() + " for domain " + domain);
        return allUserOneDrives;
    }
}
