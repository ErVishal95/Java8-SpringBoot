package com.asigra.service.impl;

import com.asigra.model.common.File;
import com.asigra.model.publicfolder.PublicFolder;
import com.asigra.service.DomainService;
import com.asigra.service.EWSService;
import com.asigra.service.utils.ExceptionReportUtils;
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.exception.service.local.ServiceLocalException;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.search.FindFoldersResults;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.FolderView;
import microsoft.exchange.webservices.data.search.ItemView;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@PropertySource("classpath:ews.properties")
public class EWSServiceImpl implements EWSService {

    private static final Logger logger = LogManager.getLogger(EWSServiceImpl.class);
    private final Environment env;
    private final DomainService domainService;
    private final ExceptionReportUtils exceptionReportUtils;

    @Autowired
    public EWSServiceImpl(@Lazy Environment env,
                          @Lazy ExceptionReportUtils exceptionReportUtils,
                          @Lazy DomainService domainService) {
        this.env = env;
        this.exceptionReportUtils = exceptionReportUtils;
        this.domainService = domainService;
    }

    @Override
    public List<PublicFolder> getPublicRootFolders(String domain) {
        logger.debug(" getPublicRootFolders ews service function executed", domain);
        List<PublicFolder> allPublicFolders = new ArrayList<>();
        try {
            allPublicFolders = getRootFolders(domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicRootFoldersFetchFailed(e.getMessage());
        }

        if (allPublicFolders != null) {
            logger.debug(" Count of all the existing public folders " + allPublicFolders.size());
        }
        return allPublicFolders;
    }

    @Override
    public List<PublicFolder> getSubFoldersOfAPublicFolder(String folderId, String domain) {
        logger.debug(" getSubFoldersOfAPublicFolder ews service function executed", folderId, domain);
        List<PublicFolder> allSubFolders = new ArrayList<>();
        try {
            allSubFolders = getSubFolders(folderId, domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicSubFoldersFetchFailed(folderId, e.getMessage());
        }
        if (allSubFolders != null) {
            logger.debug(" Count of all the sub-folders of a public folder " + allSubFolders.size());
        }

        return allSubFolders;
    }

    @Override
    public List<File> getAllFilesOfAPublicFolder(String folderId, String domain) {
        logger.debug(" getAllFilesOfAPublicFolder ews service function executed", folderId, domain);
        List<File> allFilesInAPublicFolder = new ArrayList<>();
        try {
            allFilesInAPublicFolder = getFilesInAPublicFolder(folderId, domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicFolderFilesFetchFailed(folderId, e.getMessage());
        }

        if (allFilesInAPublicFolder != null) {
            logger.debug(" Count of all the files in a public folder " + allFilesInAPublicFolder.size());
        }

        return allFilesInAPublicFolder;

    }

    private List<PublicFolder> getRootFolders(String domain) {
        logger.debug(" getRootFolders ews service function executed", domain);
        List<PublicFolder> publicFolderList = null;
        try {
            publicFolderList = new ArrayList<>();
            FolderView folderView = new FolderView(Integer.valueOf(Objects.requireNonNull(env.getProperty("public.folder.search.page.size"))));
            FindFoldersResults findResults = getExchangeEWSService(domain).findFolders(WellKnownFolderName.PublicFoldersRoot, folderView);
            for (Folder folder : findResults.getFolders()) {
                PublicFolder publicFolder = createFolderObj(folder);
                publicFolderList.add(publicFolder);
            }
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicRootFoldersFetchFailed(e.getMessage());
        }

        return publicFolderList;
    }

    private List<PublicFolder> getSubFolders(String folderId, String domain) {
        logger.debug(" getSubFolders ews service function executed", folderId, domain);
        List<PublicFolder> subFolderList = null;
        try {
            subFolderList = new ArrayList<>();
            FolderId publicFolderId = new FolderId(folderId);
            FolderView folderView = new FolderView(Integer.valueOf(Objects.requireNonNull(env.getProperty("public.folder.search.page.size"))));
            FindFoldersResults folders = getExchangeEWSService(domain).findFolders(publicFolderId, folderView);

            for (Folder subFolder : folders) {
                PublicFolder publicFolder = createFolderObj(subFolder);
                subFolderList.add(publicFolder);
            }
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicSubFoldersFetchFailed(folderId, e.getMessage());
        }

        return subFolderList;

    }

    private List<File> getFilesInAPublicFolder(String folderId, String domain) {
        logger.debug(" getFilesInAPublicFolder ews service function executed", folderId, domain);
        List<File> allFilesInAPublicFolder = null;
        try {
            allFilesInAPublicFolder = new ArrayList<>();
            FolderId publicFolder = new FolderId(folderId);
            ItemView fileSearch = new ItemView(Integer.valueOf(Objects.requireNonNull(env.getProperty("public.folder.file.search.page.size"))));
            FindItemsResults<Item> files = getExchangeEWSService(domain).findItems(publicFolder, fileSearch);
            for (Item file : files) {
                File email = new File();
                email.setId(file.getId().toString());
                email.setSubject(file.getSubject());

                allFilesInAPublicFolder.add(email);
            }
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfPublicFolderFilesFetchFailed(folderId, e.getMessage());
        }

        return allFilesInAPublicFolder;

    }

    private PublicFolder createFolderObj(Folder subFolder) throws ServiceLocalException {
        PublicFolder publicFolder = new PublicFolder();

        publicFolder.setId(subFolder.getId().toString());
        publicFolder.setDisplayName(subFolder.getDisplayName());
        return publicFolder;
    }

    private ExchangeService getExchangeEWSService(String domain) {
        return domainService.getExchangeEWSService(domain);
    }
}