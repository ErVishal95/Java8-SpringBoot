package com.asigra.service.impl;

import com.asigra.constants.GraphAPIURLS;
import com.asigra.constants.KeyConstants;
import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.archive.batch.request.ArchiveFileRequest;
import com.asigra.model.archive.batch.request.ArchiveFolderRequest;
import com.asigra.model.archive.batch.response.ArchiveFolderResponse;
import com.asigra.model.common.File;
import com.asigra.model.common.batch.BatchRequest;
import com.asigra.model.domain.DomainEntity;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.calendar.Calendar;
import com.asigra.model.exchange.calendar.CalendarEvent;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.contact.batch.request.ContactBatchRequest;
import com.asigra.model.exchange.contact.batch.request.ContactFolderBatchRequest;
import com.asigra.model.exchange.journal.Journal;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.mailbox.batch.request.ExchangeMailboxBatchRequest;
import com.asigra.model.exchange.task.TaskFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.exchange.task.batch.request.TaskBatchRequest;
import com.asigra.model.exchange.task.batch.request.TaskFolderBatchRequest;
import com.asigra.model.user.PaginatedUser;
import com.asigra.model.user.User;
import com.asigra.service.BatchService;
import com.asigra.service.CacheService;
import com.asigra.service.ExchangeService;
import com.asigra.service.utils.CommonUtils;
import com.asigra.service.utils.ExceptionReportUtils;
import com.asigra.service.utils.GraphUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ExchangeServiceImpl implements ExchangeService {

    private static final Logger logger = LogManager.getLogger(ExchangeServiceImpl.class);
    private final CommonUtils commonUtils;
    private final GraphUtils graphUtils;
    private final ExceptionReportUtils exceptionReportUtils;
    private final BatchService batchService;
    private final CacheService cacheService;
    private final Environment env;

    @Autowired
    public ExchangeServiceImpl(@Lazy CommonUtils commonUtils,
                               @Lazy GraphUtils graphUtils,
                               @Lazy ExceptionReportUtils exceptionReportUtils,
                               @Lazy BatchService batchService,
                               @Lazy CacheService cacheService,
                               @Lazy Environment environment) {
        this.commonUtils = commonUtils;
        this.graphUtils = graphUtils;
        this.exceptionReportUtils = exceptionReportUtils;
        this.batchService = batchService;
        this.cacheService = cacheService;
        this.env = environment;
    }

    @Override
    public List<User> getUserList(String domain, boolean licensedUsersOnly) {
        logger.debug(" getUserList exchange service function executed", domain);
        List<User> userList = null;
        List<PaginatedUser> paginatedUsers = new ArrayList<>();
        try {
            userList = getPaginatedUsers(GraphAPIURLS.ALL_USERS, paginatedUsers, domain, licensedUsersOnly);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExistingUserListFetchFailed(commonUtils.getCauseForException(e));
        }

        if (userList != null) {
            logger.debug(" Count of all the existing users " + userList.size());
        }
        return userList;
    }

    @Override
    public List<User> getGroupList(String domain) {
        logger.debug(" getGroupList exchange service function executed", domain);
        List<User> allExistingGroups = null;
        try {
            allExistingGroups = graphUtils.getObjectFromGraphService(GraphAPIURLS.ALL_GROUPS, User.class, domain);

        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExistingGroupListFetchFailed(commonUtils.getCauseForException(e));
        }

        if (allExistingGroups != null) {
            logger.debug(" Count of all the existing groups " + allExistingGroups.size());
        }

        return allExistingGroups;
    }

    @Override
    public List<ExchangeObject> getUserRootExchangeFolders(String userId, String domain) {
        logger.debug(" getUserRootExchangeFolders exchange service function executed", userId, domain);
        ExchangeObject exchangeObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getExchangeMailboxBatchRequests(userId), ExchangeObject.class);
        return Collections.singletonList(exchangeObject);
    }

    @Override
    public List<ExchangeFolder> getMailboxSubFolders(String userId, String folderId, String domain) {
        logger.debug(" getMailboxSubFolders exchange service function executed", userId, folderId, domain);
        List<ExchangeFolder> allChildFolders = null;
        String childFoldersURL = String.format(GraphAPIURLS.USER_MAILBOX_CHILD_FOLDER_DETAILS, (Object[]) new String[]{userId, folderId});
        try {
            allChildFolders = graphUtils.getObjectFromGraphService(childFoldersURL, ExchangeFolder.class, domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExchangeSubFoldersFetchFailed(userId, folderId, commonUtils.getCauseForException(e));
        }

        if (allChildFolders != null) {
            logger.debug(" Count of all the sub folders in the publicfolder " + allChildFolders.size());
        }

        return allChildFolders;
    }

    @Override
    public List<File> getAllEmailsOfFolder(String userId, String folderId, String domain) {
        logger.debug(" getAllFilesOfFolder exchange service function executed", userId, folderId, domain);
        List<File> allEmailsInAFolder = null;
        String mailFoldersMessagesURL = String.format(GraphAPIURLS.USER_MAILBOX_FOLDER_MSGS, (Object[]) new String[]{userId, folderId});
        try {
            allEmailsInAFolder = graphUtils.getObjectFromGraphService(mailFoldersMessagesURL, File.class, domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExchangeFilesFetchFailed(userId, folderId, commonUtils.getCauseForException(e));
        }

        if (allEmailsInAFolder != null) {
            logger.debug(" Count of all the emails in the public folder " + allEmailsInAFolder.size());
        }

        return allEmailsInAFolder;
    }

    @Override
    public List<ArchiveObject> getUserRootArchiveFolders(String domain, String userId) {
        logger.debug(" getUserArchiveFolderContents exchange service function executed", userId, userId);
        ArchiveObject archiveObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getArchiveBatchRequests(userId), ArchiveObject.class);
        return Collections.singletonList(archiveObject);
    }

    @Override
    public List<ArchiveObject> getUserArchiveFolderContents(String domain, String userId, String folderId) {
        logger.debug(" getUserArchiveFolderContents exchange service function executed", domain, userId, folderId);
        ArchiveObject archiveObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getArchiveFolderContentsBatchRequests(userId, folderId), ArchiveObject.class);
        return Collections.singletonList(archiveObject);
    }

    @Override
    public List<Calendar> getUserRootCalendars(String userId, String domain) {
        logger.debug(" getUserRootCalendars exchange service function executed", userId, domain);
        List<Calendar> userRootCalendars = null;
        String userRootCalendarsURL = String.format(GraphAPIURLS.USER_ROOT_CALENDARS, (Object[]) new String[]{userId});
        logger.debug(" userRootCalendarsURL " + userRootCalendarsURL);
        try {
            userRootCalendars = graphUtils.getObjectFromGraphService(userRootCalendarsURL, Calendar.class, domain);
        } catch (Exception e) {
            logger.error(e);
        }

        if (userRootCalendars != null) {
            logger.debug(" Count of all the existing user calendar root folders " + userRootCalendars.size());
        }

        return userRootCalendars;
    }

    @Override
    public List<Journal> getUserJournals(String userId, String domain) {
        logger.debug(" getUserJournals exchangeutils function executed", userId, domain);
        List<Journal> userJournals = null;

        String userJournalsURL = String.format(GraphAPIURLS.USER_JOURNALS, (Object[]) new String[]{userId});
        logger.debug(" userJournalsURL " + userJournalsURL);

        try {
            userJournals = graphUtils.getObjectFromGraphService(userJournalsURL, Journal.class, domain);
        } catch (Exception e) {
            logger.error(e);
        }

        if (userJournals != null) {
            logger.debug(" Count of all the existing user journals " + userJournals.size());
        }

        return userJournals;
    }


    @Override
    public List<CalendarEvent> getUserCalendarEvents(String userId, String domain, String calenderId) {
        logger.debug(" getUserCalendarEvents exchangeutils function executed", userId, domain);
        List<CalendarEvent> userCalendarEvents = new ArrayList<>();
        String userCalenderEventsURL = String.format(GraphAPIURLS.USER_CALENDAR_EVENTS, (Object[]) new String[]{userId, calenderId});
        logger.debug(" userCalenderEventsURL " + userCalenderEventsURL);
        try {
            userCalendarEvents = graphUtils.getObjectFromGraphService(userCalenderEventsURL, CalendarEvent.class, domain);
        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfExchangeRootFoldersFetchFailed(userId, commonUtils.getCauseForException(e));
        }

        if (userCalendarEvents != null) {
            logger.debug(" Count of all the existing user root folders " + userCalendarEvents.size());
        }

        return userCalendarEvents;
    }

    @Override
    public List<ContactObject> getUserContactFolderContents(String userId, String domain, String contactFolderId) {
        logger.debug(" getUserContactFolderContents exchangeutils function executed", userId, domain, contactFolderId);
        ContactObject contactObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getUserContactsBatchRequestList(userId, contactFolderId), ContactObject.class);
        return Collections.singletonList(contactObject);
    }

    @Override
    public List<TaskObject> getUserTaskFolderContents(String userId, String domain, String taskFolderId) {
        logger.debug(" getUserTaskFolderContents exchangeutils function executed", userId, domain, taskFolderId);
        TaskObject taskFolderObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getUserTasksBatchRequestList(userId, taskFolderId), TaskObject.class);

        if (taskFolderId == null) {
            Optional<TaskFolder> folder = taskFolderObject.getTaskFolders().stream().findFirst();
            String folderId = null;
            if (folder.isPresent()) {
                folderId = folder.get().getId();
            }
            TaskObject taskObject = batchService.fetchGenericDataFromGraphUsingBatch(domain, getUserTasksBatchRequestList(userId, folderId), TaskObject.class);
            taskFolderObject.getTasks().addAll(taskObject.getTasks());
            taskFolderObject.getTaskFolders().removeIf(taskFolder -> taskFolder.getName().equalsIgnoreCase("tasks"));

        }
        return Collections.singletonList(taskFolderObject);
    }


    private List<User> getPaginatedUsers(String graphURL, List<PaginatedUser> allExistingPagingUsers, String domain,
                                         boolean licensedUsersOnly) {
        try {
            JSONObject jsonObject = graphUtils.getObjectFromGraphService(graphURL, domain);
            List<User> existingUsers = commonUtils.convertJSONObjectToList(jsonObject, User.class);

            List<User> usersWithLicenses = existingUsers
                    .stream()
                    .filter(user -> !licensedUsersOnly || !user.getAssignedLicenses().isEmpty())
                    .map(user -> new User(user.getId(), user.getDisplayName(), user.getUserPrincipalName()))
                    .collect(Collectors.toList());

            String nextLink = null;
            nextLink = checkForNextLink(graphURL, jsonObject, nextLink);
            PaginatedUser paginatedUser = new PaginatedUser();
            paginatedUser.setUserList(usersWithLicenses);
            allExistingPagingUsers.add(paginatedUser);

            if (nextLink != null) {
                getPaginatedUsers(URLDecoder.decode(nextLink, StandardCharsets.UTF_8.name()), allExistingPagingUsers, domain, licensedUsersOnly);

            }
            return allExistingPagingUsers.stream().map(PaginatedUser::getUserList).flatMap(Collection::stream).distinct().collect(Collectors.toList());

        } catch (Exception e) {
            logger.error("Error in fetching paginated users ", e.getMessage());
            throw commonUtils.getExceptionObject(e);
        }
    }

    private String checkForNextLink(String graphURL, JSONObject jsonObject, String nextLink) {
        try {
            nextLink = jsonObject.getString(env.getProperty("next_link_key"));

        } catch (Exception e) {
            logger.error(" No value for @odata.nextLink for graph url " + graphURL + "exception " + e.getMessage());
        }
        return nextLink;
    }

    @Override
    public List<User> getUsersHavingArchiveFolders(String domain, boolean realTime) {
        logger.debug(" getUsersHavingArchiveFolders exchange service function executed", domain, realTime);
        List<User> allUserWithArchiveFolders = null;

        if (!realTime) {
            logger.debug(" get users with archive folders from cache if available");
            Optional<DomainEntity> domainDBObj = cacheService.getDomainEntityFromDB(domain);
            if (domainDBObj.isPresent()) {
                logger.debug(" domain for which users with archive folders need to be fecthed are available in the cache table ");

                allUserWithArchiveFolders = domainDBObj.get().getUsersWithArchiveFolders();

                logger.debug(" count of all cached users with archive folders" + " allUserWithArchiveFolders " + allUserWithArchiveFolders.size());
            } else {
                logger.debug(" users with archive folders not present in the cache table, not fetching the details using batch service now ");
            }
        } else {

            List<User> userList = getUserList(domain, false);
            allUserWithArchiveFolders = getUsersWithArchiveEnabledFromBatch(domain, userList);
            cacheService.cacheUserWithArchiveFoldersToDB(domain, allUserWithArchiveFolders);
        }

        return allUserWithArchiveFolders;
    }

    @Override
    public List<User> getUsersWithArchiveEnabledFromBatch(String domain, List<User> userList) {
        List<User> allUserWithArchiveFolders;
        Map<String, User> userIdMap = userList.stream().collect(
                Collectors.toMap(User::getId, Function.identity()));

        allUserWithArchiveFolders = batchService.fetchUsersWithArchiveEnabledFromGraphUsingBatch(
                domain,
                userList,
                User.class,
                ArchiveFolderRequest.class,
                ArchiveFolderResponse.class,
                GraphAPIURLS.USER_ARCHIVE_FOLDERS_BATCH_REQUEST_URL);

        allUserWithArchiveFolders
                .forEach(user -> {
                    User userObj = userIdMap.get(user.getId());
                    user.setDisplayName(userObj.getDisplayName());
                    user.setUserPrincipalName(userObj.getUserPrincipalName());
                });
        return allUserWithArchiveFolders;
    }

    private List<BatchRequest> getExchangeMailboxBatchRequests(String userId) {
        List<BatchRequest> exchangeMailboxBatchRequests = new ArrayList<>();
        exchangeMailboxBatchRequests.add(createExchangeMailboxBatchRequest(userId));
        return exchangeMailboxBatchRequests;
    }

    public List<BatchRequest> getArchiveBatchRequests(String userId) {
        List<BatchRequest> archiveBatchRequests = new ArrayList<>();
        archiveBatchRequests.add(createArchiveBatchRequest(userId));
        return archiveBatchRequests;
    }

    private List<BatchRequest> getArchiveFolderContentsBatchRequests(String userId, String folderId) {
        List<BatchRequest> archiveBatchRequests = new ArrayList<>();
        archiveBatchRequests.add(createArchiveFolderBatchRequest(userId, folderId));
        archiveBatchRequests.add(createArchiveFileBatchRequest(userId, folderId));
        return archiveBatchRequests;
    }

    private ExchangeMailboxBatchRequest createExchangeMailboxBatchRequest(String userId) {
        return new ExchangeMailboxBatchRequest(
                KeyConstants.EXCHANGE_MAILBOX_BATCH_ID,
                String.format(GraphAPIURLS.USER_EXCHANGE_MAILBOX_BATCH_REQUEST_URL, userId),
                RequestMethod.GET.name()
        );
    }

    private ArchiveFolderRequest createArchiveBatchRequest(String userId) {
        return new ArchiveFolderRequest(
                KeyConstants.ARCHIVE_BATCH_ID,
                String.format(GraphAPIURLS.USER_ARCHIVE_BATCH_REQUEST_URL, userId),
                RequestMethod.GET.name()
        );
    }

    private ArchiveFolderRequest createArchiveFolderBatchRequest(String userId, String folderId) {
        return new ArchiveFolderRequest(
                KeyConstants.ARCHIVE_SUB_FOLDERS_BATCH_ID,
                String.format(GraphAPIURLS.USER_ARCHIVE_SUB_FOLDERS_BATCH_REQUEST_URL, userId, folderId),
                RequestMethod.GET.name()
        );
    }

    private ArchiveFileRequest createArchiveFileBatchRequest(String userId, String folderId) {
        return new ArchiveFileRequest(
                KeyConstants.ARCHIVE_FOLDERS_FILES_BATCH_ID,
                String.format(GraphAPIURLS.USER_ARCHIVE_FOLDER_FILES_BATCH_REQUEST_URL, userId, folderId),
                RequestMethod.GET.name()
        );
    }

    private List<BatchRequest> getUserContactsBatchRequestList(String userId, String contactFolderId) {
        List<BatchRequest> userContactsBatchRequests = new ArrayList<>();

        if (Objects.isNull(contactFolderId)) {
            userContactsBatchRequests.add(createUserContactFolderBatchRequest(userId));
            userContactsBatchRequests.add(createUserContactBatchRequest(userId));

        } else {
            userContactsBatchRequests.add(createUserContactSubFolderBatchRequest(userId, contactFolderId));
            userContactsBatchRequests.add(createUserSubFolderContactBatchRequest(userId, contactFolderId));
        }
        return userContactsBatchRequests;
    }

    private List<BatchRequest> getUserTasksBatchRequestList(String userId, String taskFolderId) {
        List<BatchRequest> userTaskBatchRequests = new ArrayList<>();

        if (Objects.isNull(taskFolderId)) {
            userTaskBatchRequests.add(createUserTaskFolderBatchRequest(userId));

        } else {
            userTaskBatchRequests.add(createUserFolderTaskBatchRequest(userId, taskFolderId));
        }
        return userTaskBatchRequests;
    }

    private ContactFolderBatchRequest createUserContactFolderBatchRequest(String userId) {
        return new ContactFolderBatchRequest(
                KeyConstants.EXCHANGE_CONTACT_FOLDERS_BATCH_ID,
                String.format(GraphAPIURLS.USER_ROOT_CONTACTS_FOLDERS_BATCH_REQUEST_URL, userId),
                RequestMethod.GET.name()
        );
    }

    private ContactBatchRequest createUserContactBatchRequest(String userId) {
        return new ContactBatchRequest(
                KeyConstants.EXCHANGE_CONTACTS_BATCH_ID,
                String.format(GraphAPIURLS.USER_ROOT_CONTACTS_BATCH_REQUEST_URL, userId),
                RequestMethod.GET.name()
        );
    }

    private ContactFolderBatchRequest createUserContactSubFolderBatchRequest(String userId, String contactFolderId) {
        return new ContactFolderBatchRequest(
                KeyConstants.EXCHANGE_CONTACT_FOLDERS_BATCH_ID,
                String.format(GraphAPIURLS.USER_CONTACT_SUB_FOLDERS_BATCH_REQUEST_URL, userId, contactFolderId),
                RequestMethod.GET.name()
        );
    }

    private ContactBatchRequest createUserSubFolderContactBatchRequest(String userId, String contactFolderId) {
        return new ContactBatchRequest(
                KeyConstants.EXCHANGE_CONTACTS_BATCH_ID,
                String.format(GraphAPIURLS.USER_CONTACTS_IN_FOLDER_BATCH_REQUEST_URL, userId, contactFolderId),
                RequestMethod.GET.name()
        );
    }

    private TaskFolderBatchRequest createUserTaskFolderBatchRequest(String userId) {
        return new TaskFolderBatchRequest(
                KeyConstants.EXCHANGE_TASK_FOLDERS_BATCH_ID,
                String.format(GraphAPIURLS.USER_ROOT_TASK_FOLDERS, userId),
                RequestMethod.GET.name()
        );
    }

    private TaskBatchRequest createUserFolderTaskBatchRequest(String userId, String taskFolderId) {
        return new TaskBatchRequest(
                KeyConstants.EXCHANGE_TASKS_BATCH_ID,
                String.format(GraphAPIURLS.USER_FOLDER_TASKS, userId, taskFolderId),
                RequestMethod.GET.name()
        );
    }


}

