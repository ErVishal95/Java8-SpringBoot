package com.asigra.service.impl;

import com.asigra.constants.KeyConstants;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.user.User;
import com.asigra.service.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Service
@PropertySource("classpath:domain.properties")
public class JobServiceImpl implements JobService {

    private static final Logger logger = LogManager.getLogger(JobServiceImpl.class);
    private final DomainService domainService;
    private final ExchangeService exchangeService;
    private final DriveService driveService;
    private final CacheService cacheService;
    private final Environment env;

    @Autowired
    public JobServiceImpl(@Lazy DomainService domainService,
                          @Lazy ExchangeService exchangeService,
                          @Lazy DriveService driveService,
                          @Lazy CacheService cacheService,
                          @Lazy Environment env) {
        this.domainService = domainService;
        this.exchangeService = exchangeService;
        this.driveService = driveService;
        this.cacheService = cacheService;
        this.env = env;
    }

    @Override
    @Scheduled(initialDelayString = KeyConstants.ONE_DRIVE_CACHE_INITIAL_DELAY, fixedRateString = KeyConstants.ONE_DRIVE_CACHE_RUN_INTERVAL)
    public void cacheDomainLevelDetails() {
        logger.debug(" cacheDomainLevelDetails job service method executed ");
        String[] allDomains = Objects.requireNonNull(env.getProperty("available_domains")).split(",");

        for (String domain : allDomains) {
            Instant startTimeOfBatchExecutionForDomain = Instant.now();
            getDomainProperties(domain);
            List<User> userList = exchangeService.getUserList(domain, false);
            cacheOneDrivesForAllExistingDomains(domain, userList);
            cacheSharePointsForAllExistingDomains(domain);
            cacheUsersWithArchiveFoldersForAllExistingDomains(domain, userList);
            Instant endTimeOfBatchExecutionForDomain = Instant.now();

            logger.debug(" total time for job execution for domain " + domain + " in seconds " +
                    Duration.between(startTimeOfBatchExecutionForDomain, endTimeOfBatchExecutionForDomain).getSeconds());
        }
    }

    private void cacheOneDrivesForAllExistingDomains(String domain, List<User> userList) {
        List<OneDrive> allOneDrives = driveService.getUserOneDriveDataFromBatch(domain, userList);
        logger.debug(" caching the onedrives to database for domain " + domain);
        cacheService.cacheOneDrivesToDB(domain, allOneDrives);
    }

    private void cacheSharePointsForAllExistingDomains(String domain) {
        List<SharePoint> allSharePoints = driveService.getSharePointRootFoldersInDomain(domain, true);
        logger.debug(" caching the sharepoints to database for domain " + domain);
        cacheService.cacheSharePointsToDB(domain, allSharePoints);
    }

    private void cacheUsersWithArchiveFoldersForAllExistingDomains(String domain, List<User> userList) {
        logger.debug(" caching the list of all users with archive enabled to database for domain " + domain);
        List<User> usersWithArchiveEnabled = exchangeService.getUsersWithArchiveEnabledFromBatch(domain, userList);
        cacheService.cacheUserWithArchiveFoldersToDB(domain, usersWithArchiveEnabled);
    }

    private void getDomainProperties(String domain) {
        String username = env.getProperty(domain + "_user_name");
        String password = env.getProperty(domain + "_password");
        domainService.loadDomainProperties(domain, username, password);
    }
}

