package com.asigra.service.utils;

import com.asigra.exception.GenericException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.List;

@Service
public class CommonUtils {
    private final Environment env;
    private static final Logger logger = LogManager.getLogger(CommonUtils.class);

    @Autowired
    public CommonUtils(@Lazy Environment env) {
        this.env = env;
    }


    public <T> List<T> convertJSONObjectToList(JSONObject jsonObject, Class<T> requestedClassType) {
        List<T> requestedObject = null;
        try {
            requestedObject = convertJSONStringToList(jsonObject.getString(env.getProperty("graph_api_response_key")), requestedClassType);
        } catch (Exception e) {
            logger.error(" exception in getObjectTypeFromJSONObject function ", e);
        }
        return requestedObject;
    }

    public <T> List<T> convertJSONStringToList(String jsonArray, Class<T> clazz) {
        Type typeOfT = TypeToken.getParameterized(List.class, clazz).getType();
        return new Gson().fromJson(jsonArray, typeOfT);
    }

    public String getCauseForException(Throwable throwable) {
        logger.debug(" getCauseForException function of commonutils service executed with throwable " + throwable);
        GenericException genericException = getExceptionObject(throwable);
        return genericException.getError() + " " + genericException.getErrorCause();
    }

    public GenericException getExceptionObject(Throwable throwable) {
        logger.debug(" getExceptionObject function of commonutils service executed with throwable " + throwable);
        GenericException genericException;
        if (throwable instanceof GenericException) {
            genericException = (GenericException) throwable;
        } else {
            genericException = (GenericException) throwable.getCause();
        }
        return genericException;
    }
}