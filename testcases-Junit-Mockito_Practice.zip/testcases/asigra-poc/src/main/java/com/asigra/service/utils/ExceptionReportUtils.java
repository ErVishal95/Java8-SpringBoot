package com.asigra.service.utils;

import com.asigra.exception.AccessTokenInvalidException;
import com.asigra.exception.GenericException;
import com.asigra.model.common.batch.BatchRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

@Service
@PropertySource("classpath:exception_messages.properties")
public class ExceptionReportUtils {

    private final Environment env;

    private static final Logger logger = LogManager.getLogger(ExceptionReportUtils.class);
    private static final String SPACE = " ";

    @Autowired
    public ExceptionReportUtils(@Lazy Environment env) {
        this.env = env;
    }

    public void throwExceptionIfExistingUserListFetchFailed(String cause) {
        logger.debug(" throwExceptionIfExistingUserListFetchFailed method executed with cause " + cause);
        logger.error(env.getProperty("EXCHANGE_USER_FETCH_FAILED") + SPACE + cause);
        throw new GenericException(env.getProperty("EXCHANGE_USER_FETCH_FAILED") + SPACE, cause);
    }

    public void throwExceptionIfExistingGroupListFetchFailed(String cause) {
        logger.debug(" throwExceptionIfExistingGroupListFetchFailed method executed with cause " + cause);
        logger.error(env.getProperty("EXCHANGE_GROUP_FETCH_FAILED") + SPACE + cause);
        throw new GenericException(env.getProperty("EXCHANGE_GROUP_FETCH_FAILED") + SPACE, cause);
    }

    public void throwExceptionIfExchangeRootFoldersFetchFailed(String userId, String cause) {
        logger.debug(" throwExceptionIfExchangeRootFoldersFetchFailed method executed with cause " + cause, userId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_ROOT_FOLDER_FETCH_FAILED")), userId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_ROOT_FOLDER_FETCH_FAILED")), userId), cause);
    }

    public void throwExceptionIfExchangeFilesFetchFailed(String userId, String folderId, String cause) {
        logger.debug(" throwExceptionIfExchangeFilesFetchFailed method executed with cause " + cause, userId, folderId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_FILES_FETCH_FAILED")), userId, folderId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_FILES_FETCH_FAILED")), userId, folderId), cause);
    }

    public void throwExceptionIfExchangeSubFoldersFetchFailed(String userId, String folderId, String cause) {
        logger.debug(" throwExceptionIfExchangeSubFoldersFetchFailed method executed with cause " + cause, userId, folderId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_CHILD_FOLDERS_FETCH_FAILED")), userId, folderId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("EXCHANGE_CHILD_FOLDERS_FETCH_FAILED")), userId, folderId), cause);
    }

    public void throwExceptionIfUsersWithArchiveRootFoldersFetchFailed(String domain, String cause) {
        logger.debug(" throwExceptionIfArchiveRootFoldersFetchFailed method executed with cause " + cause);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("ARCHIVE_ROOT_FOLDER_FETCH_FAILED")), domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("ARCHIVE_ROOT_FOLDER_FETCH_FAILED")), domain), cause);
    }

    public void throwExceptionIfSharePointFoldersInDomainFetchFailed(String domain, String cause) {
        logger.debug(" throwExceptionIfSharePointFoldersInDomainFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_ROOT_FOLDERS_IN_DOMAIN_FETCH_FAILED")), domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_ROOT_FOLDERS_IN_DOMAIN_FETCH_FAILED")), domain), cause);
    }

    public void throwExceptionIfSharePointSubSitesFetchFailed(String domain, String siteId, String cause) {
        logger.debug(" throwExceptionIfSharePointSubSitesFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_SUB_SITE_FETCH_FAILED")), siteId, domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_SUB_SITE_FETCH_FAILED")), siteId, domain), cause);
    }

    public void throwExceptionIfSharePointListFetchFailed(String domain, String siteId, String cause) {
        logger.debug(" throwExceptionIfSharePointListFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_LIST_FETCH_FAILED")), siteId, domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("SHARE_POINT_LIST_FETCH_FAILED")), siteId, domain), cause);
    }

    public void throwExceptionIfOneDrivesInDomainFetchFailed(String domain, String cause) {
        logger.debug(" throwExceptionIfOneDrivesInDomainFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("ONE_DRIVE_ROOT_FOLDERS_IN_DOMAIN_FETCH_FAILED")), domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("ONE_DRIVE_ROOT_FOLDERS_IN_DOMAIN_FETCH_FAILED")), domain), cause);
    }

    public void throwExceptionIfOneDriveContentsFetchFailed(String userId, String driveId, String cause) {
        logger.debug(" throwExceptionIfOneDriveContentsFetchFailed method executed with cause " + cause, userId, driveId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("USER_ONE_DRIVE_CONTENTS_FETCH_FAILED")), userId, driveId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("USER_ONE_DRIVE_CONTENTS_FETCH_FAILED")), userId, driveId), cause);
    }

    public void throwExceptionIfOneDriveFolderContentsFetchFailed(String userId, String itemId, String cause) {
        logger.debug(" throwExceptionIfOneDriveFolderContentsFetchFailed method executed with cause " + cause, userId, itemId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("USER_ONE_DRIVE_FILES_FETCH_FAILED")), userId, itemId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("USER_ONE_DRIVE_FILES_FETCH_FAILED")), userId, itemId), cause);
    }

    public void throwExceptionIfGraphUtilsBatchRequestFetchFailed(String domain, List<? extends BatchRequest> batchRequest, String cause) {
        logger.debug(" throwExceptionIfGraphUtilsBatchRequestFetchFailed method executed with cause " + cause + " batchRequest " + batchRequest, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("BATCH_ROOT_FOLDERS_FETCH_FAILED")), batchRequest, domain) + SPACE + cause);
    }

    public void throwExceptionIfPublicRootFoldersFetchFailed(String cause) {
        logger.debug(" throwExceptionIfPublicRootFoldersFetchFailed method executed with cause " + cause);
        logger.error(env.getProperty("PUBLIC_ROOT_FOLDERS_FETCH_ERROR") + SPACE + cause);
        throw new GenericException(env.getProperty("PUBLIC_ROOT_FOLDERS_FETCH_ERROR") + SPACE, cause);
    }

    public void throwExceptionIfPublicSubFoldersFetchFailed(String folderId, String cause) {
        logger.debug(" throwExceptionIfPublicSubFoldersFetchFailed method executed with cause " + cause, folderId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("PUBLIC_SUB_FOLDERS_FETCH_ERROR")), folderId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("PUBLIC_SUB_FOLDERS_FETCH_ERROR")), folderId), cause);
    }

    public void throwExceptionIfPublicFolderFilesFetchFailed(String folderId, String cause) {
        logger.debug(" throwExceptionIfPublicFolderFilesFetchFailed method executed with cause " + cause, folderId);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("PUBLIC_FOLDER_FILES_FETCH_ERROR")), folderId) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("PUBLIC_FOLDER_FILES_FETCH_ERROR")), folderId), cause);
    }

    public void throwExceptionAccessTokenIsInvalidToFetchReponseDuringRetry() {
        logger.debug(" throwExceptionIfAccessTokenIsInvalid method executed");
        logger.error(env.getProperty("ACCESS_TOKEN_INVALID"));
        throw new AccessTokenInvalidException(env.getProperty("ACCESS_TOKEN_INVALID"));
    }

    public void throwExceptionIfAccessTokenFetchFailed() {
        logger.debug(" throwExceptionIfAccessTokenFetchFailed method executed with cause");
        logger.error(env.getProperty("ACCESS_TOKEN_FETCH_FAILED"));
        throw new GenericException(env.getProperty("ACCESS_TOKEN_FETCH_FAILED"));
    }

    public void throwExceptionIfGraphUtilsResponseFetchFailed(String graphURL, Exception e) {
        logger.debug(" throwExceptionIfGraphUtilsResponseFetchFailed method executed with cause " + e + " graphURL " + graphURL);
        GenericException genericException = (GenericException) e;
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("GRAPH_RESPONSE_FETCH_FAILED")), graphURL) + SPACE + genericException.getError() + SPACE + genericException.getErrorCause());
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("GRAPH_RESPONSE_FETCH_FAILED")), graphURL), genericException.getError() + SPACE + genericException.getErrorCause());
    }

    public void throwExceptionIfGraphUtilsBatchResponseFetchFailed(String graphURL, List<? extends BatchRequest> batchRequest, String cause) {
        logger.debug(" throwExceptionIfGraphUtilsBatchResponseFetchFailed method executed with cause " + cause + " graphURL " + graphURL + " batchRequest " + batchRequest);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("GRAPH_RESPONSE_BATCH_FETCH_FAILED")), graphURL, batchRequest) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("GRAPH_RESPONSE_BATCH_FETCH_FAILED")), graphURL, batchRequest), cause);
    }

    public void throwExceptionIfDomainConfigurationFetchFailed(String domain, String cause) {
        logger.debug(" throwExceptionIfDomainConfigurationFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_CONFIGURATION_FETCH_FAILED")), domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_CONFIGURATION_FETCH_FAILED")), domain), cause);
    }

    public void throwExceptionIfDomainFromCacheFetchFailed(String domain, String cause) {
        logger.debug(" throwExceptionIfDomainFromCacheFetchFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_CACHE_FETCH_FAILED")), domain) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_CACHE_FETCH_FAILED")), SPACE, domain), cause);
    }

    public void throwExceptionIfExchangeServiceCreationFailed(String domain, String username, String cause) {
        logger.debug(" throwExceptionIfExchangeServiceCreationFailed method executed with cause " + cause, domain);
        logger.error(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_EXCHANGE_SERVICE_CREATION_FAILED")), domain, username) + SPACE + cause);
        throw new GenericException(MessageFormat.format(Objects.requireNonNull(env.getProperty("DOMAIN_EXCHANGE_SERVICE_CREATION_FAILED")), domain, username), cause);
    }
}
