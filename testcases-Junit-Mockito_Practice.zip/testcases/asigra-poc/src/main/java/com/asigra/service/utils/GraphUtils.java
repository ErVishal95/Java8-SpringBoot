package com.asigra.service.utils;

import com.asigra.exception.AccessTokenInvalidException;
import com.asigra.exception.GenericException;
import com.asigra.model.common.batch.BatchRequest;
import com.asigra.model.domain.Domain;
import com.asigra.service.DomainService;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
@PropertySources({
        @PropertySource("classpath:domain.properties"),
        @PropertySource("classpath:keys.properties")
})
public class GraphUtils {

    private final RestTemplate restTemplate;
    private final DomainService domainService;
    private final CommonUtils commonUtils;
    private final Environment env;
    private final ExceptionReportUtils exceptionReportUtils;

    private static final Logger logger = LogManager.getLogger(GraphUtils.class);
    private static final String SPACE = " ";
    private String ACCEPT_KEY = null;
    private String CONTENT_TYPE = null;

    @Autowired
    public GraphUtils(
            @Lazy RestTemplate restTemplate,
            @Lazy CommonUtils commonUtils,
            @Lazy Environment env,
            @Lazy DomainService domainService,
            @Lazy ExceptionReportUtils exceptionReportUtils) {
        this.restTemplate = restTemplate;
        this.commonUtils = commonUtils;
        this.env = env;
        this.domainService = domainService;
        this.exceptionReportUtils = exceptionReportUtils;

        ACCEPT_KEY = env.getProperty("accept_key");
        CONTENT_TYPE = env.getProperty("content_type");
    }

    @Retryable(value = {AccessTokenInvalidException.class}, maxAttempts = 2, backoff = @Backoff(delay = 2000))
    public JSONObject getObjectFromGraphService(String graphURL, String domain) {
        logger.debug(" getObjectFromGraphService graphutils service function executed with graphURL " + graphURL + " domain " + domain);
        Domain domainObj = null;
        JSONObject jsonObject = null;
        try {
            domainObj = domainService.getDomainProperties(domain);
            HttpEntity entity = setHttpHeaders(domainObj);
            jsonObject = getResponseFromGraphAPI(graphURL, entity);

        } catch (Exception e) {
            if (e instanceof HttpClientErrorException && e.getMessage().contains(Objects.requireNonNull(env.getProperty("unauthorized_key")))) {
                logger.debug(" retrying since access token is expired");
                Objects.requireNonNull(domainObj).setAccessToken(null);
                String accessToken = getAccessTokenFromUserCredentials(domainObj);
                String taskAccessToken = getTaskAccessTokenFromUserCredentials(domainObj);
                if (accessToken == null) {
                    exceptionReportUtils.throwExceptionIfAccessTokenFetchFailed();
                }
                domainObj.setAccessToken(accessToken);
                domainObj.setTaskAccessToken(taskAccessToken);
                exceptionReportUtils.throwExceptionAccessTokenIsInvalidToFetchReponseDuringRetry();
            }
            exceptionReportUtils.throwExceptionIfGraphUtilsResponseFetchFailed(graphURL, e);
        }
        return jsonObject;
    }

    public <T> List<T> getObjectFromGraphService(String graphURL, Class<T> requestedClassType, String domain) {
        logger.debug(" getObjectFromGraphService method of graphutils service function executed with graphURL " + graphURL + " requestedClassType " + requestedClassType + " domain " + domain);
        JSONObject responseFromGraphService = getObjectFromGraphService(graphURL, domain);
        return commonUtils.convertJSONObjectToList(responseFromGraphService, requestedClassType);
    }

    public String getResponseFromBatchRequest(final String graphURL, List<? extends BatchRequest> batchRequest, String domain, boolean betaTaskRequest) {
        logger.debug(" getResponseFromBatchRequest graphutils service function executed with graphURL " + graphURL + " betaTaskRequest " + betaTaskRequest);
        String responseForBatchRequest = null;
        HttpURLConnection conn = null;

        try {
            Domain domainObj = domainService.getDomainProperties(domain);
            URL url = new URL(graphURL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(RequestMethod.POST.name());
            conn.setRequestProperty(Objects.requireNonNull(ACCEPT_KEY), CONTENT_TYPE);
            conn.setRequestProperty(Objects.requireNonNull(env.getProperty("content_type_key")), CONTENT_TYPE);
            conn.setDoOutput(true);

            conn.setRequestProperty(Objects.requireNonNull(env.getProperty("authorization_key")), env.getProperty("bearer_key") + SPACE
                    + (betaTaskRequest ? domainObj.getTaskAccessToken() : domainObj.getAccessToken()));

            JsonObject rootObjectForRequest = new JsonObject();
            JsonElement batchRequestObj = new Gson().toJsonTree(batchRequest);
            rootObjectForRequest.add(Objects.requireNonNull(env.getProperty("batch_api_request_key")), batchRequestObj);

            String batchRequestStr = rootObjectForRequest.toString();

            if (StringUtils.isNotEmpty(batchRequestStr)) {
                OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
                out.write(batchRequestStr);
                out.close();
            }

            int responseCode = conn.getResponseCode();
            logger.debug(" responseCode after getting batch response " + responseCode);
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder outputJson = new StringBuilder();
            String output;

            while ((output = br.readLine()) != null) {
                outputJson.append(output);
            }

            JSONObject jsonObject = new JSONObject(outputJson.toString());
            responseForBatchRequest = jsonObject.getString(env.getProperty("batch_api_response_key"));
            logger.debug(" responseForBatchRequest after getting batch response " + responseForBatchRequest + " for the batch request " + batchRequestStr);

            conn.disconnect();

        } catch (Exception e) {
            exceptionReportUtils.throwExceptionIfGraphUtilsBatchResponseFetchFailed(graphURL, batchRequest, e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (Exception e) {
                logger.error(" exception in getResponseFromBatchRequest method " + e.getMessage());
            }
        }
        return responseForBatchRequest;
    }

    private HttpEntity setHttpHeaders(Domain domainObj) {
        String accessToken = domainObj.getAccessToken();
        String taskAccessToken;
        if (Objects.isNull(accessToken)) {
            accessToken = getAccessTokenFromUserCredentials(domainObj);
            taskAccessToken = getTaskAccessTokenFromUserCredentials(domainObj);
            if (Objects.isNull(accessToken)) {
                exceptionReportUtils.throwExceptionIfAccessTokenFetchFailed();
            }
            domainObj.setAccessToken(accessToken);
            domainObj.setTaskAccessToken(taskAccessToken);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Objects.requireNonNull(env.getProperty("authorization_key")), env.getProperty("bearer_key") + SPACE + accessToken);

        return new HttpEntity(headers);
    }

    @SuppressWarnings("unused")
    private String getAccessTokenFromUserCredentials(Domain domainObj) {
        String accessToken;

        HttpURLConnection conn = null;
        try {
            URL url = new URL(Objects.requireNonNull(env.getProperty(domainObj.getDomainName() + "_post_url")));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(RequestMethod.POST.name());
            conn.setRequestProperty(Objects.requireNonNull(ACCEPT_KEY), CONTENT_TYPE);
            conn.setDoOutput(true);

            StringBuilder params = getInputParametersForAccessToken(domainObj);
            addRequestParametersToFetchAccessToken(params, env.getProperty("grant_type_key"), env.getProperty("grant_type"));

            try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                dos.writeBytes(params.toString());
            }
            int responseCode = conn.getResponseCode();
            logger.debug(" responseCode for fetching the access token " + responseCode);

            String json;
            if (responseCode == org.apache.http.HttpStatus.SC_OK) {
                InputStream in = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                json = result.toString();

                JsonObject o = new JsonParser().parse(json).getAsJsonObject();
                accessToken = o.get(env.getProperty("access_token_key")).getAsString();

            } else {
                accessToken = null;
                logger.error(" errors in fetching the access token in the getAccessTokenFromUserCredentials method");
            }
        } catch (Exception e) {
            accessToken = null;
            logger.error("errors in fetching the access token in the getAccessTokenFromUserCredentials method " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (Exception e) {
                logger.error(" exception in closing the connection in the getAccessTokenFromUserCredentials method " + e.getMessage());
            }
        }

        return accessToken;
    }

    @SuppressWarnings("unused")
    public String getTaskAccessTokenFromUserCredentials(Domain domainObj) {
        logger.debug(" getTaskAccessTokenFromUserCredentials graphutils service function executed with domain " + domainObj.getDomainName());
        String accessToken;

        HttpURLConnection conn = null;
        try {
            URL url = new URL(Objects.requireNonNull(env.getProperty(domainObj.getDomainName() + "_post_url")));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(RequestMethod.POST.name());
            conn.setRequestProperty(Objects.requireNonNull(ACCEPT_KEY), CONTENT_TYPE);
            conn.setDoOutput(true);

            StringBuilder params = getInputParametersForAccessToken(domainObj);
            addRequestParametersToFetchAccessToken(params, env.getProperty("grant_type_key"), env.getProperty("task_grant_type"));

            try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                dos.writeBytes(params.toString());
            }
            int responseCode = conn.getResponseCode();
            logger.debug(" responseCode for fetching the access token " + responseCode);

            String json;
            if (responseCode == org.apache.http.HttpStatus.SC_OK) {
                InputStream in = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                json = result.toString();

                JsonObject o = new JsonParser().parse(json).getAsJsonObject();
                accessToken = o.get(env.getProperty("access_token_key")).getAsString();

            } else {
                accessToken = null;
                logger.error(" errors in fetching the access token in the getTaskAccessTokenFromUserCredentials method");
            }
        } catch (Exception e) {
            accessToken = null;
            logger.error("errors in fetching the access token in the getTaskAccessTokenFromUserCredentials method " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (Exception e) {
                logger.error(" exception in closing the connection in the getTaskAccessTokenFromUserCredentials method " + e.getMessage());
            }
        }

        return accessToken;
    }

    private StringBuilder getInputParametersForAccessToken(Domain domainObj) {
        StringBuilder params = new StringBuilder();
        addRequestParametersToFetchAccessToken(params, env.getProperty("resource_key"), env.getProperty("resource_url"));
        addRequestParametersToFetchAccessToken(params, env.getProperty("client_id_key"), domainObj.getClientId());
        addRequestParametersToFetchAccessToken(params, env.getProperty("client_secret_key"), domainObj.getClientSecret());
        addRequestParametersToFetchAccessToken(params, env.getProperty("token_username"), domainObj.getUserName());
        addRequestParametersToFetchAccessToken(params, env.getProperty("token_password"), domainObj.getPassword());

        return params;
    }

    private void addRequestParametersToFetchAccessToken(StringBuilder params, String key, String value) {
        if (params.length() > 0) {
            params.append("&");
        }
        params.append(key);
        params.append("=");
        try {
            params.append(URLEncoder.encode(value, Objects.requireNonNull(env.getProperty("default_encoding"))));
        } catch (UnsupportedEncodingException e) {
            logger.error(" exception in addRequestParametersToFetchToken method " + e.getMessage());
        }
    }

    private JSONObject getResponseFromGraphAPI(String graphURL, HttpEntity entity) {
        logger.debug(" getResponseFromGraphAPI graphutils service function executed with graphURL " + graphURL);
        try {
            ResponseEntity<String> result;
            result = restTemplate.exchange(graphURL, HttpMethod.GET, entity,
                    new ParameterizedTypeReference<String>() {
                    });

            return new JSONObject(result.getBody());
        } catch (Exception e) {
            logger.error(" exception in getting response from graph api " + e);
            throw new GenericException(e.getMessage());
        }
    }

    @Recover
    public <T> T errorInGettingAccessTokenAfterAllRetries(AccessTokenInvalidException atie, T exceptionText) {
        logger.debug(" errorInGettingAccessTokenAfterAllRetries method of graphutils service function executed with accessTokenInvalidException " + atie + " exceptionText " + exceptionText);
        logger.debug("All retries completed to fetch access token so the fallback method is executed with exceptionText " + exceptionText);
        return exceptionText;
    }
}