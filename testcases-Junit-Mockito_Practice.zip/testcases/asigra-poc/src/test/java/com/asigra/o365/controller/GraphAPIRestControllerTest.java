package com.asigra.o365.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.asigra.controller.GraphAPIRestController;
import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.common.File;
import com.asigra.model.common.Folder;
import com.asigra.model.common.SharePointContent;
import com.asigra.model.drive.OneDrive;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.calendar.Calendar;
import com.asigra.model.exchange.calendar.CalendarEvent;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.journal.Journal;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.task.TaskFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.sharepoint.SharePoint;
import com.asigra.model.sharepoint.SharePointSiteContent;
import com.asigra.model.user.User;
import com.asigra.service.impl.DriveServiceImpl;
import com.asigra.service.impl.ExchangeServiceImpl;

    @RunWith(SpringRunner.class)
    @WebMvcTest(GraphAPIRestController.class)
    public class GraphAPIRestControllerTest {

    	@MockBean
    	private ExchangeServiceImpl exchangeServiceImpl;
    	@MockBean
    	private DriveServiceImpl driverServiceImpl;
    	
        
    	@Autowired
        private MockMvc mockMvc;
    	//mock data
        private String id = "2a2c224b-0184-4a93-b217-2bf35171618e";
        private String displayName = "MC Rsystem";
        private String userPrincipalName = "MC.Rsystem@AsigraInc.onmicrosoft.com";
        private String DOMAIN = "asigrainc";
        private String folderId = "1";
        private String message = "Failed to retrieve child folders of a folder for user id "+id+" and folder Id "+folderId;
        private String details = "Failed to retrieve response from microsoft graph api for url: https://graph.microsoft.com/v1.0/users/2a2c224b-0184-4a93-b217-2bf35171618e/mailFolders/1/childFolders?$top=999&$select=id,displayName 400 Bad Request null";
        private String subject = "taskDemo";
        private String name = "taskDemoName";
        private String calendarId = "2";
        private List<Folder> fList = new ArrayList<Folder>();
        private boolean realtime = true;
        private String sharepointwebUrl = "https://asigrainc.sharepoint.com";
        private String oneDriveUserId = "11"; 
        private String itemId = "10"; 
        
        @Test
        public void testGetUserList() throws Exception {
        	User mockUser = new User(id, displayName, userPrincipalName);
            List<User> mockUserList = new ArrayList<>();
            mockUserList.add(mockUser);
            String expectedJson = "[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\",\"userPrincipalName\":\""+userPrincipalName+"\"}]";
        	Mockito.when(exchangeServiceImpl.getUserList(DOMAIN, true)).thenReturn(mockUserList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetGroupList() throws Exception {
        	User mockUser = new User(id, displayName, userPrincipalName);
            List<User> mockUserList = new ArrayList<>();
            mockUserList.add(mockUser);
            String expectedJson = "[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\",\"userPrincipalName\":\""+userPrincipalName+"\"}]";
        	Mockito.when(exchangeServiceImpl.getGroupList(DOMAIN)).thenReturn(mockUserList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/groups").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserRootExchangeFolders() throws Exception {
        	Folder folder =  new Folder(id, displayName);
        	List<Folder> exchangeFolderList = new ArrayList<>();
        	exchangeFolderList.add(folder);
        	ExchangeObject mockExchangeObject = new ExchangeObject();
        	mockExchangeObject.setExchangeFolderList(exchangeFolderList);
            List<ExchangeObject> mockExchangeObjectList = new ArrayList<>();
            mockExchangeObjectList.add(mockExchangeObject);
            String expectedJson = "[{\"exchangeFolderList\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}]}]";
           
            Mockito.when(exchangeServiceImpl.getUserRootExchangeFolders(id, DOMAIN)).thenReturn(mockExchangeObjectList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/folders").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetMailboxSubFolders() throws Exception {
        	ExchangeFolder exchangeFolder =  new ExchangeFolder(id, displayName);
        	List<ExchangeFolder> mockexchangeFolderList = new ArrayList<>();
        	mockexchangeFolderList.add(exchangeFolder);
            String expectedJson = "[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}]";
        	Mockito.when(exchangeServiceImpl.getMailboxSubFolders(id, folderId,  DOMAIN)).thenReturn(mockexchangeFolderList);
        	MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/folders/"+folderId+"/folders").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetAllEmailsOfFolder() throws Exception {
        	File file = new File(id, subject);
        	List<File> mockfileList = new ArrayList<>();
        	mockfileList.add(file);
            String expectedJson = "[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]";
        	Mockito.when(exchangeServiceImpl.getAllEmailsOfFolder(id, folderId,  DOMAIN)).thenReturn(mockfileList);
        	MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/folders/"+folderId+"/files").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserRootCalendars() throws Exception {
        	Calendar calendar = new Calendar(id, name);
        	List<Calendar> mockcalendarList = new ArrayList<>();
        	mockcalendarList.add(calendar);
            String expectedJson = "[{\"id\":\""+id+"\",\"name\":\""+name+"\"}]";
        	Mockito.when(exchangeServiceImpl.getUserRootCalendars(id, DOMAIN)).thenReturn(mockcalendarList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/calendars").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserCalendarEvents() throws Exception {
        	CalendarEvent calendarEvent = new CalendarEvent(id, subject);
        	List<CalendarEvent> mockcalendarEventList = new ArrayList<>();
        	mockcalendarEventList.add(calendarEvent);
            String expectedJson = "[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]";
        	Mockito.when(exchangeServiceImpl.getUserCalendarEvents(id, DOMAIN,  calendarId)).thenReturn(mockcalendarEventList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/calendars/"+calendarId).accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserJournals() throws Exception {
        	Journal journal = new Journal(id, subject);
        	List<Journal> mockjournalEventList = new ArrayList<>();
        	mockjournalEventList.add(journal);
            String expectedJson = "[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]";
        	Mockito.when(exchangeServiceImpl.getUserJournals(id, DOMAIN)).thenReturn(mockjournalEventList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/journals").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserRootContacts() throws Exception {
        	Folder folder =  new Folder(id, displayName);
        	List<Folder> FolderList = new ArrayList<>();
        	FolderList.add(folder);
        	ContactObject contactObject = new ContactObject();
        	contactObject.setContacts(FolderList);
        	contactObject.setContactFolders(FolderList);
        	List<ContactObject> mockContactObjectEventList = new ArrayList<>();
        	mockContactObjectEventList.add(contactObject);
            String expectedJson = "[{\"contactFolders\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}],\"contacts\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserContactFolderContents(id, DOMAIN, null)).thenReturn(mockContactObjectEventList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/contacts/").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserContactFolderContents() throws Exception {
        	Folder folder =  new Folder(id, displayName);
        	List<Folder> FolderList = new ArrayList<>();
        	FolderList.add(folder);
        	ContactObject contactObject = new ContactObject();
        	contactObject.setContacts(FolderList);
        	contactObject.setContactFolders(FolderList);
        	List<ContactObject> mockContactObjectEventList = new ArrayList<>();
        	mockContactObjectEventList.add(contactObject);
           
        	String expectedJson = "[{\"contactFolders\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}],\"contacts\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserContactFolderContents(id, DOMAIN, folderId)).thenReturn(mockContactObjectEventList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/contacts/"+folderId).accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserRootTasks() throws Exception {
        	File tasks = new File(id, subject);
        	List<File> mockfileList = new ArrayList<>();
        	mockfileList.add(tasks);
        	TaskFolder taskFolder = new TaskFolder(id, name);
        	List<TaskFolder> mocktaskFoldersList = new ArrayList();
        	mocktaskFoldersList.add(taskFolder);
        	TaskObject taskObject = new TaskObject();
        	taskObject.setTaskFolders(mocktaskFoldersList);
        	taskObject.setTasks(mockfileList);
        	List<TaskObject> mocktaskObjectsList = new ArrayList();
        	mocktaskObjectsList.add(taskObject);
           
        	String expectedJson = "[{\"taskFolders\":[{\"id\":\""+id+"\",\"name\":\""+name+"\"}],\"tasks\":[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserTaskFolderContents(id, DOMAIN, null)).thenReturn(mocktaskObjectsList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/tasks/").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserTaskFolderContents() throws Exception {
        	File tasks = new File(id, subject);
        	List<File> mockfileList = new ArrayList<>();
        	mockfileList.add(tasks);
        	TaskFolder taskFolder = new TaskFolder(id, name);
        	List<TaskFolder> mocktaskFoldersList = new ArrayList();
        	mocktaskFoldersList.add(taskFolder);
        	TaskObject taskObject = new TaskObject();
        	taskObject.setTaskFolders(mocktaskFoldersList);
        	taskObject.setTasks(mockfileList);
        	List<TaskObject> mocktaskObjectsList = new ArrayList();
        	mocktaskObjectsList.add(taskObject);
           
        	String expectedJson = "[{\"taskFolders\":[{\"id\":\""+id+"\",\"name\":\""+name+"\"}],\"tasks\":[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserTaskFolderContents(id, DOMAIN, folderId)).thenReturn(mocktaskObjectsList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/users/"+id+"/tasks/"+folderId+"/").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUsersHavingArchiveFolders() throws Exception {
        	User mockUser = new User(id, displayName, userPrincipalName);
            List<User> mockUserList = new ArrayList<>();
            mockUserList.add(mockUser);
            String expectedJson = "[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\",\"userPrincipalName\":\""+userPrincipalName+"\"}]";
            Mockito.when(exchangeServiceImpl.getUsersHavingArchiveFolders(DOMAIN, realtime)).thenReturn(mockUserList);
        	MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/archive/folders/realtime/"+realtime).accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserRootArchiveFolders() throws Exception {
        	File file = new File(id, subject);
        	List<File> mockfileList = new ArrayList<>();
        	mockfileList.add(file);
        	Folder folder = new Folder(id, displayName);
        	List<Folder> mocktaskFoldersList = new ArrayList();
        	mocktaskFoldersList.add(folder);
        	ArchiveObject archiveObject = new ArchiveObject();
        	archiveObject.setArchiveFileList(mockfileList);
        	archiveObject.setArchiveFolderList(mocktaskFoldersList);
        	List<ArchiveObject> mockarchiveObjectList = new ArrayList();
        	mockarchiveObjectList.add(archiveObject);
            String expectedJson = "[{\"archiveFolderList\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}],\"archiveFileList\":[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserRootArchiveFolders(DOMAIN, id)).thenReturn(mockarchiveObjectList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/archive/users/"+id+"/folders").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetUserArchiveFolderContents() throws Exception {
        	File file = new File(id, subject);
        	List<File> mockarchiveFileList = new ArrayList<>();
        	mockarchiveFileList.add(file);
        	
        	Folder folder = new Folder(id, displayName);
        	List<Folder> mockarchiveFolderList = new ArrayList();
        	mockarchiveFolderList.add(folder);
        	
        	ArchiveObject archiveObject = new ArchiveObject();
        	archiveObject.setArchiveFileList(mockarchiveFileList);
        	archiveObject.setArchiveFolderList(mockarchiveFolderList);
        	
        	List<ArchiveObject> mockarchiveObjectList = new ArrayList();
        	mockarchiveObjectList.add(archiveObject);
            
        	String expectedJson = "[{\"archiveFolderList\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\"}],\"archiveFileList\":[{\"id\":\""+id+"\",\"subject\":\""+subject+"\"}]}]";
        	Mockito.when(exchangeServiceImpl.getUserArchiveFolderContents(DOMAIN, id, folderId)).thenReturn(mockarchiveObjectList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/archive/users/"+id+"/folders/"+folderId+"/contents").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetSharePointRootFoldersInADomain() throws Exception {
        	SharePoint sharePoint = new SharePoint();
        	sharePoint.setId(id);
        	sharePoint.setName(name);
        	sharePoint.setWebUrl(sharepointwebUrl);
        	List<SharePoint> mockSSharePointList = new ArrayList<>();
        	mockSSharePointList.add(sharePoint);
           String expectedJson = "[{\"id\":\""+id+"\",\"name\":\""+name+"\",\"webUrl\":\""+sharepointwebUrl+"\"}]";
           Mockito.when(driverServiceImpl.getSharePointRootFoldersInDomain(DOMAIN, realtime)).thenReturn(mockSSharePointList);
           MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/sharepoint/realtime/"+realtime).accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetSharePointSiteContents() throws Exception {
        	SharePointContent content = new SharePointContent(id, sharepointwebUrl, displayName, sharepointwebUrl);
        	List<SharePointContent> mockSharePointContentList = new ArrayList<>();
            mockSharePointContentList.add(content);
            SharePointSiteContent sharePointSiteContent = new SharePointSiteContent();
            sharePointSiteContent.setLists(mockSharePointContentList);
            List<SharePointSiteContent> mocksharePointSiteContentsList = new ArrayList();
            mocksharePointSiteContentsList.add(sharePointSiteContent);
            
            String expectedJson = "[{\"subSites\":[],\"lists\":[{\"id\":\""+id+"\",\"displayName\":\""+displayName+"\",\"webUrl\":\""+sharepointwebUrl+"\"}]}]";
            
        	Mockito.when(driverServiceImpl.getSharePointSiteContents(DOMAIN, id)).thenReturn(mocksharePointSiteContentsList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/sharepoint/"+id+"/"+"contents").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetOneDriveRootFoldersForAllUsersInADomain() throws Exception {
        	OneDrive oneDrive =  new OneDrive(id, name, sharepointwebUrl, oneDriveUserId);
        	List<OneDrive> mockOneDriveList = new ArrayList<>();
        	mockOneDriveList.add(oneDrive);
            String expectedJson = "[{\"id\":\""+id+"\",\"name\":\""+name+"\",\"webUrl\":\""+sharepointwebUrl+"\",\"oneDriveUserId\":\""+oneDriveUserId+"\"}]";
           
        	Mockito.when(driverServiceImpl.getOneDriveRootFoldersForAllUsersInDomain(DOMAIN, realtime)).thenReturn(mockOneDriveList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/one-drive/realtime/"+realtime).accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetContentsOfTheRootDrive() throws Exception {
        	OneDrive oneDrive =  new OneDrive(id, name, sharepointwebUrl, oneDriveUserId);
        	List<OneDrive> mockOneDriveList = new ArrayList<>();
        	mockOneDriveList.add(oneDrive);
            String expectedJson = "[{\"id\":\""+id+"\",\"name\":\""+name+"\",\"webUrl\":\""+sharepointwebUrl+"\",\"oneDriveUserId\":\""+oneDriveUserId+"\"}]";
           
        	Mockito.when(driverServiceImpl.getContentsOfTheRootDrive(id, oneDriveUserId, DOMAIN)).thenReturn(mockOneDriveList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/one-drive/users/"+id+"/drives/"+oneDriveUserId+"/contents").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }
        
        @Test
        public void testGetOneDriveFilesOfAFolder() throws Exception {
        	OneDrive oneDrive =  new OneDrive(id, name, sharepointwebUrl, oneDriveUserId);
        	List<OneDrive> mockOneDriveList = new ArrayList<>();
        	mockOneDriveList.add(oneDrive);
            String expectedJson = "[{\"id\":\""+id+"\",\"name\":\""+name+"\",\"webUrl\":\""+sharepointwebUrl+"\",\"oneDriveUserId\":\""+oneDriveUserId+"\"}]";
            
        	Mockito.when(driverServiceImpl.getContentsOfOneDriveFolder(id, itemId, DOMAIN)).thenReturn(mockOneDriveList);
        	
    		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get(
    				"/graph/domain/"+DOMAIN+"/one-drive/users/"+id+"/items/"+itemId+"/contents").accept(
    				MediaType.APPLICATION_JSON);

    		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    		String resultFromURL=result.getResponse().getContentAsString();
    		
    		JSONAssert.assertEquals(expectedJson, resultFromURL, false);
    		assertEquals(HttpStatus.SC_OK,result.getResponse().getStatus());
    		   	
        }

    }