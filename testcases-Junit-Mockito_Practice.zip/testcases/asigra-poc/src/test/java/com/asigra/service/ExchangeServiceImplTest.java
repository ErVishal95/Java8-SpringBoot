package com.asigra.service;


import com.asigra.constants.GraphAPIURLS;
import com.asigra.model.archive.ArchiveObject;
import com.asigra.model.common.File;
import com.asigra.model.common.Folder;
import com.asigra.model.domain.DomainEntity;
import com.asigra.model.exchange.ExchangeObject;
import com.asigra.model.exchange.calendar.Calendar;
import com.asigra.model.exchange.calendar.CalendarEvent;
import com.asigra.model.exchange.contact.ContactObject;
import com.asigra.model.exchange.journal.Journal;
import com.asigra.model.exchange.mailbox.ExchangeFolder;
import com.asigra.model.exchange.task.TaskFolder;
import com.asigra.model.exchange.task.TaskObject;
import com.asigra.model.user.User;
import com.asigra.service.impl.ExchangeServiceImpl;
import com.asigra.service.utils.CommonUtils;
import com.asigra.service.utils.ExceptionReportUtils;
import com.asigra.service.utils.GraphUtils;
import org.hamcrest.collection.IsCollectionWithSize;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import java.util.*;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ExchangeServiceImplTest {

    private final String DOMAIN = "asigrainc";
    private final String USER_ID = "2a2c224b-0184-4a93-b217-2bf35171618e";
    private final String FOLDER_ID = "AQMkADZiOTE0MjRmLTAzZjAtNGZiMS04ZDljLTMwYjg5NTg5YjdiYQAuAAADKyJ4Zl50u0ugpNu-5GdxywEAiiSl6h9Lq0G2tDACF8xwhQAAAgEMAAAA";
    @Mock
    private GraphUtils graphUtils;
    @Mock
    private CommonUtils commonUtils;
    @Mock
    private BatchService batchService;
    @Mock
    private CacheService cacheService;
    @Mock
    private ExceptionReportUtils exceptionReportUtils;
    @Mock
    private Environment env;
    private ExchangeServiceImpl exchangeServiceImpl;

    @Before
    public void init() {
        exchangeServiceImpl = new ExchangeServiceImpl(commonUtils,
                graphUtils,
                exceptionReportUtils,
                batchService,
                cacheService,
                env);
        when(env.getProperty("next_link_key")).thenReturn("@odata.nextLink");

    }

    @Test
    public void getExistingUserList_withlicenses_test() throws Exception {
        // given
        List<User> existingUsers = getUsers();
        JSONObject jsonObject = mock(JSONObject.class);
        when(graphUtils.getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN)).thenReturn(jsonObject);
        when(commonUtils.convertJSONObjectToList(jsonObject, User.class)).thenReturn(existingUsers);
        when(jsonObject.getString(env.getProperty("next_link_key")))
                .thenThrow(new RuntimeException("No next link available"));

        // when
        List<User> userList = exchangeServiceImpl.getUserList(DOMAIN, true);

        // then
        String userPrincipalName = userList.get(0).getUserPrincipalName();
        assertThat(userList, notNullValue());
        assertThat(userList, IsCollectionWithSize.hasSize(1));
        assertThat(Arrays.asList(userPrincipalName), hasItems("MC.Rsystem@AsigraInc.onmicrosoft.com"));
        verify(graphUtils, times(1)).getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN);
        verify(commonUtils, times(1)).convertJSONObjectToList(jsonObject, User.class);
        verifyNoMoreInteractions(graphUtils);
        verifyNoMoreInteractions(commonUtils);
    }

    @Test
    public void getExistingUserList_nolicenses_test() throws Exception {
        // given
        User user = new User();
        user.setAssignedLicenses(Collections.emptyList());
        List<User> existingUsers = Collections.singletonList(user);
        JSONObject jsonObject = mock(JSONObject.class);
        when(jsonObject.getString(env.getProperty("next_link_key")))
                .thenThrow(new RuntimeException("No next link available"));
        when(graphUtils.getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN)).thenReturn(jsonObject);
        when(commonUtils.convertJSONObjectToList(jsonObject, User.class)).thenReturn(existingUsers);

        // when
        List<User> userList = exchangeServiceImpl.getUserList(DOMAIN, true);

        // then
        assertThat(userList, IsCollectionWithSize.hasSize(0));
        verify(graphUtils, times(1)).getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN);
        verify(commonUtils, times(1)).convertJSONObjectToList(jsonObject, User.class);
    }

    @Test
    public void getUserRootExchangeFolders_test() {
        // given
        ExchangeObject exchangeObject = getExchangeObject();

        when(batchService.fetchGenericDataFromGraphUsingBatch(anyString(), anyList(), any())).thenReturn(exchangeObject);
        // when
        List<ExchangeObject> results = exchangeServiceImpl.getUserRootExchangeFolders(USER_ID, DOMAIN);

        // then
        ExchangeObject response = results.get(0);
        assertThat(response.getExchangeFolderList(), IsCollectionWithSize.hasSize(1));
        verify(batchService, times(1)).fetchGenericDataFromGraphUsingBatch(anyString(), anyList(), any());
    }

    @Test
    public void getMailboxSubFolders_test() {
        // given
        ExchangeFolder exchangeFolder = getExchangeFolder();

        when(graphUtils.getObjectFromGraphService(anyString(), any(), anyString())).thenReturn(Collections.singletonList(exchangeFolder));
        // when
        List<ExchangeFolder> results = exchangeServiceImpl.getMailboxSubFolders(USER_ID, "folderId", DOMAIN);

        // then
        ExchangeFolder response = results.get(0);
        assertEquals(response.getId(), exchangeFolder.getId());
        assertEquals(response.getDisplayName(), exchangeFolder.getDisplayName());
        verify(graphUtils, times(1)).getObjectFromGraphService(anyString(), any(), anyString());
    }

    @Test
    public void getAllMessagesOfFolder_test() {
        // given
        List<File> filesOfFolder = getFilesOfFolder();
        List<File> results = new ArrayList<>();
        when(graphUtils.getObjectFromGraphService(
                String.format(GraphAPIURLS.USER_MAILBOX_FOLDER_MSGS, USER_ID, FOLDER_ID), File.class, DOMAIN))
                .thenReturn(filesOfFolder);

        // when
        results = exchangeServiceImpl.getAllEmailsOfFolder(USER_ID, FOLDER_ID, DOMAIN);

        // then
        assertThat(results, notNullValue());
        assertThat(results, IsCollectionWithSize.hasSize(1));
        verify(graphUtils, times(1)).getObjectFromGraphService(
                String.format(GraphAPIURLS.USER_MAILBOX_FOLDER_MSGS, USER_ID, FOLDER_ID), File.class, DOMAIN);
        verifyNoMoreInteractions(graphUtils);
    }

    @Test
    public void getUserRootArchiveFolders_test() {
        // given
        ArchiveObject archiveObject = getArchiveObject();

        when(batchService.fetchGenericDataFromGraphUsingBatch(anyString(), any(), any())).thenReturn(archiveObject);
        // when
        List<ArchiveObject> results = exchangeServiceImpl.getUserRootArchiveFolders(DOMAIN, USER_ID);

        // then
        ArchiveObject response = results.get(0);
        assertThat(response.getArchiveFolderList(), IsCollectionWithSize.hasSize(1));
        assertThat(response.getArchiveFileList(), IsCollectionWithSize.hasSize(1));
        verify(batchService, times(1)).fetchGenericDataFromGraphUsingBatch(anyString(), any(), any());
        verifyNoMoreInteractions(batchService);
    }

    @Test
    public void getUserArchiveFolderContents_test() {
        // given
        ArchiveObject archiveObject = getArchiveObject();

        when(batchService.fetchGenericDataFromGraphUsingBatch(anyString(), any(), any())).thenReturn(archiveObject);
        // when
        List<ArchiveObject> results = exchangeServiceImpl.getUserArchiveFolderContents(DOMAIN, USER_ID, "folderId");

        // then
        ArchiveObject response = results.get(0);
        assertThat(response.getArchiveFolderList(), IsCollectionWithSize.hasSize(1));
        assertThat(response.getArchiveFileList(), IsCollectionWithSize.hasSize(1));
        verify(batchService, times(1)).fetchGenericDataFromGraphUsingBatch(anyString(), any(), any());
        verifyNoMoreInteractions(batchService);
    }

    @Test
    public void getRootCalendars_test() {
        List<Calendar> userCalendars = getCalendars();
        List<Calendar> results = new ArrayList<>();
        String userRootCalendarsURL = String.format(GraphAPIURLS.USER_ROOT_CALENDARS, (Object[]) new String[]{USER_ID});
        when(graphUtils.getObjectFromGraphService(userRootCalendarsURL, Calendar.class, DOMAIN)).thenReturn(userCalendars);

        results = exchangeServiceImpl.getUserRootCalendars(USER_ID, DOMAIN);

        assertThat(results, notNullValue());
        assertThat(results, IsCollectionWithSize.hasSize(1));
        assertThat(Arrays.asList(results.get(0).getName()), hasItems("Canada holidays"));
        verify(graphUtils, times(1)).getObjectFromGraphService(String.format(GraphAPIURLS.USER_ROOT_CALENDARS, USER_ID, FOLDER_ID), Calendar.class, DOMAIN);
        verifyNoMoreInteractions(graphUtils);
    }

    @Test
    public void getUserJournals_test() {
        // given
        Journal journal = new Journal();
        journal.setId("id");
        journal.setSubject("journal");

        when(graphUtils.getObjectFromGraphService(anyString(), any(), any())).thenReturn(Collections.singletonList(journal));
        // when
        List<Journal> results = exchangeServiceImpl.getUserJournals(DOMAIN, USER_ID);

        // then
        Journal response = results.get(0);
        assertEquals(response.getId(), journal.getId());
        assertEquals(response.getSubject(), journal.getSubject());
        verify(graphUtils, times(1)).getObjectFromGraphService(anyString(), any(), any());
        verifyNoMoreInteractions(graphUtils);
    }

    @Test
    public void getUserCalendarEvents_test() {
        // given
        CalendarEvent calendarEvent = new CalendarEvent();
        calendarEvent.setId("id");
        calendarEvent.setSubject("event");

        when(graphUtils.getObjectFromGraphService(anyString(), any(), any())).thenReturn(Collections.singletonList(calendarEvent));
        // when
        List<CalendarEvent> results = exchangeServiceImpl.getUserCalendarEvents(DOMAIN, USER_ID, "calndarId");

        // then
        CalendarEvent response = results.get(0);
        assertEquals(response.getId(), calendarEvent.getId());
        assertEquals(response.getSubject(), calendarEvent.getSubject());
        verify(graphUtils, times(1)).getObjectFromGraphService(anyString(), any(), any());
        verifyNoMoreInteractions(graphUtils);
    }

    @Test
    public void getUserContactFolderContents_test() {
        // given
        ContactObject contactObject = new ContactObject();
        contactObject.getContactFolders().add(new Folder());
        contactObject.getContacts().add(new Folder());

        when(batchService.fetchGenericDataFromGraphUsingBatch(anyString(), any(), any())).thenReturn(contactObject);
        // when
        List<ContactObject> results = exchangeServiceImpl.getUserContactFolderContents(DOMAIN, USER_ID, "contactFolderId");

        // then
        ContactObject response = results.get(0);
        assertThat(response.getContactFolders(), IsCollectionWithSize.hasSize(1));
        assertThat(response.getContacts(), IsCollectionWithSize.hasSize(1));
        verify(batchService, times(1)).fetchGenericDataFromGraphUsingBatch(anyString(), any(), any());
        verifyNoMoreInteractions(graphUtils);
    }

    @Test
    public void getUserTaskFolderContents_test() {
        // given
        TaskObject taskObject = new TaskObject();
        taskObject.getTaskFolders().add(new TaskFolder("id", "name"));
        taskObject.getTasks().add(new File("id", "task"));

        when(batchService.fetchGenericDataFromGraphUsingBatch(anyString(), any(), any())).thenReturn(taskObject);
        // when
        List<TaskObject> results = exchangeServiceImpl.getUserTaskFolderContents(DOMAIN, USER_ID, null);

        // then
        TaskObject response = results.get(0);
        assertThat(response.getTaskFolders(), IsCollectionWithSize.hasSize(1));
        assertThat(response.getTasks(), IsCollectionWithSize.hasSize(2));
        verify(batchService, times(2)).fetchGenericDataFromGraphUsingBatch(anyString(), any(), any());
        verifyNoMoreInteractions(batchService);
    }

    @Test
    public void getUsersHavingArchiveFolders_no_cache_test() throws Exception {
        // given
        User user = new User();
        user.setId("id");
        user.setDisplayName("name");
        user.setUserPrincipalName("name");
        user.setAssignedLicenses(Collections.emptyList());
        List<User> existingUsers = Collections.singletonList(user);
        JSONObject jsonObject = mock(JSONObject.class);

        when(jsonObject.getString(env.getProperty("next_link_key"))).thenThrow(new RuntimeException("No next link available"));
        when(graphUtils.getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN)).thenReturn(jsonObject);
        when(commonUtils.convertJSONObjectToList(jsonObject, User.class)).thenReturn(existingUsers);
        when(batchService.fetchUsersWithArchiveEnabledFromGraphUsingBatch(any(), anyList(), any(), any(), any(), any())).thenReturn(existingUsers);
        doNothing().when(cacheService).cacheUserWithArchiveFoldersToDB(DOMAIN, existingUsers);
        // when
        List<User> results = exchangeServiceImpl.getUsersHavingArchiveFolders(DOMAIN, true);

        // then
        User response = results.get(0);
        assertThat(results, IsCollectionWithSize.hasSize(1));
        assertEquals(response.getId(), user.getId());
        assertEquals(response.getDisplayName(), user.getDisplayName());
        verify(graphUtils, times(1)).getObjectFromGraphService(GraphAPIURLS.ALL_USERS, DOMAIN);
        verify(commonUtils, times(1)).convertJSONObjectToList(jsonObject, User.class);
        verify(batchService, times(1)).fetchUsersWithArchiveEnabledFromGraphUsingBatch(any(), anyList(), any(), any(), any(), any());
        verify(cacheService, times(1)).cacheUserWithArchiveFoldersToDB(DOMAIN, existingUsers);
        verifyNoMoreInteractions(graphUtils);
        verifyNoMoreInteractions(commonUtils);
        verifyNoMoreInteractions(batchService);
    }

    @Test
    public void getUsersHavingArchiveFolders_cache_test() throws Exception {
        // given
        DomainEntity domainObj = mock(DomainEntity.class);
        Optional<DomainEntity> domainEntity = Optional.of(domainObj);

        when(cacheService.getDomainEntityFromDB(DOMAIN)).thenReturn(domainEntity);
        when(domainObj.getUsersWithArchiveFolders()).thenReturn(Collections.singletonList(new User()));
        // when
        List<User> results = exchangeServiceImpl.getUsersHavingArchiveFolders(DOMAIN, false);

        // then
        assertThat(results, IsCollectionWithSize.hasSize(1));

        verify(cacheService, times(1)).getDomainEntityFromDB(DOMAIN);
        verifyNoMoreInteractions(cacheService);
    }

    private List<Calendar> getCalendars() {
        Calendar calendar = new Calendar();
        String CALENDAR_ID = "AQMkADZiOTE0MjRmLTAzZjAtNGZiMS04ZDljLTMwYjg5NTg5YjdiYQBGAAADKyJ4Zl50u0ugpNu-5GdxywcAiiSl6h9Lq0G2tDACF8xwhQAAAgEGAAAAiiSl6h9Lq0G2tDACF8xwhQAAAiGbAAAA";
        String CALENDAR_NAME = "Canada holidays";
        calendar.setId(CALENDAR_ID);
        calendar.setName(CALENDAR_NAME);

        return Collections.singletonList(calendar);
    }


    private List<ExchangeFolder> getExchangeSubFolders() {
        String SUB_FOLDER_ID = "AAMkADZiOTE0MjRmLTAzZjAtNGZiMS04ZDljLTMwYjg5NTg5YjdiYQAuAAAAAAArInhmXnS7S6Ck27-kZ3HLAQCKJKXqH0urQba0MAIXzHCFAAACZWgcAAA=";
        ExchangeFolder exchangeFolder = new ExchangeFolder(SUB_FOLDER_ID, "Test 1");

        return Collections.singletonList(exchangeFolder);
    }

    private List<File> getFilesOfFolder() {
        File file = new File(
                "AAMkADZiOTE0MjRmLTAzZjAtNGZiMS04ZDljLTMwYjg5NTg5YjdiYQBGAAAAAAArInhmXnS7S6Ck27-kZ3HLBwCKJKXqH0urQba0MAIXzHCFAAAAAAEMAACKJKXqH0urQba0MAIXzHCFAAATssnGAAA=",
                "Message Center Major Change Update Notification");

        return Collections.singletonList(file);
    }

    private List<User> getUsers() {
        List<User> usersList = new ArrayList<>();
        User user1 = new User();
        user1.setId(USER_ID);
        String USER_NAME = "MC Rsystem";
        user1.setDisplayName(USER_NAME);
        String USER_PRINCIPAL_NAME = "MC.Rsystem@AsigraInc.onmicrosoft.com";
        user1.setUserPrincipalName(USER_PRINCIPAL_NAME);
        String USER_LICENSE = "Exchange License";
        user1.setAssignedLicenses(Collections.singletonList(USER_LICENSE));
        usersList.add(user1);

        return usersList;
    }

    private ExchangeObject getExchangeObject() {
        ExchangeObject exchangeObject = new ExchangeObject();
        exchangeObject.getExchangeFolderList().add(new Folder("id", "name"));
        return exchangeObject;
    }

    private ExchangeFolder getExchangeFolder() {
        ExchangeFolder exchangeFolder = new ExchangeFolder("id", "name");
        return exchangeFolder;
    }

    private ArchiveObject getArchiveObject() {
        ArchiveObject archiveObject = new ArchiveObject();
        archiveObject.getArchiveFolderList().add(new Folder());
        archiveObject.getArchiveFileList().add(new File());
        return archiveObject;
    }

}
